<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $newPort = $_POST['port'];

      


  // Check if the provided port is valid (optional)
  if (is_numeric($newPort) && $newPort > 0 && $newPort <= 65535) {
    // Edit the Apache configuration file
    $httpdConfPath = 'D:/xampp/apache/conf/httpd.conf';
    $httpdConfContent = file_get_contents($httpdConfPath);
    $updatedHttpdConfContent = preg_replace('/Listen\s*\d+/', 'Listen ' . $newPort, $httpdConfContent);
    file_put_contents($httpdConfPath, $updatedHttpdConfContent);

    // // Restart Apache service
    // exec('net stop Apache2.4');
    // exec('net start Apache2.4');

    // echo 'Apache port changed successfully!';

    //  sleep(4);

   
 echo 'Apache port changed successfully!';
        
 

  } else {
    echo 'Invalid port number!';
  }
}
?>
