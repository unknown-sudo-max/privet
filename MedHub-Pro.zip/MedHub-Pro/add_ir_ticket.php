
<?php


require_once 'connect.php';
//require_once 'Add_new_user.php';

if(isset($_POST['addnewtkt'])){



//@$alert =$_POST['alert'];








if (!empty($_POST['unique_id']) && !empty($_POST['title']) && !empty($_POST['subject'])) {

	# code...

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	# code...
@$unique_id                      = strip_tags($_POST['unique_id']);
@$title                          = strip_tags($_POST['title']);
@$subject                        = strip_tags($_POST['subject']);
@$problemtype                    = strip_tags($_POST['problemtype']);
@$status                         = strip_tags($_POST['status']);
@$comment                        = strip_tags($_POST['comment']);
@$addedby                        = strip_tags($_POST['addedby']);
@$segmentation                   = strip_tags($_POST['segmentation']);
@$handler                        = strip_tags($_POST['handler']);
@$date                           = strip_tags($_POST['date']);





$db  = "INSERT INTO irtickets  (unique_id,title,subject,problemtype,status,comment,addedby,segmentation,handler,date)VALUES('$unique_id','$title','$subject','$problemtype','open','$comment','$addedby','$segmentation','$handler','$date')";

 

if (mysqli_query($conn, $db)) {

	# code...

	echo "<p style='color:green; font-size:15px;'>The Ticket Added Successfully - We will contact with you shortly ..</p>";
	echo "<script> window.location.href=('./Tickets.php');</script>";
}
	else{

		echo "<p style='color:red; font-size:15px;'>Failed TO Add The Ticket !!!)</p>";
	}


	
//mysqli_close($conn);
}


}else{
	echo "<p style='color:red; font-size:15px;'>The  <u style='font-weight:  bold;'>Subject & Title </u>   Fields Are Required !!! </p>";
}
/*
if (mysqli_query($conn, $db )) {

	# code...

	echo "user added success";
}
	else{

		echo "failed";
	}

mysqli_close($conn);

*/



}

ob_start();

@session_start();
//@$_SESSION['theuser'] = $_POST['theuser'];

//@$_SESSION['thepass'] = $_POST['thepass'];

//@$_SESSION['thefname'] = $_POST['thefname'];

/*


if(isset($_POST['save'])){

extract($_REQUEST);
$file=fopen('myusers2.php' , 'a');
fwrite(@$file, "///////////////");
fwrite(@$file, $thefname);
fwrite(@$file, " User");
fwrite(@$file, "//");
fwrite(@$file, "\n");
fwrite(@$file, "if(isset($");
fwrite(@$file, "_");
fwrite(@$file, "POST['submit'])){");
fwrite(@$file, "if(");
fwrite(@$file, "$");
fwrite(@$file, "user ");
fwrite(@$file, "== '");
fwrite(@$file, $theuser);
fwrite(@$file, "'){");
fwrite(@$file, "if(");
fwrite(@$file, "$");
fwrite(@$file, "pass ");
fwrite(@$file, "== '");
fwrite(@$file, $thepass);
fwrite(@$file, "'){");
fwrite(@$file, "echo ");
fwrite(@$file, "\"<script>");
fwrite(@$file, "window.location.href=");
fwrite(@$file, "('Avaya_vaildation.php');");
fwrite(@$file, "</script>\";");
fwrite(@$file, "}");

fwrite(@$file, "else{");

fwrite(@$file, "$");
fwrite(@$file, "error ");
fwrite(@$file, "= ");
fwrite(@$file, "\"<div ");
fwrite(@$file, "style='position: relative;text-align: center;'>");
fwrite(@$file, "<n style='color: red;'>");
fwrite(@$file, "Invalid Login</n>");
fwrite(@$file, "<br><k>");
fwrite(@$file, "Check your password again , OR refer to your Adminstrator");
fwrite(@$file, "</k><div>\";");
//fwrite(@$file, "$error = \'<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid Login</n><br><k>Check your password again , OR refer to your Adminstrator</k><div>\';");
   
fwrite(@$file, "$");
fwrite(@$file, "success ");
   fwrite(@$file, "= '';"); 


     fwrite(@$file, "echo \"<br><br> <br> ");    
     fwrite(@$file, "$");
     fwrite(@$file, "error\";");       
     fwrite(@$file, "}}}");  
     fwrite(@$file, "\n");       

            
}

*/





  ob_end_flush();

?>
