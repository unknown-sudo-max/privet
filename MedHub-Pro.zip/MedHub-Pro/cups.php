<?php

require_once 'connect.php';



//setcookie('user' , @$_POST['user'], time() + (86400 * 30), "/"); // 86400 = 1 day

//session_start();

   


if(isset($_POST['change'])){

 $_SESSION['user'] = $_POST['user'];

    $user = $_SESSION['user'];




    //////////////////////////////first phase//////////////////////////////


$user = $_POST['user'];


$error2 = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid User</n><br><k>This User Are Not Exsit in Our DataBase  , So  refer to your Adminstrator</k><div>";

$query1 = "SELECT * FROM users WHERE user='$user'";
$result = mysqli_query($conn, $query1 );
$count = mysqli_num_rows($result);
if ($count>0) {




////////////////////////////////////////////////////second phase/////////////////////

$user = $_POST['user'];
$pass = $_POST['pass'];
$error = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid Old Password </n><br><k>Check Your Old Password again , OR Refer To Your Adminstrator</k><div>";
$success = "";

$query = "SELECT * FROM users WHERE user='$user' AND pass='$pass'";
$result = mysqli_query($conn, $query );








$count = mysqli_num_rows($result);
if ($count>0) {
    # code...
    

////////////////////////////////////////////////////third phase/////////////////////







if (!empty($_POST['user']) && !empty($_POST['addedon']) && !empty($_POST['npass'])) {

    # code...
 if ($_SERVER['REQUEST_METHOD'] == 'POST') {
@$user       = strip_tags($_POST['user']);
@$npass      = strip_tags($_POST['npass']);
@$addedon    = strip_tags($_POST['addedon']);




$sql= "UPDATE users set  pass='$npass', date='$addedon' WHERE user='$user' ";

}

//$sql= "UPDATE records set  fullname='$_POST[fullname]', pcuser='$_POST[pcuser]', pcpass='$_POST[pcpass]', login='$_POST[login]', shifttime='$_POST[shifttime]', sitestatus='$_POST[sitestatus]', arrivalstatus='$_POST[fullname]', recordstatus='$_POST[recordstatus]', comment='$_POST[comment]', shiftondate='$_POST[arrivalstatus]', addedon='$_POST[addedon]' WHERE id='$_POST[id]' ";




if (mysqli_query($conn, $sql)) {

    # code...

    echo "<p style='color:green; font-size:15px;'>Your Password are Changed Successfully</p>";



    session_unset();
    echo "<script>
//Using setTimeout to execute a function after 5 seconds.
setTimeout(function () {
   //Redirect with JavaScript
   window.location.href= 'index.php?session=expired';
}, 1000);
</script>";
    
//refresh
exit();



}
    else{

        echo "<p style='color:red; font-size:15px;'>Failed TO Updated The User !!!</p>";
    }

mysqli_close($conn);

}
else{
    echo "<p style='color:red; font-size:15px;'>The  .. <u style='font-weight:  bold;'>' User & Old Pass & New Pass '</u> ..  Fields Are Required !!! </p>";
}



















////////////////////////////////////////////////////third phase/////////////////////

}
else{
            $error = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid Old Password </n><br><k>Check Your Old Password again , OR Refer To Your Adminstrator</k><div>";
            $success = "";
            echo "<br><br> <br> $error";
        }




////////////////////////////////////////////////////second phase/////////////////////







}

else{
            $error2 = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid User </n> ' $user '<br><k>This User Are Not Exsit in Our DataBase  , So  refer to your Adminstrator</k><div>";
            
            echo "<br><br> <br> $error2";

            

 }








    //////////////////////////////first phase//////////////////////////////

}



?>