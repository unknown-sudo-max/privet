<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* Custom CSS styling for the dashboard */
        /* Add your own styles here */
        body {
            padding: 20px;
        }
        .dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
            margin-left: 5px;
        }
        .dot-green {
            background-color: green;
        }
        .dot-red {
            background-color: red;
        }
        .dot-yellow {
            background-color: yellow;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>IT Dashboard</h1>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        System Status
                    </div>
                    <div class="card-body">
                        <p>Status: <span id="status"></span><span id="dot"></span></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        Server Health
                    </div>
                    <div class="card-body">
                        <p id="serverHealthStatus">Server Health Status <i id="serverHealthIcon" class=""></i></p>
                        <p>Server CPU Usage: <span id="cpuUsage"></span>%</p>
                        <p>Server Memory Usage: <span id="memoryUsage"></span>%</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // JavaScript/jQuery code to update the dashboard data

        // Function to fetch and update system status
        function updateSystemStatus() {
            // Make an AJAX request to the server
            $.ajax({
                url: 'system_status.php',
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    // Update the status element with the received data
                    $('#status').text(data.status);
                    $('#dot').removeClass().addClass('dot dot-' + data.dotColor);
                },
                error: function() {
                    // Handle errors if any
                    $('#status').text('Error retrieving status');
                }
            });
        }

        // Function to fetch and update server health
        function updateServerHealth() {
            // Make an AJAX request to the server
            $.ajax({
                url: 'server_health.php',
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    // Update the CPU and memory usage elements with the received data
                    $('#cpuUsage').text(data.cpuUsage);
                    $('#memoryUsage').text(data.memoryUsage);

                    // Update the server health status based on CPU and memory usage
                    var cpuUsage = parseInt(data.cpuUsage);
                    var memoryUsage = parseInt(data.memoryUsage);
                    var serverHealthIcon = $('#serverHealthIcon');

                    if (cpuUsage > 80 && memoryUsage > 80) {
                        $('#serverHealthStatus').removeClass().addClass('text-danger');
                        serverHealthIcon.removeClass().addClass('fas fa-exclamation-triangle');
                    } else if (cpuUsage < 40 && memoryUsage < 40) {
                        $('#serverHealthStatus').removeClass().addClass('text-success');
                        serverHealthIcon.removeClass().addClass('fas fa-check-circle');
                    } else {
                        $('#serverHealthStatus').removeClass().addClass('text-warning');
                        serverHealthIcon.removeClass().addClass('fas fa-exclamation-circle');
                    }
                },
                error: function() {
                    // Handle errors if any
                    $('#cpuUsage').text('Error retrieving CPU usage');
                    $('#memoryUsage').text('Error retrieving memory usage');
                    $('#serverHealthStatus').removeClass().addClass('text-secondary');
                    $('#serverHealthIcon').removeClass();
                }
            });
        }

        // Update the dashboard data on page load
        $(document).ready(function() {
            updateSystemStatus();
            updateServerHealth();
        });

        // Update the dashboard data every 10 seconds
        setInterval(function() {
            updateSystemStatus();
            updateServerHealth();
        }, 10000);
    </script>
</body>
</html>
