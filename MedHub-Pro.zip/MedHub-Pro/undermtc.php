<?php 

require_once('header.php');
?>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<style type="text/css">
	.spand{

		padding: 10px;
		position: absolute;
		left: 3%;
		top: 100px;
		width: 70%;
		margin: 4px;
		font-size: 30px;
		text-align: center;
		font-weight: bold;
		text-shadow: 10px 10px 20px darkred;
	}

	.spandd{

		padding: 10px;
		position: absolute;
		left: 3%;
	    top: 143px;
		width: 70%;
		margin: 4px;
		font-size: 30px;
		text-align: center;
		font-weight: bold;
		text-shadow: 10px 10px 20px darkred;
		z-index: -1;
		opacity: 0.7;
	}



 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){

.spand {
    padding: 10px;
    position: absolute;
    left: 10%;
    top: 208px;
    width: 80%;
    margin: 4px;
    font-size: 30px;
    text-align: center;
    font-weight: bold;
    text-shadow: 10px 10px 20px darkred;
}


}

	@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){




.spand {
    padding: 10px;
    position: absolute;
    left: -48%;
    top: 154px;
    width: 90%;
    margin: 4px;
    font-size: 30px;
    text-align: center;
    font-weight: bold;
    text-shadow: 10px 10px 20px darkred;
}

 


}

</style>


<span class="spand" dir="ltr">Sorry <u>(*_<i>This Page</i>_*)</u> currently under maintenance  will back to Normal Soon !!!! ,  if you have any inquiry Kindly refer to your superior.</span>
<div class="spandd" ><img src="img/iconfinder-websiteunderconstruction-4417109_116618.png"></div>

<script>setTimeout(function(){ history.back(); }, 5000);</script>