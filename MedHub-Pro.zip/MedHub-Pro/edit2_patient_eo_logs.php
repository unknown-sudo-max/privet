
<?php 
$start_time = microtime(TRUE);
require_once('header.php');
// include 'access.php';
access('EO');

      
 
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="ircss.css">

<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />


<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
 <script type="text/javascript" src="cdn/xlsx.full.min.js"></script>
 <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script src="cdn/dd9c95f04f.js" crossorigin="anonymous"></script>
<script src="cdn/table2excel-master"></script>
<script type="text/javascript">

 


$(document).ready(function() {

let topbutton = document.getElementById("topBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    topbutton.style.display = "block";
  } else {
    topbutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document





$('#specialization').on('change', function () {
let val = $('#specialization').val();

        console.log(val);
        $("option[value='وجه و فكين']").attr('disabled', 'disabled');
$("option[value='العيادات المسائية']").attr('disabled', 'disabled');
$("option[value='قلب مفتوح']").attr('disabled', 'disabled');

        if (val == 'وجه و فكين' || val == 'قلب مفتوح') {
            $('#doctor').attr('disabled', true);
        } else {
            $('#doctor').attr('disabled', false);
        }
    })



 




var exit_type      = $('#exit_type').val();

if (exit_type == 'وفاة') {
  document.getElementById("editneweo").remove();
  document.getElementById("checkbox_div").style.display = 'none';
  document.getElementById("hrr").style.display = 'none';
  document.getElementById('record_status').disabled = true;
  document.getElementById('exit_type').disabled = true;
  document.getElementById('exit_date').disabled = true;
  document.getElementById('doctor').disabled = true;
  document.getElementById('specialization').disabled = true;
  document.getElementById('financial_transaction').disabled = true;
  document.getElementById('health_insurance_beneficiary').disabled = true;
  document.getElementById('entry_type').disabled = true;
  document.getElementById('date_of_entry').disabled = true;
  document.getElementById('section').disabled = true;
  document.getElementById('grade').disabled = true;
  document.getElementById('exit_date').setAttribute('readonly','readonly');
}


var nonne = $('#nonne').html();

if (nonne == 'لا يوجد ملفات تم ارفاقها') {
  document.getElementById("editneweo").remove();
  document.getElementById("export_button").remove();
  document.getElementById("export_button2").remove();
  document.getElementById("viewbtn").remove();
   

}


    // body...

$("#record_status").on('change', function(){


 

  $(".exit_date_box").hide();
  // $("#exit_date").val('');
  $("#" + $(this).val()).fadeIn(700);
 
}).change();


var now = new Date();
var this_year = now.getFullYear();
var month = ("0" + (now.getMonth() + 1)).slice(-2);
var day = ("0" + now.getDate()).slice(-2);
var st_year = this_year.toString();
var last_two_dig_of_year = st_year[2]+st_year[3];
var pa_national_id = $('#pa_national_id').val();
var national_id = pa_national_id.toString();
var select_gender = national_id[12];
var select_century = national_id[0];
var select_birthdate = national_id[1]+national_id[2]+'-'+national_id[3]+national_id[4]+'-'+national_id[5]+national_id[6];
var select_birthmonth = national_id[3]+national_id[4];
var select_birthday = national_id[5]+national_id[6];
var select_year_of_birth = national_id[1]+national_id[2];
var age_last_century = (this_year+month+day)- ("19"+select_year_of_birth+select_birthmonth+select_birthday);
var st_age_last_century = age_last_century.toString();

var age_this_century = (this_year+month+day)- ("20"+select_year_of_birth+select_birthmonth+select_birthday);
var st_age_this_century = age_this_century.toString();


if (select_century == '2') {


$('#age').html(st_age_last_century[0]+st_age_last_century[1]+ '&nbsp;'+'عام');


}else if (select_century == '3') {


  $('#age').html(st_age_this_century[0]+st_age_this_century[1]+ '&nbsp;'+'عام');

}



var now = new Date();
 
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear()+"-"+(month)+"-"+(day) ;


 if ($('#record_status').val() == 'دخول') {
 

$('#exit_type').val("");
$('#exit_date').val("");
$('#date_of_entry').val(today);
}else if($('#record_status').val() == 'خروج'){

 
$('#exit_date').val(today);
$('#date_of_entry').val('');

}







function html_table_to_excel(type)
    {

        var data = document.getElementById('myTable');
         var patientname      = $('#patient_name').val();
         
        
       
 

        var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});


        XLSX.write(file, { bookType: type, type : 'binary', cellStyles : true, bookSST: true, type: 'base64' });

         

        XLSX.writeFile(file, patientname + '_patient logs in DB file.' + type);

    }

    const export_button = document.getElementById('export_button');



    export_button.addEventListener('click', () =>  {


        html_table_to_excel('xlsx');


 



    });



    ///////////M_G_X_ORIGINALS/////////////////////////////


   $("#spo_degree_of_kinship").on('change', function(){


 

  $(".spo_degree_of_kinship_box").hide();
  // $("#exit_date").val('');
  $("#" + $(this).val()).fadeIn(700);
 
}).change();


if(isset($_POST['addneweo'])){

if ($('#spo_degree_of_kinship2').val() == '') {
  
  document.getElementById("spo_degree_of_kinship2").disabled = true;
  document.getElementById("أخري").remove();

} else{
   
   document.getElementById("spo_degree_of_kinship2").disabled = false;
}


}
 



 


});
 








 function eo_upload_file() {
  var checkBox = document.getElementById("checkboxf");
  var div5 = document.getElementById("file_area");
  
  

  if (checkBox.checked == true){
   $(div5).fadeIn(900);
   div5.style.display = "block";

   
  } else {
     $(div5).fadeOut(900);
     div5.style.display = "none";
  }
}




///////////M_G_X_ORIGINALS/////////////////////////////


function spo_degree_of_kinship_validate() {


  const spo_degree_of_kinship2 = document.getElementById('spo_degree_of_kinship2');
  const spo_degree_of_kinship = document.getElementById('spo_degree_of_kinship');

 if ($('#spo_degree_of_kinship').val() != 'أخري') {
 



spo_degree_of_kinship2.setAttribute('name', 'example-name');
spo_degree_of_kinship.setAttribute('name', 'spo_degree_of_kinship');

}else{

  

spo_degree_of_kinship2.setAttribute('name', 'spo_degree_of_kinship');
spo_degree_of_kinship.setAttribute('name', 'example-name');
}
}
 




function entry_type_validate() {


var now = new Date();
 
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear()+"-"+(month)+"-"+(day) ;


  

 if ($('#record_status').val() == 'دخول') {
 


$('#exit_type').val("");
$('#exit_date').val("");
$('#date_of_entry').val(today);
}else if ($('#record_status').val() == 'خروج') {
 
 

$('#exit_type').val("");
$('#exit_date').val(today);
$('#date_of_entry').val('');
}}


function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
  // window.scrollTo({ top: 0, behavior: 'smooth' });
}












var subjectObject = {
  //1- batna
  "باطنة": {
    "هشام عبد الحميد":[],
    "محمود رجب":[],
    "جورج فاروق":[],
    "جمال العطار":[],
    "عمر عبد السلام":[]
    // "PHP":[],
    // "SQL":[]
    
  },
  //2- kebd
  "كبد": {
    "رأفت عطا":[],
    "رانيا امين":[],
    "شندي محمد":[],
    "أحمد الراعي":[]
    // "PHP":[],
    // "SQL":[]

  },
  //3- 2alb
  "قلب": {
    "زهراء":[],
    "محمد امام":[],
    "وائل شحات":[],
    "شادي زهران":[]
    // "PHP":[],
    // "SQL":[]
    
  },
  //4- sadr
  "صدر": {
    "راندا صلاح":[],
    "وائل شحات":[]
    // "PHP":[],
    // "SQL":[]
    
  },
  //5- anf & ozon
  "انف و اذن": {
    "خالد رشيد":[],
    "هدير اسامة":[],
    "خالد الجوهري":[],
    "هبه محمود":[]
    // "PHP":[],
    // "SQL":[]
    
  },
  //6- ramad
  "رمد": {
    "سهير عصمت":[],
    "محمود جمال":[],
    "إيمان محمد":[],
    "مصطفي بهجت":[],
    "مصطفي الغنام":[],
    "محمد هاني":[],
    "أحمد فوزي":[]
    // "PHP":[],
    // "SQL":[]

  },
  //7- gera7a
  "جراحة": {
    "يحي صفوت":[],
    "وليد الشيمي":[],
    "محمد عبد اللطيف":[],
    "مدحت عامر":[],
    "علاء حنفي":[],
    "محمد الكردي":[],
    "محمد ندا":[],
    "محمد فاروق":[],
    "سعيد البرجي":[],
    "محمود الافندي":[]
    // "PHP":[],
    // "SQL":[]

  },
  //8- nafsya & 3asabya
  "نفسية و عصبية": {
    "منتصر حجازي":[],
    "أحمد قدري":[]
    // "PHP":[],
    // "SQL":[]
  
  },
  //9- geldya
  "جلدية": {
    "ميريت امين":[],
    "شهيرة طلبه":[],
    "مصطفي يحي":[]
    // "PHP":[],
    // "SQL":[]
  
  },
  //10- masalek
  "مسالك": {
    "علي حسن":[],
    "حسن النمر":[],
    "تامر فؤاد":[],
    "محمود المهدي":[]
    // "PHP":[],
    // "SQL":[]
    
  },
  //11- 3zam
  "عظام": {
    "حامد الجوهري":[],
    "شريف البيسي":[],
    "محمد المراكبي":[],
    "وليد احمد":[],
    "محمد توفيق":[],
    "بهاء قرنه":[],
    "محمد شبانه":[],
    "وليد السيد":[],
    "سوزان الغرابي":[],
    "حسين جمعة":[],
    "محمد سليمان قطب":[],
    "احمد منصور":[],
    "محمد صابر":[],
    "محمد عبد الحميد":[],
    "محمد زيدان":[],
    "عاطف البلتاجي":[]
    // "PHP":[],
    // "SQL":[]
  },
  //12- wageh & faken
  
  "وجه و فكين": {
    "لا يتوفر في الوقت الحالي":[]

    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  //13- romatezm
  "روماتيزم": {
    "حنان حسين":[],
    "شريف قنديل":[],
    "ايمان الجزار":[],
    "سعادات الغوابي":[],
    "رانيا امين":[]
    // "PHP":[],
    // "SQL":[]
   
  },
  //14- kola
  "كلي": {
    "عصام حامد":[],
    "محمد علي ابراهيم":[]
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // 15- mo5 & a3sab
  "مخ و اعصاب": {
    "محمد مصطفي":[],
    "محمد المليجي":[],
    "سمير صابر":[],
    "طارق زكي":[],
    "محمد عيد":[],
    "احمد صلاح":[],
    "عماد الاكوح":[],
    "محمد حلمي":[],
    "احمد عمرو حافظ":[],
    "احمد كحيل":[],
    "احمد مرعي":[]
    // "PHP":[],
    // "SQL":[]
  },
  // 16- aw3ya
  "اوعية": {
    "حسين كمال":[],
    "اشرف علي":[],
    "علاء عبد الحليم":[],
    "احمد جمال":[],
    "احمد رفعت":[],
    "محمود فوزي":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // 17- nesaa & welada
  "نساء و ولادة": {
    "هبه ابراهيم":[]
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // 18- ta5der
  "تخدير": {
    "محمد احمد عبدالله":[]
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // 19- asnan
  "أسنان": {
    "بسمه محمود":[],
    "اسامة كمال":[]
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // // 20- el3yada el mas2ya
  // "العيادات المسائية": {
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "SQL":[]
  // },
  // 21- awram
  "أورام": {
    "خالد كمال الدين":[]
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // 22- 2alb mafto7
  "قلب مفتوح": {
    "لا يتوفر في الوقت الحالي":[]

    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  }
}



window.onload = function() {
  var specializationSel = document.getElementById("specialization");
  var doctorSel = document.getElementById("doctor");
 
  for (var x in subjectObject) {
    specializationSel.options[specializationSel.options.length] = new Option(x, x);
  }


   specializationSel.onchange = function() {
    //empty Chapters- and Topics- dropdowns
// chapterSel.length = 1;
    doctorSel.length = 1;
    //display correct values
    for (var y in subjectObject[this.value]) {
      doctorSel.options[doctorSel.options.length] = new Option(y, y);
    }
  }
}



///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////




</script>

<style type="text/css">

#topBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  left: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: #b95656;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
}

#topBtn:hover {
  background-color: #555;
}


.export_button {
    font-size: 16px;
    border: none;
    outline: none;
    color: white;
    cursor: pointer;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}



input[type="date"]::-webkit-datetime-edit, input[type="date"]::-webkit-inner-spin-button, input[type="date"]::-webkit-clear-button {
  color: #fff;
  position: relative;
}

input[type="date"]::-webkit-datetime-edit-year-field{
  position: absolute !important;
  border-left:1px solid #8c8c8c;
  padding: 2px;
  color:#000;
  left: 56px;
}

input[type="date"]::-webkit-datetime-edit-month-field{
  position: absolute !important;
  border-left:1px solid #8c8c8c;
  padding: 2px;
  color:#000;
  left: 26px;
}


input[type="date"]::-webkit-datetime-edit-day-field{
  position: absolute !important;
  color:#000;
  padding: 2px;
  left: 4px;
  
}
 
select{
background-color: #bbb8b8;
}

.logomain {
    width: 80%;
    position: absolute;
    right: -70px;
    top: -175px;
    cursor: pointer;
}


.demo-wrap {
  position: relative;
}

.demo-wrap:after {
  content: ' ';
  display: block;
  position: absolute;
  float: left;
  left: 0;
  top: 0;
  width: 22%;
  height: 100%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}

li{
  list-style-type: none;

}

/*a {
  float: left;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
  background-color: #30072c;
  color: white;
  font-weight: bold;
    

}
 a:hover {
  background-color: #a5707a;
  color: black;
  font-weight: bold;
}*/

  .btnup{

padding: 10px;
margin: 8px;
border-radius: 5px;
border: none;
text-decoration: none;
background-color: #30072c;
  color: white;
  font-weight: bold;
    
transition-duration: 0.4s;
cursor: pointer;
left: -7px;
position: relative;

  }


  .btnup:hover{

 background-color: #a5707a;
  color: black;
  font-weight: bold;



  }
  .fn{

align-items: center;

  }

  .com{
 
 align-items: center;

  }
  .divup{
    padding: 10px;
  }


  details > summary {
  list-style: none;

}
.allofthelist{

width: 70%;
position: absolute;
float: left;
left: 3%;

}

/*.cpr{

  padding: 12px;
  margin: 12px;
  position: absolute;

  text-align: center;
 cursor: not-allowed;
  top: 99%;
  left: 30%;
  
}*/
 
details > summary {
  list-style: none;
}



#left{
   position: absolute; 
   left:0;
}

  </style>
  <button onclick='topFunction()' id='topBtn' title='Go to top'><span class="material-symbols-outlined">arrow_upward</span></button>
<div class="eocontainer" style="width: 73%; background-color: ; position: absolute; left: 2%;">


  <div  id="heeed"><span style="font-size: 30px; border: 2px #958997 solid; padding: 4px; margin: 3px; box-shadow: 3px 3px 50px 3px #4c1943; font-weight: bold; border-radius: 12px; text-shadow: 8px 6px 8px #784a73;font-family: 'Reem Kufi', sans-serif; " id="heed">تعديل بيانات مريض</span></div>
 
<hr>
<div>
  <title>View</title>






<style type="text/css">
  

.box{
  display: none;
}
  table {
   font-family: 'Reem Kufi', sans-serif;
  border-collapse: collapse;
  width: 100%;
}

  td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}



/*.body{
  position: absolute;
  right: 37%;
  width: 50%;
}*/


 .w3-sidebar{

     position: relative;
     right: 0;
     top: 0;
  }

   .sessiondiv{

    position: relative;
    top:  -13px;

   }

     header{

  position: absolute;
  left: 0;
  padding: 10px;

  }

#heeed{

  display: flex; 
  justify-content: center;


}

  
  @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){

  #divco{
    overflow: scroll;
    width: 100%;
    position: relative;
  }


  }
 
 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){

.body{
  

    top: 137px;
    position: absolute;
    right: -31%;
    width: 133%;
}



#myTable{
  overflow: scroll;
 
}


 #heeed{

    display: flex;
    justify-content: center;
    position: relative;
    top: 87px;
    left: 71px;
}


  #divco{
    overflow: scroll;
    width: 100%;
    position: relative;
  }

 }
@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){

.body{
  position: absolute;
left: 6%;
top: 150px;
width: 120%;

}


  #divco{
    overflow: scroll;
    width: 100%;
    position: relative;
  }

#left{
    position: relative; 
    
}


/*#myTable{
  overflow: scroll;
  display: none;
}
#logstitlespan{
  display: none;
  visibility: hidden;
}*/

.sglat{
  font-size: 7px;
 }

 #heeed{

    display: flex;
    justify-content: center;
    position: relative;
    top: 87px;
    left: 47px;
}


.export_button {
    font-size: 10px;
    border: none;
    outline: none;
    color: white;
    cursor: pointer;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

}

</style>



<body dir="ltr">

<div class="body">
<?php
ob_start(); 
/*

fullname
pcuser
pcpass
login
shifttime
sitestatus
arrivalstatus

*/








@session_start();



    

ob_end_flush();
?>
          
<!--

<div class="addnewbox" style="position:relative; left: 30%; width:40%; height:80%; background-color: gray;">


<tr>


<td>

<br>


<th>

<p>your name : </p>
</th>
</td>
<td>
<input type="text"  width:20PX; placeholder="" >
</td>
</tr>
</div>
  -->
  <!--Connection-->  <!--Connection-->
  <co class="co">
<?php

require_once('connect.php');


?>
</co>

<br id="brh" hidden>
<br id="brh" hidden>
 
<h3 style="text-align: center; font-size: 230%; font-family: cursive;" id="ht">( Editing Reports Area )</h3>
<br id="brh" hidden>
 
<hr color="black" size="5">

<ti id="ti" hidden >Printing Date :- &nbsp; <?php date_default_timezone_set('Africa/Cairo'); $timee = date('d/m/Y, h:i:s A'); echo ($timee);?>&nbsp;   ||  &nbsp; Printer user : <?php echo $_SESSION['user'];?></ti>
<br><br>
<form method="POST" name="myform" autocomplete="on" id="myform"  enctype="multipart/form-data" style="" dir="rtl"  >
<div class="rnr-brickcontents style1 rnr-b-wrapper  rnr-wrapper rnr-cbw-fields"  >

<div class="rnr-cw-fields rnr-s-fields asbuttons MetroOffice"    >
<div class="rnr-c rnr-cv rnr-c-fields">


<div class="rnr-brickcontents style2 rnr-b-addheader " id="neww" ><span> <h1 style="font-family: 'Reem Kufi', sans-serif;">تعديل بيانات مريض</h1>
</span></div>
<div class="rnr-brickcontents style2 rnr-b-addheader " id="neww2"><span> <h1></h1>
</span></div>

<div class="rnr-brickcontents style2 rnr-b-addheader "  id="neww3" ><span> <h1 style="font-family: 'Reem Kufi', sans-serif;"> Record id :  <input type="text"  style="border-radius: 7px; background-color: black; color: white; border: none; outline: none;" readonly=""  id="unique_id" name="unique_id" maxlength="24" value="<?php $unique_id =$_GET['unique_id']; echo $unique_id; ?>"/></h1>
</span></div>
 

 
 

<div class="rnr-brickcontents style1 rnr-b-addfields_simple "><div class="rnr-simplefields edit">
  


  <?php

$unique_id =$_GET['unique_id'];

$query = "SELECT * FROM patient_login_eo WHERE unique_id='$unique_id' ";

$query_run = mysqli_query($conn, $query);
if (mysqli_num_rows($query_run) > 0 ) {
    # code...
   foreach ($query_run as $row) {
    // code...

 


echo "



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"  id=\"left\">
 <span class=\"rnr-label\">رقم هاتف المريض :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"pa_phone_num\" style=\"width: 200px; background-color:#e1e1e1; opacity: 0.7;\" type=\"text\" name=\"pa_phone_num\" oninput=\"this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*?)\..*/g, '$1');\" value=\"$row[pa_phone_num]\" readonly >&nbsp;<font color=\"red\">*</font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
   <span class=\"rnr-label\">الرقم القومي :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"pa_national_id\" style=\"width: 200px; background-color:#e1e1e1; opacity: 0.7;\" type=\"text\" name=\"pa_national_id\" oninput=\"this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*?)\..*/g, '$1');\" value=\"$row[pa_national_id]\" readonly>&nbsp;<font color=\"red\">*</font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"  id=\"left\">
  <span class=\"rnr-label\">الرقم الطبي :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"medical_number\" style=\"width: 200px; background-color:#e1e1e1; opacity: 0.7;\" type=\"text\" name=\"medical_number\"oninput=\"this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*?)\..*/g, '$1');\"  value=\"$row[medical_number]\" readonly >&nbsp;<font color=\"red\">*</font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">اسم المريض :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"patient_name\" style=\"width: 200px; background-color:#e1e1e1; opacity: 0.7;\" type=\"text\" name=\"patient_name\"  value=\"$row[patient_name]\" readonly>&nbsp;<font color=\"red\">*</font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"  id=\"left\">
  <span class=\"rnr-label\">النوع :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"gender\" style=\"width: 200px; background-color:#e1e1e1; opacity: 0.7;\" type=\"text\" name=\"gender\"  value=\"$row[gender]\" readonly>&nbsp;<font color=\"red\">*</font></span></span>
</div> 

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">تاريخ الميلاد :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"date_of_birth\" style=\"width: 200px; background-color:#e1e1e1; opacity: 0.7;\" type=\"text\" name=\"date_of_birth\"  value=\"$row[date_of_birth]\" readonly>&nbsp;<font color=\"red\">*</font></span></span>
  <span class=\"rnr-label\" style='min-width: 0px;'>السن :</span><span class=\"rnr-label\" id='age' style='min-width: 0px;'></span>
</div>

 

<hr>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"    id=\"left\">
  <span class=\"rnr-label\">درجة قرابة المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"spo_degree_of_kinship\" onfocusout=\"spo_degree_of_kinship_validate()\" name=\"spo_degree_of_kinship\" style=\"width: 207px;\"><option value='أب'>أب</option><option value='أم'>أم</option><option value='أخ'>أخ</option><option value='أخت'>أخت</option><option value='زوج او زوجة'>زوج او زوجة</option><option value='أبن او أبنة'>أبن او أبنة</option><option value='أخري'>أخري</option><option value='$row[spo_degree_of_kinship]' selected>$row[spo_degree_of_kinship]</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div> 



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">اسم المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"sponsor_name\" style=\"width: 200px;background-color:#e1e1e1; opacity: 0.7;\" type=\"text\" name=\"sponsor_name\"  value=\"$row[sponsor_name]\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>


<div class='spo_degree_of_kinship_box' id='أخري'>
<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"    id=\"left\">
  <span class=\"rnr-label\">درجة قرابة أخري :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"spo_degree_of_kinship2\" style=\"width: 200px;\" type=\"text\" name=\"\"  value=\"\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">رقم هاتف المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"spo_phone_num\" maxlength=\"11\" style=\"width: 200px;background-color:#e1e1e1; opacity: 0.7;\" type=\"text\" oninput=\"this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*?)\..*/g, '$1');\" name=\"spo_phone_num\"  value=\"$row[spo_phone_num]\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>





<hr>
<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \" id=\"checkbox_div\">
  
  <label for='checkboxf'>رفع ملفات :</label>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"checkboxf\"  onclick='eo_upload_file()' type=\"checkbox\" name=\"checkboxf\"  value=\"\" >&nbsp;<font color=\"red\" ></font></span></span>

</div>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"  id='file_area' style='display:none;'>
  <span class=\"rnr-label\">إرفاق ملف :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"file\"   style=\"width: 200px;\" type=\"file\" name=\"file\"  value=\"\" >&nbsp;<font color=\"red\" ></font></span><button   class=\"rnr-button main\" id=\"eo_upload\"  name=\"eo_upload\" style=\"cursor: pointer;\" >إضافة</button> </span>

</div>

 


<hr id='hrr'>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"  id=\"left\">
  <span class=\"rnr-label\">التخصص :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"specialization\" name=\"specialization\" style=\"width: 207px\"><option value='$row[specialization]' selected hidden>$row[specialization]</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">تاريخ الدخول :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"date_of_entry\" style=\"width: 200px;\" type=\"date\" name=\"date_of_entry\"  value=\"$row[date_of_entry]\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"   id=\"left\">
  <span class=\"rnr-label\">الطبيب :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"doctor\" name=\"doctor\" style=\"width: 207px;\"><option value='$row[doctor]' selected hidden>$row[doctor]</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">نوع الدخول :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"entry_type\" name=\"entry_type\" style=\"width: 207px\"><option value='طوارئ'>طوارئ</option><option value='مباشر'>مباشر</option><option value='$row[entry_type]' selected hidden>$row[entry_type]</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>


 
<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"  id=\"left\">
  <span class=\"rnr-label\">اذن القبول :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"acceptance_permission\" style=\"width: 200px;\" type=\"text\" name=\"acceptance_permission\"  value=\"$row[acceptance_permission]\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">القسم :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"section\" name=\"section\" style=\"width: 207px\"><option value='1'>1</option><option value='2'>2</option><option value='3'>3</option><option value='4'>4</option><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8'>8</option><option value='9'>9</option><option value='10'>10</option><option value='11'>11</option><option value='وحدة الأطفال المبتسرين'>وحدة الأطفال المبتسرين</option><option value='عناية مركزة'>عناية مركزة</option><option value='عناية قلب مفتوح'>عناية قلب مفتوح</option><option value='وحدة الانجو'>وحدة الانجو</option><option value='$row[section]' selected hidden>$row[section]</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"  id=\"left\">
  <span class=\"rnr-label\">المعاملة المالية :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"financial_transaction\" name=\"financial_transaction\" style=\"width: 207px\"><option value='مجانى'>مجانى</option><option value='خاص'>خاص</option><option value='مستشفى'>مستشفى</option><option value='وزارة'>وزارة</option><option value='شركات'>شركات</option><option value='تأمين'>تأمين</option><option value='تأمين أطفال'>تأمين أطفال</option><option value='تأمين مواليد'>تأمين مواليد</option><option value='عاملين' disabled>عاملين</option><option value='$row[financial_transaction]' selected hidden>$row[financial_transaction]</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">الحجرة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"room\" name=\"room\" style=\"width: 207px\" disabled><option value='$row[room]' selected hidden>$row[room]</option><option value='1'>1</option><option value='2'>2</option><option value='3'>3</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>






<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"  id=\"left\">
  <span class=\"rnr-label\">اسم الكفيل :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"sponsor_name\" style=\"width: 200px;\" type=\"text\" name=\"sponsor_name\"  value=\"\" placeholder='Inactive ..... ' disabled>&nbsp;<font color=\"red\">*</font></span></span>
</div>


 

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">الدرجة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"grade\" name=\"grade\" style=\"width: 207px\"><option value='جناح'>جناح</option><option value='اولى ممتاز'>اولى ممتاز</option><option value='اولى عادى'>اولى عادى</option><option value='ثانية ممتاز'>ثانية ممتاز</option><option value='ثانية عادى'>ثانية عادى</option><option value='عناية مركزة'>عناية مركزة</option><option value='$row[grade]' selected hidden>$row[grade]</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"  id=\"left\">
  <span class=\"rnr-label\">منتفع بالتامين الصحي :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"health_insurance_beneficiary\" name=\"health_insurance_beneficiary\" style=\"width: 207px\"><option value='منتفع بالتامين'>منتفع بالتامين</option><option value='$row[health_insurance_beneficiary]' selected hidden>$row[health_insurance_beneficiary]</option><option value='غير منتفع بالتامين'>غير منتفع بالتامين</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">نتيجة العينة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"sample_result\" style=\"width: 200px;\" type=\"text\" name=\"sample_result\"  value=\"$row[sample_result]\"  placeholder='Inactive ..... ' disabled>&nbsp;<font color=\"red\">*</font></span></span>
</div>




 

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"   id=\"left\">
  <span class=\"rnr-label\">كود منشآة المسح :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"scan_facility_code\" style=\"width: 200px;\" type=\"text\" name=\"scan_facility_code\"  value=\"$row[scan_facility_code]\" placeholder='Inactive ..... ' disabled>&nbsp;<font color=\"red\">*</font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">المركز المحال اليه :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"referred_center\" style=\"width: 200px;\" type=\"text\" name=\"referred_center\"  value=\"$row[referred_center]\" placeholder='Inactive ..... ' disabled>&nbsp;<font color=\"red\">*</font></span></span>
</div>


















 



<hr>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1\"   id=\"left\">
  <span class=\"rnr-label\">حالة الملف :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"record_status\" name=\"record_status\" style=\"width: 207px\"  onfocusout=\"entry_type_validate()\"><option value='دخول' >دخول</option><option value='$row[record_status]'  selected hidden>$row[record_status]</option><option value='خروج' >خروج</option><option value='احاله' disabled>احاله</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1\" >
  <span class=\"rnr-label\">تم الاضافه بواسطة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[added_by]&nbsp;<font color=\"red\"></font></span></span>
</div>
<div class='exit_date_box' id='خروج'>
<div data-fieldname=\"Ticket\" class=\"rnr-field style1\"   id=\"left\">
  <span class=\"rnr-label\">نوع الخروج :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"exit_type\" name=\"exit_type\" style=\"width: 207px\"><option value='شفاء' >شفاء</option><option value='$row[exit_type]'  selected hidden>$row[exit_type]</option><option value='تحويل' >تحويل</option><option value='وفاة' >وفاة</option><option value='هروب'>هروب</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1\">
  <span class=\"rnr-label\">تم التعديل بواسطة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[last_edit_by]&nbsp;<font color=\"red\"></font></span></span>
</div>

<div class='exit_date_box' id='خروج'>
<div data-fieldname=\"Ticket\" class=\"rnr-field style1\"   id=\"left\">
  <span class=\"rnr-label\">تاريخ الخروج :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"exit_date\" style=\"width: 200px;\" type=\"date\" name=\"exit_date\"  value=\"$row[exit_date]\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1\">
  <span class=\"rnr-label\">تاريخ اخر تعديل :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[added_on]&nbsp;<font color=\"red\"></font></span></span>
</div>

<hr>



";

     
 


   }
}
else{
   echo "<p style='font-size: 30px; text-align:center;font-family: \"Reem Kufi\", sans-serif;' id='nonne'>لا يوجد ملفات تم ارفاقها</p>";
   

  }



 







?>




<div data-fieldname="Ticket" class="rnr-field style1 " hidden="hidden">
  
  <span class="rnr-control style3\"><span id="edit1_Ticket_0" class="rnr-nowrap"><input id="added_by" style="width: 200px;" type="text" name="added_by"  value="<?php echo $_SESSION['user'];?>"readonly>&nbsp;<font color="red">*</font></span></span>
</div>


<div data-fieldname="Ticket" class="rnr-field style1 " hidden="hidden">
  
  <span class="rnr-control style3\"><span id="edit1_Ticket_0" class="rnr-nowrap"><input id="last_edit_by" style="width: 200px;" type="text" name="last_edit_by"  value="<?php echo $_SESSION['user'];?>"readonly>&nbsp;<font color="red">*</font></span></span>
</div>


<div data-fieldname="Ticket" class="rnr-field style1" hidden="hidden">
 
  <span class="rnr-control style3"><span id="edit1_Ticket_0" class="rnr-nowrap"><input id="added_on" style="width: 200px;" type="text" name="added_on"  value=" <?php date_default_timezone_set('Africa/Cairo'); $timeee = date('d/m/Y, h:i:s A'); echo ($timeee);?>" readonly>&nbsp;<font color="red">*</font></span></span>
</div>






<!--
  



  





<div data-fieldname="SMS" class="rnr-field style1 ">
  <span class="rnr-label">SMS</span>
  <span class="rnr-control style3"><span id="edit1_SMS_0" class="rnr-nowrap"><input id="value_SMS_1" type="hidden" name="value_SMS_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_SMS_1_0" name="radio_SMS_1" value="1"> <span id="label_radio_SMS_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_SMS_1_1" name="radio_SMS_1" value="0"> <span id="label_radio_SMS_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="Ststus" class="rnr-field style1 ">
  <span class="rnr-label">Ticket Status</span>
  <span class="rnr-control style3"><span id="edit1_Ststus_0" class="rnr-nowrap"><select size="1" id="value_Ststus_1" name="value_Ststus_1" style="width: 207px"><option value="">Please select</option><option value="Open">Open</option><option value="Waiting For Response">Waiting For Response</option><option value="In-progress">In-progress</option><option value="Waiting For Customer">Waiting For Customer</option><option value="Call Back">Call Back</option><option value="Offline">Offline</option><option value="MSAN Replace">MSAN Replace</option><option value="Major Faults">Major Faults</option><option value="Internal Wiring Vendor Visit">Internal Wiring Vendor Visit</option><option value="Major Fault (Direct)">Major Fault (Direct)</option><option value="Engineering inspection ÊÝÊíÔ åäÏÓì">Engineering inspection ÊÝÊíÔ åäÏÓì</option></select>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="follow_process" class="rnr-field style1 ">
  <span class="rnr-label">Follow Process</span>
  <span class="rnr-control style3"><span id="edit1_follow_process_0" class="rnr-nowrap"><input id="value_follow_process_1" type="hidden" name="value_follow_process_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_follow_process_1_0" name="radio_follow_process_1" value="Yes"> <span id="label_radio_follow_process_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_follow_process_1_1" name="radio_follow_process_1" value="No"> <span id="label_radio_follow_process_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="on_shift" class="rnr-field style1 ">
  <span class="rnr-label">On Shift</span>
  <span class="rnr-control style3"><span id="edit1_on_shift_0" class="rnr-nowrap" style="display: none;"><input id="value_on_shift_1" type="hidden" name="value_on_shift_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_on_shift_1_0" name="radio_on_shift_1" value="1"> <span id="label_radio_on_shift_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_on_shift_1_1" name="radio_on_shift_1" value="0"> <span id="label_radio_on_shift_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="follow_up_time" class="rnr-field style1 ">
  <span class="rnr-label">Follow Date</span>
  <span class="rnr-control style3"><span id="edit1_follow_up_time_0" class="rnr-nowrap" style="display: none;"><input id="type_follow_up_time_1" type="hidden" name="type_follow_up_time_1" value="date11"><input id="value_follow_up_time_1" style="width: 200px;" type="Text" name="value_follow_up_time_1" value=""><input id="tsvalue_follow_up_time_1" type="Hidden" name="tsvalue_follow_up_time_1" value="0-0-0">&nbsp;<a href="#" id="imgCal_value_follow_up_time_1" data-icon="calendar" title="Click Here to Pick up the date"></a></span></span>
</div>

  
<div data-fieldname="follow_time" class="rnr-field style1 ">
  <span class="rnr-label">Follow Time</span>
  <span class="rnr-control style3"><span id="edit1_follow_time_0" class="rnr-nowrap" style="display: none;"><input id="type_follow_time_1" style="width: 200px;" type="hidden" name="type_follow_time_1" value="time"><input type="text" style="width: 200px;" name="value_follow_time_1" id="value_follow_time_1" value="">&nbsp;<a class="rnr-imgclock" data-icon="timepicker" title="Time" style="display: inline-block; margin: 4px 0px 0px 6px; visibility: visible;" id="trigger-test-value_follow_time_1"></a>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="Comment" class="rnr-field style1 ">
  <span class="rnr-label">Comment</span>
  <span class="rnr-control style3"><span id="edit1_Comment_0" class="rnr-nowrap"><textarea id="value_Comment_1" name="value_Comment_1" style="width: 200px;height: 100px;"></textarea></span></span>
</div>

  
<div data-fieldname="integration_problem" class="rnr-field style1 ">
  <span class="rnr-label">Integration Problem</span>
  <span class="rnr-control style3"><span id="edit1_integration_problem_0" class="rnr-nowrap"><input id="type_integration_problem_1" type="hidden" name="type_integration_problem_1" value="checkbox"><input id="value_integration_problem_1" type="Checkbox" name="value_integration_problem_1"></span></span>
</div>

  
<div data-fieldname="new_pilot" class="rnr-field style1 ">
  <span class="rnr-label">Valid for proactive concession</span>
  <span class="rnr-control style3"><span id="edit1_new_pilot_0" class="rnr-nowrap" style="display: none;"><select size="1" id="value_new_pilot_1" name="value_new_pilot_1" style="width: 207px"><option value="">Please select</option><option value="Yes">Yes</option><option value="No">No</option></select></span></span>
</div>

</div>
</div>
-->


<div class="rnr-brickcontents style2 rnr-b-addbuttons " id="newwbuttom"><div class="rnr-buttons-left">
    
  <!--
  <input type="submit" class="rnr-button main" name="update" id="update" value="Update">
  
 
  <input type="submit" class="rnr-button main" name="check" id="check" value="check" > 
  
  -->

  <button type="button" id="export_button" class="export_button">تصدير بيانات إلى Excel</button>&nbsp;<i class='fa fa-table' id="export_button2"></i>


  <a onclick="window.location.href=('eo_test2.php');"  style="cursor: pointer;" class="rnr-button"  name="back" id="backButton1">الرجوع</a>


 <?php  if (access('EO'  , false)): ?> 
<button   class="rnr-button main" id="viewbtn"   name="viewbtn" style="cursor: pointer; background-color: #d76666; color: black;">عرض</button>
<?php endif; ?>

 

<button   class="rnr-button main" id="editneweo"  name="editneweo" style="cursor: pointer;" >تعديل جديد</button>
  <!--
  <input type="submit" class="rnr-button main" name="delete" id="delete" style="position: relative; left: 70px;" value="Delete">
   -->


</div>
</div>


</div>
</div>

</div>



</form>

</div>




 <?php 

 if(isset($_POST['viewbtn'])){

         
  @$unique_id =$_GET['unique_id'];


           echo "<script> window.location.href=('../test3/view2_patient_eo_logs.php?unique_id=$unique_id');</script>";
           
        
  
}



 ?>



<?php




$unique_id =$_GET['unique_id'];

$query4 = "SELECT * FROM eo_uploaded_files WHERE unique_id='$unique_id' ";

$query_run4 = mysqli_query($conn, $query4);
if (mysqli_num_rows($query_run4) > 0 ) {
    # code...
   
    // code...


  echo "
  <hr>

<span style='text-align:center;justify-items: center;display: grid;font-family: \"Reem Kufi\", sans-serif; font-size:20px;'>ملفات تم ارفاقها</span>";


  while($row = $query_run4->fetch_assoc() ){
    echo "
<div class='sglat'>
<div data-fieldname=\"Ticket\" class=\"rnr-field style1\" dir='ltr'>
 
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><a href='uploads/eo_uploads/$row[file_Full_Name]' target=\"_blank\">$row[file_Full_Name]</a>&nbsp;&nbsp;&nbsp;<font color=\"red\"></font></span></span>&nbsp;&nbsp;&nbsp;&nbsp;<span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[added_by]</span>&nbsp;&nbsp;&nbsp;&nbsp;<span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[added_on]</span>
</div>

</div>

";
}

}
?>

  <?php


 




$unique_id =$_GET['unique_id'];

$query2 = "SELECT * FROM patient_eo_logs WHERE unique_id='$unique_id' ";
$query_run2 = mysqli_query($conn, $query2);
if (mysqli_num_rows($query_run2) > 0) {
    # code...



  echo "



<hr>
<span style='text-align:center;justify-items: center;display: grid;font-family: \"Reem Kufi\", sans-serif; font-size:30px;'>السجلات</span>
<hr>
<div id='divco'>
<table  id=\"myTable\" style=\"width:99.9%; font-size: 15px; font-family: sans-serif; \">
  <tr>


    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\">اسم المريض </th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>الرقم القومي</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>رقم هاتف المريض</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>تاريخ الميلاد</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>النوع</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th2\">الرقم الطبي</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>اسم المرافق</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>رقم هاتف المرافق</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>درجة قرابة المرافق</th>
    <th style=\"background-color :#1c562b; color:white;font-weight: normal;\" id=\"tht\">تاريخ الدخول</th>
    <th style=\"background-color :#721d1d; color:white;font-weight: normal;\" id=\"tht\">تاريخ الخروج</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th4\">نوع الدخول</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal;\" id=\"th5\">القسم</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" >الدرجة</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" >الطبيب</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" hidden>اذن القبول</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th9\">التخصص</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th10\">المعاملة المالية</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th11\">التامين</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th12\">حالة الملف</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" >نوع الخروج</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" >الاضافه</th>
    <th style=\"background-color :#2E2D2D; color:white;font-weight: normal; \" id=\"th1\" >التعديل</th>
    <th style='background-color :#2E2D2D; color:white;font-weight: normal;' id=\"th15\">تاريخ</th>

    


    
    
  </tr>



";




  while($row = $query_run2->fetch_assoc() ){
 
 


echo "<tr>";

      echo "<td>$row[patient_name]</td>";
        echo "<td hidden>$row[pa_national_id]</td>";
      echo "<td hidden>$row[pa_phone_num]</td>";
      echo "<td hidden>$row[date_of_birth]</td>";
      echo "<td hidden>$row[gender]</td>";
      echo "<td>$row[medical_number]</td>";
      echo "<td hidden>$row[sponsor_name]</td>";
      echo "<td hidden>$row[spo_phone_num]</td>";
      echo "<td hidden>$row[spo_degree_of_kinship]</td>";
      echo "<td style='font-size:10px;'>$row[date_of_entry]</td>";
      echo "<td style='font-size:10px;'>$row[exit_date]</td>";
      echo "<td>$row[entry_type]</td>";
      echo "<td>$row[section]</td>";
      echo "<td >$row[grade]</td>";
      echo "<td >$row[doctor]</td>";
      echo "<td hidden>$row[acceptance_permission]</td>";
      echo "<td>$row[specialization]</td>";
      echo "<td>$row[financial_transaction]</td>";
      echo "<td>$row[health_insurance_beneficiary]</td>";
      echo "<td>$row[record_status]</td>";
      echo "<td >$row[exit_type]</td>";

      echo "<td >$row[added_by]</td>";
      echo "<td >$row[last_edit_by]</td>";
      
      echo "<td style='font-size:10px;'>$row[added_on]</td>";
     

      
      
      
      
        //echo "<td>$row[ip]</td>";
      


      echo "</tr>";



echo " </div>";



}

$sql1 = " SELECT count(id) AS totalex FROM patient_eo_logs WHERE unique_id='$unique_id' AND record_status='خروج' ";
$sql2 = " SELECT count(id) AS totalet FROM patient_eo_logs WHERE unique_id='$unique_id' AND record_status='دخول' ";
$exresult =mysqli_query($conn , $sql1);
$etresult =mysqli_query($conn , $sql2);
$exvalues = mysqli_fetch_assoc($exresult);
$etvalues = mysqli_fetch_assoc($etresult);
$ex_num_rows =$exvalues['totalex'];
$et_num_rows =$etvalues['totalet'];
 echo  'حاله الملف /' . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'. 'خروج :' . $ex_num_rows . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'. 'دخول :' . $et_num_rows ;

 


   }


    ?>


 <footer class="custom-footer">
      <?php
      $end_time = microtime(TRUE);
      $time_taken = $end_time - $start_time;
      $total_time = round($time_taken, 4);
      ?>
      <p>
        <span class="description">⏱️ Render:</span>
        <span class="result"><?php echo $total_time; ?> sec</span>
      </p>
      <p>&copy; 2023 M_G_X. All rights reserved.</p>
    </footer>

  
</div>

<script type="text/javascript">
  

$('option[value='وجه و فكين']').attr('disabled', 'disabled');
$('option[value='العيادات المسائية']').attr('disabled', 'disabled');
$('option[value='قلب مفتوح']').attr('disabled', 'disabled');
 


</script>


<?php

 



if (@$_SESSION['type']=='admin' ) {

        echo "<script>document.getElementById('unique_id').style.backgroundColor = '#081a36';</script>";

         echo "<script>document.getElementById('added_by').style.backgroundColor = '#bfdeef';</script>";
          echo "<script>document.getElementById('last_edit_by').style.backgroundColor = '#bfdeef';</script>";
           echo "<script>document.getElementById('added_on').style.backgroundColor = '#bfdeef';</script>";
 
        echo "<script>document.getElementById('neww').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('heed').style.boxShadow = '3px 3px 50px 3px #21478b';</script>";
        echo "<script>document.getElementById('heed').style.textShadow = '8px 6px 8px #143970';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#081a36';</script>";

       
         include 'edit2_patient_eo_script.php';
         include 'edit2_patient_logs_script.php';
         include 'eo_uploads_script.php';
 





  }elseif (@$_SESSION['type']=='it_user' || @$_SESSION['type']=='ad_it_user') {

      
  echo "<script>document.getElementById('unique_id').style.backgroundColor = '#15483f';</script>";
 
        echo "<script>document.getElementById('added_by').style.backgroundColor = '#799f96';</script>";
        echo "<script>document.getElementById('last_edit_by').style.backgroundColor = '#799f96';</script>";
        echo "<script>document.getElementById('added_on').style.backgroundColor = '#799f96';</script>";

        echo "<script>document.getElementById('neww').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('heed').style.boxShadow = '3px 3px 50px 3px #15483f';</script>";
        echo "<script>document.getElementById('heed').style.textShadow = '8px 6px 8px #15483f';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#15483f';</script>";
         include 'edit2_patient_eo_script.php';
         include 'edit2_patient_logs_script.php';
         include 'eo_uploads_script.php';
 

     
  }elseif (@$_SESSION['type']=='eo_user') {

      
  echo "<script>document.getElementById('unique_id').style.backgroundColor = '#1c2827';</script>";
 
        echo "<script>document.getElementById('added_by').style.backgroundColor = '#799f96';</script>";
        echo "<script>document.getElementById('last_edit_by').style.backgroundColor = '#799f96';</script>";
        echo "<script>document.getElementById('added_on').style.backgroundColor = '#799f96';</script>";

        echo "<script>document.getElementById('neww').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('heed').style.boxShadow = '3px 3px 50px 3px #1c2827';</script>";
        echo "<script>document.getElementById('heed').style.textShadow = '8px 6px 8px #1c2827';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#1c2827';</script>";
         include 'edit2_patient_eo_script.php';
         include 'edit2_patient_logs_script.php';
         include 'eo_uploads_script.php';
 

     
  }elseif (@$_SESSION['type']=='eo_viewer') {

      
  echo "<script>document.getElementById('unique_id').style.backgroundColor = 'gray';</script>";
 
        echo "<script>document.getElementById('neww').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = 'gray';</script>";
     
  }else{
            echo "<script>function(){ history.back(); }</script>";
  }


?>
 