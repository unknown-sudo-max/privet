
  <!-- Header -->
<?php 
$start_time = microtime(TRUE);
require_once('header.php');
// include 'access.php';
access('AIT');

?>
<!-- End page content -->
<link rel="stylesheet" href="cdn/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
 <script type="text/javascript" src="cdn/xlsx.full.min.js"></script>
 <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script src="cdn/dd9c95f04f.js" crossorigin="anonymous"></script>

<script type="text/javascript">

//   $(document).ready(function(){

// //Using setTimeout to execute a function after 5 seconds.
// setTimeout(function () {
//    //Redirect with JavaScript
//    window.history.pushState("/test2.php", "", '/test3/test2.php');
// }, 0);


// window.scrollTo(1000,0);

// });

 
  $(document).ready(function(){


 var apacheportContent = document.getElementById("apacheport-content");
      apacheportContent.classList.add("hidden");
var atriangleIcon = document.querySelector("#apacheport-heading .triangle");
 atriangleIcon.classList.toggle("rotate");





var userManagementContent = document.getElementById("UserManagement-content");
userManagementContent.classList.toggle("hidden");
var utriangleIcon = document.querySelector("#UserManagement-heading .triangle");
 utriangleIcon.classList.toggle("rotate");

  
  var backupsContent = document.getElementById("Backups-content");
  backupsContent.classList.toggle("hidden");
    var btriangleIcon = document.querySelector("#Backups-heading .triangle");
     btriangleIcon.classList.toggle("rotate");


      var emailConfigurationContent = document.getElementById("EmailConfiguration-content");
      emailConfigurationContent.classList.toggle("hidden");
    var etriangleIcon = document.querySelector("#EmailConfiguration-heading .triangle");
     etriangleIcon.classList.toggle("rotate");
    

 


 function html_table_to_excel(type)
    {
        var data = document.getElementById('myTable');

        var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

        XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

        XLSX.writeFile(file, 'All patient in DB file.' + type);
    }

    const export_button = document.getElementById('export_button');

    export_button.addEventListener('click', () =>  {
        html_table_to_excel('xlsx');
    });


});
 
  

</script>
<style>
.hidden {
      display: none;
    }


    .triangle {
    display: inline-block;
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 5px 5px 0 5px;
    border-color: #000000 transparent transparent transparent;
    margin-right: 10px;
    transition: transform 0.3s;
  }

  .rotate {
    transform: rotate(-90deg);
  }

   

* {box-sizing: border-box;}

body{ 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    

}
/*
body::before { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    content: "";
      background-image: url('pngegg.png');
      background-size: cover;
      position: absolute;
      top: 0px;
      right: 0px;
      bottom: 0px;
      left: 0px;
      opacity: 0.10;
      z-index: -1;
}
 */
#navbar {
  overflow: hidden;
  background-color: #9f8398;
  padding: 90px 10px;
  transition: 0.4s;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 99;

}

#navbar a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;

}
ul{

  list-style-image: url('fas fa-folder-open');
}
#navbar #logo {
  font-size: 35px;
  font-weight: bold;
  transition: 0.4s;

}

#navbar a:hover {
  background-color: #b99fb2;
  color: black;
}

#navbar a.active {
  background-color: #7d1d64;
  color: white;
}

#navbar-right {
  float: right;
  padding: 12px;
}

 
.container a {
  
  display: block;
  color: black;
  text-align: left;
  padding: 10px;
  
  font-size: 17px;
  list-style-image: url('sqpurple.gif');
}

.container a:hover {
  background-color: #ddd;
  color: black;
  border-radius: 5px;
  padding: 8;
  margin: 4;
  opacity: 0.5;

}

.container a.active {
  background-color: #2196F3;
  color: white;
  

}

.container{
float: left;
text-align: left;
position: absolute;
left: 1%;
width: 70%;

}

.list{
  width: 100%;
  align-items: left;

}

.ifrm{
  width: 100%;
  height: 100%;
  border: none;
}


.list li {
  list-style-type: 'fas fa-folder-open';
  list-style-type: '📂 ';
}

.logo{

  //display: block;
  position: relative;
  float: right;
  left:  -30px;
  width: 20%;
  height: 27%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}

.cpr{

/*  padding: 12px;
  margin: 12px;
  position: absolute;*/

  text-align: center;
 cursor: not-allowed;
/*  top: 84%;
  left: 30%;*/
  
}
 
details > summary {
  list-style: none;
}



.navbarh {
  overflow: hidden;
  background-color: #333;
}

.navbarh a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}


.navbarh span {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;

}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}



.export_button {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  cursor: pointer;
  
  background-color: inherit;
  font-family: inherit;
  margin: 0;
   
}

.export_button:hover {
  background-color: red;
}

.navbarh a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
@media screen and (max-width: 580px) {
  #navbar {
    padding: 20px 10px !important;
  }
  #navbar a {
    float: none;
    display: block;
    text-align: left;
  }
  #navbar-right {
    float: none;
  }


details > summary {
  list-style: none;
}





  @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){
.navbarh{
    width: 120%;
    position: relative;
    top: 20px;

  }
#navbarv{
    width: 70%;
    position: relative;
  }
  }



 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){
.navbarh{
    width: 120%;
    position: relative;
    top: 20px;

  }

  #navbarv{
    width: 70%;
    position: relative;
  }
   h4{
    top: 75px;
    position: relative;
  }


}


@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){

  .navbarh{
    width: 130%;
    position: relative;
    top: 75px;
    height: 150px;

  }

  h4{
    top: 75px;
    position: relative;
  }

  #navbarv{
    width: 80%;
    position: relative;
  }

    #divco{
    overflow: scroll;
    width: 140%;
    position: relative;
  }

}

</style>



<div class="container" style="float: left" dir="ltr">

<h4 style="font-family: 'Carattere', cursive; font-size: 30px;">IT-_-List</h4>
 
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="path/to/your/bootstrap.css"> <!-- Replace with the path to your Bootstrap CSS file -->
  <style>
    /* Custom styles */
    .custom-heading {
      margin-top: 2rem;
    }

    .custom-footer {
      color: #554949;
      font-size: 13px;
      margin-top: 2rem;
    }

    .card-title {
      background-color: #f8f9fa;
      padding: 10px;
    }
  </style>
  <title>Configuration Management</title>
</head>

<body>
  <div class="container">
    <h1 class="custom-heading">Configuration Management</h1>
    <hr>

    <div class="card" style="width: 80%;">
      <div class="card-body">
        <h2 class="card-title">General Info</h2>
        <!-- General settings form -->
        <form class="tableform">
        
   <style>
  /* Custom CSS styles */
  .custom-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    background-color: #f5f5f5;
    color: #333;
    font-size: 14px;
  }

  .custom-table th,
  .custom-table td {
    padding: 10px;
    border: 1px solid #ddd;
  }

  .custom-table th {
    background-color: #e7e7e7;
    font-weight: bold;
  }

  .custom-table tbody tr:nth-child(even) {
    background-color: #f9f9f9;
  }


  .tableform{

      border-radius: 6px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  }
</style>

<table class="custom-table">
  <tr>
    <th>System Name:</th>
    <td><span id="systemNameSpan"></span></td>
  </tr>
  
  <tr>
    <th>System Version:</th>
    <td><span id="systemVersionSpan"></span></td>
  </tr>
  <tr>
    <th>Language:</th>
    <td><span id="systemLanguageSpan"></span></td>
  </tr>
  <tr>
    <th>Theme/Appearance:</th>
    <td><span id="systemThemeSpan"></span></td>
  </tr>
  <tr>
    <th>Required RAM:</th>
    <td><span id="systemRequiredRamSpan"></span></td>
  </tr>
  <tr>
    <th>Users Limit:</th>
    <td><span id="systemUserslimitSpan"></span></td>
  </tr>
  <tr>
    <th>Server Software:</th>
    <td><span id="systemServerSoftwareSpan"><?php $apacheName = $_SERVER['SERVER_SOFTWARE']; echo $apacheName; ?></span></td>
  </tr>
  <tr>
    <th>Operating System:</th>
    <td><?php $operatingSystem = php_uname('s'); echo $operatingSystem; ?></td>
  </tr>
  <tr>
    <th>Browser User Agent:</th>
    <td><?php $userAgent = $_SERVER['HTTP_USER_AGENT']; echo $userAgent; ?></td>
  </tr>
  <tr>
    <th>Server Protocol:</th>
    <td><?php $serverProtocol = $_SERVER['SERVER_PROTOCOL']; echo $serverProtocol; ?></td>
  </tr>
  <tr>
    <th>Server Port:</th>
    <td><?php $serverPort = $_SERVER['SERVER_PORT']; echo $serverPort; ?></td>
  </tr>
  <tr>
    <th>Recommended Apache Port:</th>
    <td>8080</td>
  </tr>
  <tr>
    <th>Apache Port:</th>
    <td><?php
// Apache configuration file path
$httpdConfPath = 'D:/xampp/apache/conf/httpd.conf';

// Read the Apache configuration file
$httpdConfContent = file_get_contents($httpdConfPath);

// Find the Listen directive in the configuration file
$listenPattern = '/Listen\s+(\d+)/i';
if (preg_match($listenPattern, $httpdConfContent, $matches)) {
  // Extract the port value from the matched pattern
  $apachePort = $matches[1];
  echo "$apachePort";
} else {
  echo 'Failed to retrieve Apache port.';
}
?>
</td>
  </tr>
  <tr>
    <th>XAMPP Version:</th>
    <td>
      <?php
      // XAMPP Version
      $versionFile = '..\xampp\.version';

      if (file_exists($versionFile)) {
          $xamppVersion = file_get_contents($versionFile);
          echo $xamppVersion;
      } else {
          echo "XAMPP version file not found.";
      }
      ?>
    </td>
  </tr>
  <tr>
    <th>System Logo:</th>
    <td><span id="systemLogoSpan"></span></td>
  </tr>
   
</table>


 


        


          <!-- Additional general settings fields -->
          <!-- ... -->
        </form>
      </div>
    </div>

    <h2 id="UserManagement-heading" onclick="toggleUserManagementContent()" ><span class="triangle"></span>User Management</h2>


    <div id="UserManagement-content">
    <!-- User management settings form -->
    <form>

      <!-- User management settings fields -->
      <!-- ... -->
    </form>

</div>



<style>
     
    h2 {
      color: #333;
      margin-top: 20px;
      cursor: pointer;
      user-select: none;

      
    }

    .portForm {
      max-width: 300px;
       
      padding: 20px;
      background-color: #fff;
      border-radius: 6px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .newportlb {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .portInput {
      padding: 10px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 4px;
      width: 100%;
      margin-bottom: 10px;
      box-sizing: border-box;
    }

    .portInput:focus {
      border-color: #4CAF50;
      outline: none;
    }

    .Portbtn{
       padding: 12px 24px;
  font-size: 16px;
  background-color: #337ab7;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
    }

    .Portbtn:hover {
      background-color: #23527c;
          }
  </style>

     <h2 id="apacheport-heading" onclick="toggleApachePortContent()" ><span class="triangle"></span>Apache Port Configuration</h2>


<div id="apacheport-content">
  <form id="portForm" class="portForm">
    <label for="portInput" class="newportlb">New Port:</label>
    <input type="text" id="portInput" placeholder="Enter port number" class="portInput">
    <button type="submit" class="Portbtn">Change Port</button>
  </form>

  <script>
    $(document).ready(function() {



      $('#portForm').submit(function(e) {
        e.preventDefault();
        var newPort = $('#portInput').val();

        $.ajax({
          url: 'changeport.php',
          method: 'POST',
          data: { port: newPort },
          success: function(response) {
            alert(response);
          },
          error: function(xhr, status, error) {
            alert('Error: ' + error);
          }
        });
      });
    });


     function toggleApachePortContent() {
    var apacheportContent = document.getElementById("apacheport-content");
    var atriangleIcon = document.querySelector("#apacheport-heading .triangle");
    
    apacheportContent.classList.toggle("hidden");
    atriangleIcon.classList.toggle("rotate");
  }



   function toggleUserManagementContent() {
    var userManagementContent = document.getElementById("UserManagement-content");
    var utriangleIcon = document.querySelector("#UserManagement-heading .triangle");
    
    userManagementContent.classList.toggle("hidden");
    utriangleIcon.classList.toggle("rotate");
  }




   function toggleBackupsContent() {
    var backupsContent = document.getElementById("Backups-content");
    var btriangleIcon = document.querySelector("#Backups-heading .triangle");
    
    backupsContent.classList.toggle("hidden");
    btriangleIcon.classList.toggle("rotate");
  }



   function toggleEmailConfigurationContent() {
    var emailConfigurationContent = document.getElementById("EmailConfiguration-content");
    var etriangleIcon = document.querySelector("#EmailConfiguration-heading .triangle");
    
    emailConfigurationContent.classList.toggle("hidden");
    etriangleIcon.classList.toggle("rotate");
  }


 
  </script>

</div>

     <style>
    

    h2 {
      color: #333;
      margin-top: 20px;
       
      user-select: none;
    }

    .backupsform {
      max-width: 300px;
     
      padding: 20px;
      background-color: #fff;
      border-radius: 6px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

   .checkbox-group {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
}

.checkbox-group input[type="checkbox"] {
  margin-right: 8px;
}

.databaseSelectlabel {
  display: block;
  margin-bottom: 12px;
  font-weight: bold;
  color: #555;
}

.databasesselect {
  padding: 10px;
  font-size: 14px;
  border: 1px solid #ccc;
  border-radius: 4px;
  width: 100%;
  margin-bottom: 15px;
  box-sizing: border-box;
  background-color: #f5f5f5;
  color: #333;
}

.databaseExportbtn {
  padding: 12px 24px;
  font-size: 16px;
  background-color: #337ab7;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.databaseExportbtn:hover {
  background-color: #23527c;
}

  </style>
 
  <h2 id="Backups-heading" onclick="toggleBackupsContent()"><span class="triangle"></span>Backups</h2>

  <div id="Backups-content">
    <form method="post" action="backups.php"  class="backupsform">
      <label for="databaseSelect" class="databaseSelectlabel">Select Database:</label>
      

        
    <?php
// Your database connection details
$host = "localhost";
$username = "root";
$password = "";

// Create a connection to the MySQL server
$conn = mysqli_connect($host, $username, $password);

// Retrieve a list of databases
$result = mysqli_query($conn, "SHOW DATABASES");

echo '<select class="databasesselect" name="databases[]">';

// Loop through each database
while ($row = mysqli_fetch_assoc($result)) {
    $database = $row['Database'];
    echo '<option value="' . $database . '">' . $database . '</option>';
}

// Add "Select All Databases" option
echo '<option value="select_all">Select All Databases</option>';

echo '</select>';

// Close the database connection
mysqli_close($conn);
?>

    <br><br>

    <button type="submit"  name="export" class="databaseExportbtn">Export</button>
    </form>
  </div>
    

 


    <h2 id="EmailConfiguration-heading" onclick="toggleEmailConfigurationContent()" ><span class="triangle"></span>Email Configuration</h2>

    <div id="EmailConfiguration-content">
    <!-- Email configuration settings form -->
    <form>
      <!-- Email configuration settings fields -->
      <!-- ... -->
    </form>

  </div>

    <!-- Additional sections for Database Configuration, Logging and Error Handling, Security Settings, etc. -->

    <script>
      // Add your JavaScript logic here
      // Set the system name and version dynamically
      document.getElementById('systemNameSpan').innerText = 'MedHub Pro - Hospital Hub Central ( HHC )';
      document.getElementById('systemVersionSpan').innerText = '1.0.73';
      document.getElementById('systemLanguageSpan').innerText = 'English & Arabic ';
      document.getElementById('systemThemeSpan').innerText = 'Light 🌤️';
      document.getElementById('systemRequiredRamSpan').innerText = '64GB';
      document.getElementById('systemUserslimitSpan').innerText = 'Open ✅';

    


// Create a new img element
var imgElement = document.createElement('img');
imgElement.src = './img/medhub.png';
imgElement.alt = 'MedHub Pro - HHC';
imgElement.style.width = '98%';
imgElement.draggable = false;

// Get the span element
var spanElement = document.getElementById('systemLogoSpan');

// Clear existing content of the span
spanElement.innerHTML = '';

// Append the img element to the span
spanElement.appendChild(imgElement);
    </script>

    <hr>
    <footer class="custom-footer">
      <?php
      $end_time = microtime(TRUE);
      $time_taken = $end_time - $start_time;
      $total_time = round($time_taken, 4);
      ?>
      <p>
        <span class="description">⏱️ Render:</span>
        <span class="result"><?php echo $total_time; ?> sec</span>
      </p>
      <p>&copy; 2023 M_G_X. All rights reserved.</p>
    </footer>
  </div>
</body>

</html>


  
</body>
</html>


<?php
// Function to format bytes to human-readable format
function formatBytes($bytes, $decimals = 2) {
    $size = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    $factor = floor((strlen($bytes) - 1) / 3);
    return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . ' ' . $size[$factor];
}
?>






<!-- M_G_X Container -->

<!-- <div class="cpr">

<details style="float: center;">
<summary style="scale:120px right;">
  <u style="color:gray;">
    جميع الحقوق محفوظة © 2022-2023
</u>
</summary>
  <p> * Powered BY <a target="_top" disabled="" style="color: gray; cursor: pointer;"><u>MG</u></a>*</p>

</details>
</div> -->


<?php








if (@$_SESSION['type']=='admin' ) {

        echo "<script>document.getElementById('navbarh').style.backgroundColor = '#081a36';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#081a36';</script>";
        echo "<script>
                       document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                       document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                       function mouseEnter() {
                         document.getElementById('tr').style.backgroundColor = '#9ab3cd';
                       }

                       function mouseLeave() {
                         document.getElementById('tr').style.backgroundColor = '';
                       }
            </script>";






  }elseif (@$_SESSION['type']=='it_user' || @$_SESSION['type']=='ad_it_user') {

      
  echo "<script>document.getElementById('navbarh').style.backgroundColor = '#15483f';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#15483f';</script>";
        echo "<script>
                      document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                      document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                      function mouseEnter() {
                        document.getElementById('tr').style.backgroundColor = '#7e9996';
                      }

                      function mouseLeave() {
                        document.getElementById('tr').style.backgroundColor = '';
                      }
              </script>";


     
  }else{
            echo "<script>function(){ history.back(); }</script>";
  }


?>
