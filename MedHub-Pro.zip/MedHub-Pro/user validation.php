<?php




if(isset($_POST['submit'])){





//////////////////////////////first phase//////////////////////////////


 $user = $_POST['user'];


$error2 = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid User</n><br><k>This User Are Not Exsit in Our DataBase  , So  refer to your Adminstrator</k><div>";

$query1 = "SELECT * FROM users WHERE user='$user'";
$result = mysqli_query($conn, $query1 );
$count = mysqli_num_rows($result);
if ($count>0) {



//$_SESSION['user'] = $_POST['user'];



////////////////////////////////////////////////////second phase/////////////////////
$user = $_POST['user'];
$pass = $_POST['pass'];

$error = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid Login</n> ' $user '<br><k>Check your password again , OR refer to your Adminstrator</k><div>";
$success = "";

$query = "SELECT * FROM users WHERE user='$user' AND pass='$pass'";
$result = mysqli_query($conn, $query );

/*
$count = mysqli_num_rows($result);
if ($count>0) {
    # code...
    header("Location: Avaya_vaildation.php");
}
else{
            $error = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid Login</n><br><k>Check your password again , OR refer to your Adminstrator</k><div>";
            $success = "";
            echo "<br><br> <br> $error";

            

 
        }
        */








// $arr['user'] = $_POST['user'];
// $arr['pass'] = $_POST['pass'];
// $arr['type'] = $_POST['type'];

// $sstm = $conn->prepare($query );


// if ($sstm) {

//     $ccheck = $sstm->execute($arr)

//     if ($ccheck) {
//         $dataa = $sstm->fetchAll(PDO::FETCH_ASSOC);
//         if (is_array($dataa) && count($dataa) > 0 ) {
//             $_SESSION['user'] = $dataa[1]['name'];
//         }
//     }
   

// }







//session_start();

        ////////////////////




$row = mysqli_fetch_array($result);
if (@$row['type']=='admin' || @$row['type']=='ad_it_user' || @$row['type']=='it_user' || @$row['type']=='hr_user' || @$row['type']=='eo_user' || @$row['type']=='acc_user' || @$row['type']=='acc_viewer' || @$row['type']=='hr_viewer' || @$row['type']=='eo_viewer' ) {
                # code...





   @session_start();

   // $_SESSION['user'] = $_POST['user'];



     $_SESSION['user'] = $row['name'];
     $_SESSION['userid'] = $row['user'];
     $_SESSION['type'] = $row['type'];




          

                echo "<script> window.location.href=('main_test2.php');</script>
                 
                 

                ";
                 
                
                
            }
else if (@$row['type']=='User' ) {
                # code...

    session_unset();
 @session_start();
             $_SESSION['user'] = $_POST['user'];

                echo "<script> window.location.href=('Avaya__vaildation1.php');</script>";
                        
                
            }
            else{

                 // session_unset();
            
            echo "<br><br> <br> $error";
               
       
            

 
        }


/////////////////////////////////










/*
        while ($row = mysqli_fetch_array($result)) {
            # code...

            if ($row['user']==$user && $row['pass']==$pass && $row['type']=='Admin' ) {
                # code...



                echo "<script> window.location.href=('Avaya__vaildation1.php');</script>";
                
                
            }
            if ($row['user']==$user && $row['pass']==$pass && $row['type']=='User' ) {
                # code...
                 echo "<script> window.location.href=('Avaya_vaildation.php');</script>";
            }




            else{
            
            echo "<br><br> <br> $error";

            

 
        }
        
        








}
*/

////////////////////////////////////////////////////second phase/////////////////////





}

else{

    //session_unset();
            $error2 = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid User </n>'$user' <br><k>This User Are Not Exsit in Our DataBase  , So  refer to your Adminstrator</k><div>";



            
            echo "<br><br> <br> $error2";
            exit();
         session_unset();


             

 }


//////////////////////////////first phase//////////////////////////////




}



?>