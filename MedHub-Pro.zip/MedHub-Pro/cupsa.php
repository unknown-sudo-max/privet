 <?php
  require_once  'access.php';

      if (access('IT' , false)): ?>


<?php

require_once 'connect.php';


if(isset($_POST['change'])){





 // $_SESSION['user'] = $_POST['user'];

// $user = $_SESSION['user'];




    //////////////////////////////first phase//////////////////////////////


$user = $_POST['user'];


$error2 = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid User</n><br><k>This User Are Not Exsit in Our DataBase  , So  refer to your Adminstrator</k><div>";

$query1 = "SELECT * FROM users WHERE user='$user'";
$result = mysqli_query($conn, $query1 );
$count = mysqli_num_rows($result);
if ($count>0) {



















////////////////////////////////////////////////////second phase/////////////////////







if (!empty($_POST['user']) && !empty($_POST['npass'])) {

    # code...

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
@$user       = strip_tags($_POST['user']);
@$npass      = strip_tags($_POST['npass']);
@$addedon    = strip_tags($_POST['addedon']);




$sql= "UPDATE users set  pass='$npass', date='$addedon' WHERE user='$user' ";

}

//$sql= "UPDATE records set  fullname='$_POST[fullname]', pcuser='$_POST[pcuser]', pcpass='$_POST[pcpass]', login='$_POST[login]', shifttime='$_POST[shifttime]', sitestatus='$_POST[sitestatus]', arrivalstatus='$_POST[fullname]', recordstatus='$_POST[recordstatus]', comment='$_POST[comment]', shiftondate='$_POST[arrivalstatus]', addedon='$_POST[addedon]' WHERE id='$_POST[id]' ";




if (mysqli_query($conn, $sql)) {

    # code...

    echo "<p style='color:green; font-size:15px;'>The User Updated Successfully</p>";
}
    else{

        echo "<p style='color:red; font-size:15px;'>Failed TO Updated The User !!!</p>";
        echo mysql_error();
    }

mysqli_close($conn);

}
else{
    echo "<p style='color:red; font-size:15px;'>The  ..<u style='font-weight:  bold;'>' User & New Pass '</u>   
      .. Fields Are Required !!! </p>";
}



















////////////////////////////////////////////////////second phase/////////////////////




}

else{
            $error2 = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid User </n> ' $user '<br><k>This User Are Not Exsit in Our DataBase  , So  refer to your Adminstrator</k><div>";
            
            echo "<br><br> <br> $error2";

            

 }








    //////////////////////////////first phase//////////////////////////////


}

?>
<?php endif;?>