
<?php 
$start_time = microtime(TRUE);
require_once('header.php');
// include 'access.php';
access('EO');

  
 
?>
 

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="ircss.css">
<link rel="stylesheet" href="cdn/font-awesome.min.css">
<!-- <link rel="stylesheet" href="cdn/AdminLTE.min.css">
<link rel="stylesheet" href="cdn/bootstrap.min.css">
<link rel="stylesheet" href="cdn/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="cdn/select2.min2.css">
<link rel="stylesheet" href="cdn/GE_font.ttf"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>



<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>




<script type="text/javascript">

 


$(document).ready(function() {
    // body...




$('#specialization').on('change', function () {

        let val = $('#specialization').val();

        console.log(val);

        if (val == 'وجه و فكين' || val == 'قلب مفتوح') {
            $('#doctor').attr('disabled', true);
        } else {
            $('#doctor').attr('disabled', false);
        }
    })
 




 

var now = new Date();
 
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear()+"-"+(month)+"-"+(day) ;


   $('#date_of_entry').val(today);



///////////M_G_X_ORIGINALS/////////////////////////////


   $("#spo_degree_of_kinship").on('change', function(){


 

  $(".spo_degree_of_kinship_box").hide();
  // $("#exit_date").val('');
  $("#" + $(this).val()).fadeIn(700);
 
}).change();


if(isset($_POST['addneweo'])){

if ($('#spo_degree_of_kinship2').val() == '') {
  
  document.getElementById("spo_degree_of_kinship2").disabled = true;
  document.getElementById("أخري").remove();

} else{
   
   document.getElementById("spo_degree_of_kinship2").disabled = false;
}


}






});

  

///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
 
function fill_data() {




  // disabled option in specialization
$("option[value='وجه و فكين']").attr('disabled', 'disabled');
$("option[value='العيادات المسائية']").attr('disabled', 'disabled');
$("option[value='قلب مفتوح']").attr('disabled', 'disabled');
$("option[value='العيادات المسائية']").css("font-weight", "bold"); 
 
var now = new Date();
var this_year = now.getFullYear();
var month = ("0" + (now.getMonth() + 1)).slice(-2);
var day = ("0" + now.getDate()).slice(-2);
var st_year = this_year.toString();
var last_two_dig_of_year = st_year[2]+st_year[3];
var pa_national_id = $('#pa_national_id').val();
var national_id = pa_national_id.toString();
var select_gender = national_id[12];
var select_century = national_id[0];
var select_birthdate = national_id[1]+national_id[2]+'-'+national_id[3]+national_id[4]+'-'+national_id[5]+national_id[6];
var select_birthmonth = national_id[3]+national_id[4];
var select_birthday = national_id[5]+national_id[6];
var select_year_of_birth = national_id[1]+national_id[2];
var age_last_century = (this_year+month+day)- ("19"+select_year_of_birth+select_birthmonth+select_birthday);
var st_age_last_century = age_last_century.toString();

var age_this_century = (this_year+month+day)- ("20"+select_year_of_birth+select_birthmonth+select_birthday);
var st_age_this_century = age_this_century.toString();

if (pa_national_id == '') {

  alert('من فضلك قم بإدخال الرقم القومى !');
  exit();
}




if (select_century == '2') {

$('#date_of_birth').val("19"+select_birthdate);
$('#age').html(st_age_last_century[0]+st_age_last_century[1]+ '&nbsp;'+'عام');



}else if (select_century == '3') {

  $('#date_of_birth').val("20"+select_birthdate);
  $('#age').html(st_age_this_century[0]+st_age_this_century[1]+ '&nbsp;'+'عام');

}else if (select_century < '2') {

alert('الرقم القومي الذي تم ادخالة غير صحيح, او من المحتمل ان يكون ذالك الشخص ميتاً اصلاً , واللهي حرام الي بيحصل فينا دة يا عم , حاول مرة أخرى !');
$('#gender').val("");
$('#pa_national_id').val("");
$('#date_of_birth').val("");
$('#age').html('');
exit();
}else if (select_century > '3') {

alert('الرقم القومي الذي تم ادخالة غير صحيح, لأن ذالك الشخص لم يولد بعد , حاول مرة أخرى !');
$('#gender').val("");
$('#pa_national_id').val("");
$('#date_of_birth').val("");
$('#age').html('');
exit();
}else{


alert('الرقم القومي الذي تم ادخالة غير صحيح , حاول مرة أخرى !');
exit();
}
 



 
 



if (select_century == '3' && select_year_of_birth > last_two_dig_of_year) {

  alert('الرقم القومي الذي تم ادخالة غير صحيح, لأن ذالك الشخص لم يولد بعد انت فاهم انت بتقول اية !! دة كدة مواليد : '+ '20'+select_year_of_birth+ ' , يا عم بقي مش كدة ارحمونا بقي شوية , حاول مرة أخرى !');
$('#gender').val("");
$('#pa_national_id').val("");
$('#date_of_birth').val("");
exit();


}



if (select_gender == '1' || select_gender == '3' || select_gender == '5' || select_gender == '7' || select_gender == '9') {

  $('#gender').val("ذكر");
  

}else if (select_gender == '0' || select_gender == '2' || select_gender == '4' || select_gender == '6' || select_gender == '8'){


$('#gender').val("انثى");
}else{
  alert('الرقم القومي الذي تم ادخالة غير صحيح , حاول مرة أخرى !');
  $('#age').html('');
  $('#pa_national_id').val("");
  exit();
}


///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////

///////////M_G_X_ORIGINALS/////////////////////////////


}





 function eo_upload_file() {
  var checkBox = document.getElementById("checkboxf");
  var div5 = document.getElementById("file_area");
  
  

  if (checkBox.checked == true){
   $(div5).fadeIn(900);
   div5.style.display = "block";

   
  } else {
     $(div5).fadeOut(900);
     div5.style.display = "none";
  }
}


///////////M_G_X_ORIGINALS/////////////////////////////


function spo_degree_of_kinship_validate() {


  const spo_degree_of_kinship2 = document.getElementById('spo_degree_of_kinship2');
  const spo_degree_of_kinship = document.getElementById('spo_degree_of_kinship');

 if ($('#spo_degree_of_kinship').val() != 'أخري') {
 



spo_degree_of_kinship2.setAttribute('name', 'example-name');
spo_degree_of_kinship.setAttribute('name', 'spo_degree_of_kinship');

}else{

  

spo_degree_of_kinship2.setAttribute('name', 'spo_degree_of_kinship');
spo_degree_of_kinship.setAttribute('name', 'example-name');
}
}
 





var subjectObject = {
  //1- batna
  "باطنة": {
    "هشام عبد الحميد":[],
    "محمود رجب":[],
    "جورج فاروق":[],
    "جمال العطار":[],
    "عمر عبد السلام":[]
    // "PHP":[],
    // "SQL":[]
    
  },
  //2- kebd
  "كبد": {
    "رأفت عطا":[],
    "رانيا امين":[],
    "شندي محمد":[],
    "أحمد الراعي":[]
    // "PHP":[],
    // "SQL":[]

  },
  //3- 2alb
  "قلب": {
    "زهراء":[],
    "محمد امام":[],
    "وائل شحات":[],
    "شادي زهران":[]
    // "PHP":[],
    // "SQL":[]
    
  },
  //4- sadr
  "صدر": {
    "راندا صلاح":[],
    "وائل شحات":[]
    // "PHP":[],
    // "SQL":[]
    
  },
  //5- anf & ozon
  "انف و اذن": {
    "خالد رشيد":[],
    "هدير اسامة":[],
    "خالد الجوهري":[],
    "هبه محمود":[]
    // "PHP":[],
    // "SQL":[]
    
  },
  //6- ramad
  "رمد": {
    "سهير عصمت":[],
    "محمود جمال":[],
    "إيمان محمد":[],
    "مصطفي بهجت":[],
    "مصطفي الغنام":[],
    "محمد هاني":[],
    "أحمد فوزي":[]
    // "PHP":[],
    // "SQL":[]

  },
  //7- gera7a
  "جراحة": {
    "يحي صفوت":[],
    "وليد الشيمي":[],
    "محمد عبد اللطيف":[],
    "مدحت عامر":[],
    "علاء حنفي":[],
    "محمد الكردي":[],
    "محمد ندا":[],
    "محمد فاروق":[],
    "سعيد البرجي":[],
    "محمود الافندي":[]
    // "PHP":[],
    // "SQL":[]

  },
  //8- nafsya & 3asabya
  "نفسية و عصبية": {
    "منتصر حجازي":[],
    "أحمد قدري":[]
    // "PHP":[],
    // "SQL":[]
  
  },
  //9- geldya
  "جلدية": {
    "ميريت امين":[],
    "شهيرة طلبه":[],
    "مصطفي يحي":[]
    // "PHP":[],
    // "SQL":[]
  
  },
  //10- masalek
  "مسالك": {
    "علي حسن":[],
    "حسن النمر":[],
    "تامر فؤاد":[],
    "محمود المهدي":[]
    // "PHP":[],
    // "SQL":[]
    
  },
  //11- 3zam
  "عظام": {
    "حامد الجوهري":[],
    "شريف البيسي":[],
    "محمد المراكبي":[],
    "وليد احمد":[],
    "محمد توفيق":[],
    "بهاء قرنه":[],
    "محمد شبانه":[],
    "وليد السيد":[],
    "سوزان الغرابي":[],
    "حسين جمعة":[],
    "محمد سليمان قطب":[],
    "احمد منصور":[],
    "محمد صابر":[],
    "محمد عبد الحميد":[],
    "محمد زيدان":[],
    "عاطف البلتاجي":[]
    // "PHP":[],
    // "SQL":[]
  },
  //12- wageh & faken
  
  "وجه و فكين": {
    "لا يتوفر في الوقت الحالي":[]

    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  //13- romatezm
  "روماتيزم": {
    "حنان حسين":[],
    "شريف قنديل":[],
    "ايمان الجزار":[],
    "سعادات الغوابي":[],
    "رانيا امين":[]
    // "PHP":[],
    // "SQL":[]
   
  },
  //14- kola
  "كلي": {
    "عصام حامد":[],
    "محمد علي ابراهيم":[]
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // 15- mo5 & a3sab
  "مخ و اعصاب": {
    "محمد مصطفي":[],
    "محمد المليجي":[],
    "سمير صابر":[],
    "طارق زكي":[],
    "محمد عيد":[],
    "احمد صلاح":[],
    "عماد الاكوح":[],
    "محمد حلمي":[],
    "احمد عمرو حافظ":[],
    "احمد كحيل":[],
    "احمد مرعي":[]
    // "PHP":[],
    // "SQL":[]
  },
  // 16- aw3ya
  "اوعية": {
    "حسين كمال":[],
    "اشرف علي":[],
    "علاء عبد الحليم":[],
    "احمد جمال":[],
    "احمد رفعت":[],
    "محمود فوزي":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // 17- nesaa & welada
  "نساء و ولادة": {
    "هبه ابراهيم":[]
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // 18- ta5der
  "تخدير": {
    "محمد احمد عبدالله":[]
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // 19- asnan
  "أسنان": {
    "بسمه محمود":[],
    "اسامة كمال":[]
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // // 20- el3yada el mas2ya
  // "العيادات المسائية": {
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "PHP":[],
  //   // "SQL":[]
  // },
  // 21- awram
  "أورام": {
    "خالد كمال الدين":[]
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  },
  // 22- 2alb mafto7
  "قلب مفتوح": {
    "لا يتوفر في الوقت الحالي":[]

    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "PHP":[],
    // "SQL":[]
  }
}



window.onload = function() {
  var specializationSel = document.getElementById("specialization");
  var doctorSel = document.getElementById("doctor");
 
  for (var x in subjectObject) {
    specializationSel.options[specializationSel.options.length] = new Option(x, x);
  }


   specializationSel.onchange = function() {
    //empty Chapters- and Topics- dropdowns
// chapterSel.length = 1;
    doctorSel.length = 1;
    //display correct values
    for (var y in subjectObject[this.value]) {
      doctorSel.options[doctorSel.options.length] = new Option(y, y);
    }
  }
}




///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
///////////M_G_X_ORIGINALS/////////////////////////////
</script>

<style type="text/css">


#left{
    position: absolute; 
    left : 0;
    
}


input[type="date"]::-webkit-datetime-edit, input[type="date"]::-webkit-inner-spin-button, input[type="date"]::-webkit-clear-button {
  color: #fff;
  position: relative;
}

input[type="date"]::-webkit-datetime-edit-year-field{
  position: absolute !important;
  border-left:1px solid #8c8c8c;
  padding: 2px;
  color:#000;
  left: 56px;
}

input[type="date"]::-webkit-datetime-edit-month-field{
  position: absolute !important;
  border-left:1px solid #8c8c8c;
  padding: 2px;
  color:#000;
  left: 26px;
}


input[type="date"]::-webkit-datetime-edit-day-field{
  position: absolute !important;
  color:#000;
  padding: 2px;
  left: 4px;
  
}
 
select{
background-color: #bbb8b8;
}

.logomain {
    width: 80%;
    position: absolute;
    right: -70px;
    top: -175px;
    cursor: pointer;
}


.demo-wrap {
  position: relative;
}

.demo-wrap:after {
  content: ' ';
  display: block;
  position: absolute;
  float: left;
  left: 0;
  top: 0;
  width: 22%;
  height: 100%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}

li{
	list-style-type: none;

}

/*a {
  float: left;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
  background-color: #30072c;
  color: white;
  font-weight: bold;
    

}
 a:hover {
  background-color: #a5707a;
  color: black;
  font-weight: bold;
}*/

  .btnup{

padding: 10px;
margin: 8px;
border-radius: 5px;
border: none;
text-decoration: none;
background-color: #30072c;
  color: white;
  font-weight: bold;
    
transition-duration: 0.4s;
cursor: pointer;
left: -7px;
position: relative;

  }


  .btnup:hover{

 background-color: #a5707a;
  color: black;
  font-weight: bold;



  }
  .fn{

align-items: center;

  }

  .com{
 
 align-items: center;

  }
  .divup{
    padding: 10px;
  }


  details > summary {
  list-style: none;

}
.allofthelist{

width: 70%;
position: absolute;
float: left;
left: 3%;

}

/*.cpr{

  padding: 12px;
  margin: 12px;
  position: absolute;

  text-align: center;
 cursor: not-allowed;
  top: 99%;
  left: 30%;
  
}*/
 
details > summary {
  list-style: none;
}


  </style>
<div class="eocontainer" style="width: 73%; background-color: ; position: absolute; left: 2%;">


  <div id="heeed" ><span style="font-size: 30px; border: 2px #958997 solid; padding: 4px; margin: 3px; box-shadow: 3px 3px 50px 3px #4c1943; font-weight: bold; border-radius: 12px; text-shadow: 8px 6px 8px #784a73;font-family: 'Reem Kufi', sans-serif; " id="heed">تسجيل دخول مريض</span></div>
 
<hr>
<div>
  <title>View</title>


  

<style type="text/css">
  


  table {
   font-family: Georgia, serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
/*.body{
  position: absolute;
  right: 37%;
  width: 50%;
}*/


 .w3-sidebar{

     position: relative;
     right: 0;
     top: 0;
  }

   .sessiondiv{

    position: relative;
    top:  -13px;

   }

     header{

  position: absolute;
  left: 0;
  padding: 10px;

  }


  @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){

 #heeed{
    display: flex;
    justify-content: center;
    position: relative;
     

 }

  }
 
 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){

.body{
  

     top: 169px;
    position: absolute;
    right: -30%;
    width: 130%;

}


 #heeed{
    display: flex;
    justify-content: center;
    position: relative;
    top: 81px;
    left: 100px;

 }


 }
@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){

.body{
  position: absolute;
    left: 6%;
    top: 162px;
    width: 120%;
}


#left{
    position: relative; 
    
}



#heeed{
    display: flex;
    justify-content: center;
    position: relative;
    top: 81px;
    left: 45px;
 }
}

</style>



<body dir="ltr">

<div class="body">
<?php
ob_start(); 
/*

fullname
pcuser
pcpass
login
shifttime
sitestatus
arrivalstatus

*/








@session_start();



    

ob_end_flush();
?>
          
<!--

<div class="addnewbox" style="position:relative; left: 30%; width:40%; height:80%; background-color: gray;">


<tr>


<td>

<br>


<th>

<p>your name : </p>
</th>
</td>
<td>
<input type="text"  width:20PX; placeholder="" >
</td>
</tr>
</div>
  -->
  <!--Connection-->  <!--Connection-->
  <co class="co">
<?php

require_once('connect.php');


?>
</co>

<br id="brh" hidden>
<br id="brh" hidden>
 
<h3 style="text-align: center; font-size: 230%; font-family: cursive;" id="ht">( Add Reports Area )</h3>
<br id="brh" hidden>
 
<hr color="black" size="5">

<ti id="ti" hidden >Printing Date :- &nbsp; <?php date_default_timezone_set('Africa/Cairo'); $timee = date('d/m/Y, h:i:s A'); echo ($timee);?>&nbsp;   ||  &nbsp; Printer user : <?php echo $_SESSION['user'];?></ti>
<br><br>
<form method="POST" name="myform" autocomplete="on" id="myform"  style="" dir="rtl"  >
<div class="rnr-brickcontents style1 rnr-b-wrapper  rnr-wrapper rnr-cbw-fields"  >

<div class="rnr-cw-fields rnr-s-fields asbuttons MetroOffice"    >
<div class="rnr-c rnr-cv rnr-c-fields">


<div class="rnr-brickcontents style2 rnr-b-addheader " id="neww" ><span> <h1 style="font-family: 'Reem Kufi', sans-serif;">تسجيل دخول مريض</h1>
</span></div>
<div class="rnr-brickcontents style2 rnr-b-addheader " id="neww2"><span> <h1></h1>
</span></div>

<div class="rnr-brickcontents style2 rnr-b-addheader " id="neww3"><span> <h1 style="font-family: 'Reem Kufi', sans-serif;"> Record id :  <input type="text" id="unique_id" name="unique_id" maxlength="24" value="<?php $n=4;
function randomNumber($n) {
 $characters = '0123456789';
 $randomString = '';
 for ($i = 0; $i < $n; $i++) {
  $index = rand(0, strlen($characters) - 1);
  $randomString .= $characters[$index];
 }
 return $randomString;
}
echo date('mdy-his-').randomNumber($n);?>" style=" border-radius: 7px; background-color: black; color: white; border: none; outline: none;" readonly=""   />  </h1>
</span></div>
 
 

<div class="rnr-brickcontents style1 rnr-b-addfields_simple "><div class="rnr-simplefields edit">
  
<!-- <button type=\"submit\" style='width:30px;cursor:pointer;'><i class=\"fa fa-search\"></i></button> -->


  <?php



echo "




<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"    id=\"left\">
  <span class=\"rnr-label\">رقم هاتف المريض :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"pa_phone_num\" maxlength=\"11\" style=\"width: 200px;\" type=\"text\" name=\"pa_phone_num\" oninput=\"this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*?)\..*/g, '$1');\" value=\"\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">الرقم القومي :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"pa_national_id\" maxlength=\"14\" onfocusout=\"fill_data()\" style=\"width: 200px;\" type=\"text\" name=\"pa_national_id\" oninput=\"this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*?)\..*/g, '$1');\" value=\"\" >&nbsp;<font color=\"red\">*&nbsp;</font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"   id=\"left\">
  <span class=\"rnr-label\">الرقم الطبي :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"medical_number\" style=\"width: 200px;\" type=\"text\" name=\"medical_number\" oninput=\"this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*?)\..*/g, '$1');\"  value=\"\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">اسم المريض :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"patient_name\" style=\"width: 200px;\" type=\"text\" name=\"patient_name\"  value=\"\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>







<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"    id=\"left\">
  <span class=\"rnr-label\">النوع :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"gender\" name=\"gender\" style=\"width: 207px;\"><option value='ذكر'>ذكر</option><option value='انثى'>انثى</option><option value='' selected hidden>--Please Select--</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div> 

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">تاريخ الميلاد :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"date_of_birth\" data-inputmask=\"'alias': 'dd/mm/yyyy'\" style=\"width: 200px;\" type=\"date\" name=\"date_of_birth\"  value=\"\" >&nbsp;<font color=\"red\">*</font></span></span>
  <span class=\"rnr-label\" style='min-width: 0px;'>السن :</span><span class=\"rnr-label\" id='age' style='min-width: 0px;'>0</span>
</div>

 

<hr>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"    id=\"left\">
  <span class=\"rnr-label\">درجة قرابة المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"spo_degree_of_kinship\" onfocusout=\"spo_degree_of_kinship_validate()\" name=\"spo_degree_of_kinship\" style=\"width: 207px;\"><option value='أب'>أب</option><option value='أم'>أم</option><option value='أخ'>أخ</option><option value='أخت'>أخت</option><option value='زوج او زوجة'>زوج او زوجة</option><option value='أبن او أبنة'>أبن او أبنة</option><option value='أخري'>أخري</option><option value='' selected hidden>--Please Select--</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div> 

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">اسم المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"sponsor_name\" style=\"width: 200px;\" type=\"text\" name=\"sponsor_name\"  value=\"\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>

<div class='spo_degree_of_kinship_box' id='أخري'>
<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"    id=\"left\">
  <span class=\"rnr-label\">درجة قرابة أخري :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"spo_degree_of_kinship2\" style=\"width: 200px;\" type=\"text\" name=\"\"  value=\"\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>
</div>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">رقم هاتف المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"spo_phone_num\" maxlength=\"11\" style=\"width: 200px;\" type=\"text\" name=\"spo_phone_num\"  oninput=\"this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*?)\..*/g, '$1');\" value=\"\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>





<hr>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"     id=\"left\">
  <span class=\"rnr-label\">التخصص :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"specialization\" name=\"specialization\" style=\"width: 207px\"><option value='' selected hidden>--Please Select--</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">تاريخ الدخول :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"date_of_entry\" style=\"width: 200px;\" type=\"date\" name=\"date_of_entry\"  value=\"\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>





<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"     id=\"left\">
  <span class=\"rnr-label\">الطبيب :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"doctor\" name=\"doctor\" style=\"width: 207px;\"><option value='' selected hidden>--Please Select--</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">نوع الدخول :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"entry_type\" name=\"entry_type\" style=\"width: 207px\"><option value='طوارئ'>طوارئ</option><option value='مباشر'>مباشر</option><option value='' selected hidden>--Please Select--</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>

 
<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"    id=\"left\">
  <span class=\"rnr-label\">اذن القبول :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"acceptance_permission\" style=\"width: 200px;\" type=\"text\" name=\"acceptance_permission\"  value=\"\" >&nbsp;<font color=\"red\">*</font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">القسم :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"section\" name=\"section\" style=\"width: 207px\"><option value='1'>1</option><option value='2'>2</option><option value='3'>3</option><option value='4'>4</option><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8'>8</option><option value='9'>9</option><option value='10'>10</option><option value='11'>11</option><option value='وحدة الأطفال المبتسرين'>وحدة الأطفال المبتسرين</option><option value='عناية مركزة'>عناية مركزة</option><option value='عناية قلب مفتوح'>عناية قلب مفتوح</option><option value='وحدة الانجو'>وحدة الانجو</option><option value='' selected hidden>--Please Select--</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"    id=\"left\">
  <span class=\"rnr-label\">المعاملة المالية :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"financial_transaction\" name=\"financial_transaction\" style=\"width: 207px\"><option value='مجانى'>مجانى</option><option value='خاص'>خاص</option><option value='مستشفى'>مستشفى</option><option value='وزارة'>وزارة</option><option value='شركات'>شركات</option><option value='تأمين'>تأمين</option><option value='تأمين أطفال'>تأمين أطفال</option><option value='تأمين مواليد'>تأمين مواليد</option><option value='عاملين' disabled>عاملين</option><option value='' selected hidden>--Please Select--</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">الحجرة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"room\" name=\"room\" style=\"width: 207px\" disabled><option value='1'>1</option><option value='2'>2</option><option value='3'>3</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"    id=\"left\">
  <span class=\"rnr-label\">اسم الكفيل :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"sponsor_nameee\" style=\"width: 200px;\" type=\"text\" name=\"sponsor_nameee\"  value=\"\" placeholder='Inactive ..... ' disabled>&nbsp;<font color=\"red\">*</font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">الدرجة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"grade\" name=\"grade\" style=\"width: 207px\"><option value='جناح'>جناح</option><option value='اولى ممتاز'>اولى ممتاز</option><option value='اولى عادى'>اولى عادى</option><option value='ثانية ممتاز'>ثانية ممتاز</option><option value='ثانية عادى'>ثانية عادى</option><option value='عناية مركزة'>عناية مركزة</option><option value='' selected hidden>--Please Select--</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"    id=\"left\">
  <span class=\"rnr-label\">منتفع بالتامين الصحي :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><select elect size=\"1\" id=\"health_insurance_beneficiary\" name=\"health_insurance_beneficiary\" style=\"width: 207px\"><option value='منتفع بالتامين'>منتفع بالتامين</option><option value='' selected hidden>--please select--</option><option value='غير منتفع بالتامين'>غير منتفع بالتامين</option></select>&nbsp;<font color=\"red\">*</font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">نتيجة العينة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"sample_result\" style=\"width: 200px;\" type=\"text\" name=\"sample_result\"  value=\"\" placeholder='Inactive ..... ' disabled>&nbsp;<font color=\"red\">*</font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \"     id=\"left\">
  <span class=\"rnr-label\">كود منشآة المسح :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"scan_facility_code\" style=\"width: 200px;\" type=\"text\" name=\"scan_facility_code\"  value=\"\" placeholder='Inactive ..... ' disabled>&nbsp;<font color=\"red\">*</font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">المركز المحال اليه :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><input id=\"referred_center\" style=\"width: 200px;\" type=\"text\" name=\"referred_center\"  value=\"\" placeholder='Inactive ..... ' disabled>&nbsp;<font color=\"red\">*</font></span></span>
</div>


















 



<hr>







";

     






 







?>


 



<div data-fieldname="Ticket" class="rnr-field style1 " hidden="hidden">
  <span class="rnr-label">حالة الملف :</span>
  <span class="rnr-control style3\"><span id="edit1_Ticket_0" class="rnr-nowrap"><select elect size="1" id="record_status" name="record_status" style="width: 207px"><option value='دخول' selected>دخول</option><option value=''  hidden>--please select--</option><option value='خروج'>خروج</option><option value='احاله' disabled>احاله</option></select>&nbsp;<font color="red">*</font></span></span>
</div>

<div data-fieldname="Ticket" class="rnr-field style1 " hidden="hidden">
  <span class="rnr-label">تم الاضافه بواسطة :</span>
  <span class="rnr-control style3\"><span id="edit1_Ticket_0" class="rnr-nowrap"><input id="added_by" style="width: 200px;" type="text" name="added_by"  value="<?php echo $_SESSION['user'];?>"readonly>&nbsp;<font color="red">*</font></span></span>
</div>


<div data-fieldname="Ticket" class="rnr-field style1" hidden="hidden">
  <span class="rnr-label">تم التعديل بواسطة :</span>
  <span class="rnr-control style3"><span id="edit1_Ticket_0" class="rnr-nowrap"><input id="last_edit_by" style="width: 200px;" type="text" name="last_edit_by"  value="<?php echo $_SESSION['user'];?>" readonly>&nbsp;<font color="red">*</font></span></span>
</div>



<div data-fieldname="Ticket" class="rnr-field style1" hidden="hidden">
  <span class="rnr-label">توقيت الاضافة :</span>
  <span class="rnr-control style3"><span id="edit1_Ticket_0" class="rnr-nowrap"><input id="added_on" style="width: 200px;" type="text" name="added_on"  value=" <?php date_default_timezone_set('Africa/Cairo'); $timeee = date('d/m/Y, h:i:s A'); echo ($timeee);?>" readonly>&nbsp;<font color="red">*</font></span></span>
</div>




<!--
  



  





<div data-fieldname="SMS" class="rnr-field style1 ">
  <span class="rnr-label">SMS</span>
  <span class="rnr-control style3"><span id="edit1_SMS_0" class="rnr-nowrap"><input id="value_SMS_1" type="hidden" name="value_SMS_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_SMS_1_0" name="radio_SMS_1" value="1"> <span id="label_radio_SMS_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_SMS_1_1" name="radio_SMS_1" value="0"> <span id="label_radio_SMS_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="Ststus" class="rnr-field style1 ">
  <span class="rnr-label">Ticket Status</span>
  <span class="rnr-control style3"><span id="edit1_Ststus_0" class="rnr-nowrap"><select size="1" id="value_Ststus_1" name="value_Ststus_1" style="width: 207px"><option value="">Please select</option><option value="Open">Open</option><option value="Waiting For Response">Waiting For Response</option><option value="In-progress">In-progress</option><option value="Waiting For Customer">Waiting For Customer</option><option value="Call Back">Call Back</option><option value="Offline">Offline</option><option value="MSAN Replace">MSAN Replace</option><option value="Major Faults">Major Faults</option><option value="Internal Wiring Vendor Visit">Internal Wiring Vendor Visit</option><option value="Major Fault (Direct)">Major Fault (Direct)</option><option value="Engineering inspection ÊÝÊíÔ åäÏÓì">Engineering inspection ÊÝÊíÔ åäÏÓì</option></select>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="follow_process" class="rnr-field style1 ">
  <span class="rnr-label">Follow Process</span>
  <span class="rnr-control style3"><span id="edit1_follow_process_0" class="rnr-nowrap"><input id="value_follow_process_1" type="hidden" name="value_follow_process_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_follow_process_1_0" name="radio_follow_process_1" value="Yes"> <span id="label_radio_follow_process_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_follow_process_1_1" name="radio_follow_process_1" value="No"> <span id="label_radio_follow_process_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="on_shift" class="rnr-field style1 ">
  <span class="rnr-label">On Shift</span>
  <span class="rnr-control style3"><span id="edit1_on_shift_0" class="rnr-nowrap" style="display: none;"><input id="value_on_shift_1" type="hidden" name="value_on_shift_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_on_shift_1_0" name="radio_on_shift_1" value="1"> <span id="label_radio_on_shift_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_on_shift_1_1" name="radio_on_shift_1" value="0"> <span id="label_radio_on_shift_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="follow_up_time" class="rnr-field style1 ">
  <span class="rnr-label">Follow Date</span>
  <span class="rnr-control style3"><span id="edit1_follow_up_time_0" class="rnr-nowrap" style="display: none;"><input id="type_follow_up_time_1" type="hidden" name="type_follow_up_time_1" value="date11"><input id="value_follow_up_time_1" style="width: 200px;" type="Text" name="value_follow_up_time_1" value=""><input id="tsvalue_follow_up_time_1" type="Hidden" name="tsvalue_follow_up_time_1" value="0-0-0">&nbsp;<a href="#" id="imgCal_value_follow_up_time_1" data-icon="calendar" title="Click Here to Pick up the date"></a></span></span>
</div>

  
<div data-fieldname="follow_time" class="rnr-field style1 ">
  <span class="rnr-label">Follow Time</span>
  <span class="rnr-control style3"><span id="edit1_follow_time_0" class="rnr-nowrap" style="display: none;"><input id="type_follow_time_1" style="width: 200px;" type="hidden" name="type_follow_time_1" value="time"><input type="text" style="width: 200px;" name="value_follow_time_1" id="value_follow_time_1" value="">&nbsp;<a class="rnr-imgclock" data-icon="timepicker" title="Time" style="display: inline-block; margin: 4px 0px 0px 6px; visibility: visible;" id="trigger-test-value_follow_time_1"></a>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="Comment" class="rnr-field style1 ">
  <span class="rnr-label">Comment</span>
  <span class="rnr-control style3"><span id="edit1_Comment_0" class="rnr-nowrap"><textarea id="value_Comment_1" name="value_Comment_1" style="width: 200px;height: 100px;"></textarea></span></span>
</div>

  
<div data-fieldname="integration_problem" class="rnr-field style1 ">
  <span class="rnr-label">Integration Problem</span>
  <span class="rnr-control style3"><span id="edit1_integration_problem_0" class="rnr-nowrap"><input id="type_integration_problem_1" type="hidden" name="type_integration_problem_1" value="checkbox"><input id="value_integration_problem_1" type="Checkbox" name="value_integration_problem_1"></span></span>
</div>

  
<div data-fieldname="new_pilot" class="rnr-field style1 ">
  <span class="rnr-label">Valid for proactive concession</span>
  <span class="rnr-control style3"><span id="edit1_new_pilot_0" class="rnr-nowrap" style="display: none;"><select size="1" id="value_new_pilot_1" name="value_new_pilot_1" style="width: 207px"><option value="">Please select</option><option value="Yes">Yes</option><option value="No">No</option></select></span></span>
</div>

</div>
</div>
-->


<div class="rnr-brickcontents style2 rnr-b-addbuttons " id="newwbuttom"><div class="rnr-buttons-left">
    
  <!--
  <input type="submit" class="rnr-button main" name="update" id="update" value="Update">
  
 
  <input type="submit" class="rnr-button main" name="check" id="check" value="check" > 
  
  -->
  <a onclick="window.location.href=('eo_test2.php');"  style="cursor: pointer;" class="rnr-button"  name="back" id="backButton1">الرجوع</a>

 

<button   class="rnr-button main" id="addneweo"  name="addneweo" style="cursor: pointer;" >تسجيل جديد</button>
  <!--
  <input type="submit" class="rnr-button main" name="delete" id="delete" style="position: relative; left: 70px;" value="Delete">
   -->


</div>
</div>


</div>
</div>

</div>



</form>

</div>

<footer class="custom-footer">
      <?php
      $end_time = microtime(TRUE);
      $time_taken = $end_time - $start_time;
      $total_time = round($time_taken, 4);
      ?>
      <p>
        <span class="description">⏱️ Render:</span>
        <span class="result"><?php echo $total_time; ?> sec</span>
      </p>
      <p>&copy; 2023 M_G_X. All rights reserved.</p>
    </footer>

  
</div>
 


<?php





if (@$_SESSION['type']=='admin' ) {

        echo "<script>document.getElementById('unique_id').style.backgroundColor = '#081a36';</script>";
 
        echo "<script>document.getElementById('neww').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#081a36';</script>";
         echo "<script>document.getElementById('heed').style.boxShadow = '3px 3px 50px 3px #21478b';</script>";
         echo "<script>document.getElementById('heed').style.textShadow = '8px 6px 8px #143970';</script>";
         echo "<script>$(\"option[value='وجه و فكين']\").attr('disabled', 'disabled');</script>";
         include 'add_patient_eo_script.php';
         include 'add_patient_logs_script.php';
         include 'add_patient_login_eo_entry_count.php';

         
 





  }elseif (@$_SESSION['type']=='it_user' || @$_SESSION['type']=='ad_it_user') {

      
  echo "<script>document.getElementById('unique_id').style.backgroundColor = '#15483f';</script>";
 
        echo "<script>document.getElementById('neww').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('heed').style.boxShadow = '3px 3px 50px 3px #15483f';</script>";
         echo "<script>document.getElementById('heed').style.textShadow = '8px 6px 8px #15483f';</script>";
         echo "<script>$(\"option[value='وجه و فكين']\").attr('disabled', 'disabled');</script>";
          include 'add_patient_eo_script.php';
          include 'add_patient_logs_script.php';
          include 'add_patient_login_eo_entry_count.php';
 

     
  }elseif (@$_SESSION['type']=='eo_user') {

      
  echo "<script>document.getElementById('unique_id').style.backgroundColor = '#1c2827';</script>";
 
        echo "<script>document.getElementById('neww').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('heed').style.boxShadow = '3px 3px 50px 3px #1c2827';</script>";
         echo "<script>document.getElementById('heed').style.textShadow = '8px 6px 8px #1c2827';</script>";
         echo "<script>$(\"option[value='وجه و فكين']\").attr('disabled', 'disabled');</script>";
          include 'add_patient_eo_script.php';
          include 'add_patient_logs_script.php';
          include 'add_patient_login_eo_entry_count.php';
 

     
  }elseif (@$_SESSION['type']=='eo_viewer') {

      
  echo "<script>document.getElementById('unique_id').style.backgroundColor = 'gray';</script>";
 
        echo "<script>document.getElementById('neww').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = 'gray';</script>";

     
  }else{
            echo "<script>function(){ history.back(); }</script>";
  }


?>
