
<style type="text/css">
  
h1{

  font-family: 'Brush Script MT', cursive;
}


</style>

<script>  
 $(document).ready(function(){  
      $(document).on('click', '.column_sort', function(){  
           var column_name = $(this).attr("id");  
           var order = $(this).data("order");  
           var arrow = '';  
           //glyphicon glyphicon-arrow-up  
           //glyphicon glyphicon-arrow-down  
           if(order == 'desc')  
           {  
                arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-down"></span>';  
           }  
           else  
           {  
                arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-up"></span>';  
           }  
           $.ajax({  
                url:"sort.php",  
                method:"POST",  
                data:{column_name:column_name, order:order},  
                success:function(data)  
                {  
                     $('#employee_table').html(data);  
                     $('#'+column_name+'').append(arrow);  
                }  
           })  
      });  
 });  
 </script>  

<?php
require_once 'connect.php';




$r = mysqli_query($conn , $slecetr= "SELECT * FROM users");







  if(isset($_POST['check'])){


echo "
<div style='position: relative;text-align: center;'>
<h1 style='font:bold;'>
Check Users Logs
</h1>
 

</div>
<br>
<hr>";

    echo "<form>
  

  <table  id='myTable' style='width:99.9%; font-size: 15px; position: relative; left: 0%;'>
  <tr>
    <th style='background-color :#2E2D2D; color:white;'><a class=\"column_sort\" id=\"id\" data-order=\"'..'\" href=\"#\">ID</a></th>
    <th style='background-color :#2E2D2D; color:white;'><a class=\"column_sort\" id=\"id\" data-order=\"'..'\" href=\"#\">The Name</a></th>
    <th style='background-color :#2E2D2D; color:white;'><a class=\"column_sort\" id=\"id\" data-order=\"'..'\" href=\"#\">The User</a></th>
    <th style='background-color :#2E2D2D; color:white;'>The Pass</th>
    <th style='background-color :#2E2D2D; color:white;'><a class=\"column_sort\" id=\"id\" data-order=\"'..'\" href=\"#\">The User Level</a></th>
  </tr>";
    while (@$row = mysqli_fetch_array(@$r)){

$hashpass = $row['pass'];
$hash_default_salt = password_hash($hashpass,PASSWORD_DEFAULT);
$hash_variable_salt = password_hash($hashpass,PASSWORD_DEFAULT, array('cost' => 9));

// password_verify('Pass', $hash_variable_salt );
// password_verify('Pass',$hash_default_salt );
// password_verify('Pass123',$hash_default_salt );

      echo "<tr>";
      echo "<td style='cursor:pointer;'>$row[id]</td>";
      echo "<td style='cursor:pointer;'>$row[name]</td>";
      echo "<td style='cursor:pointer;'>$row[user]</td>";
      echo  "<td style='cursor:pointer;'>*******". password_verify('*******',$hash_default_salt )."</td>";
      // echo ;
      echo "<td style='cursor:pointer;'>$row[type]</td>";
      echo "</tr>";

    }

   echo "</table></form>";
}









?>