<?php

// Function to check if Apache service is running
function isApacheRunning() {
    $apacheStatus = @fsockopen('localhost', 8080);
    if ($apacheStatus !== false) {
        fclose($apacheStatus);
        return true;
    }
    return false;
}

// Function to check if MySQL service is running
function isMySQLRunning() {
    $mysqlStatus = @fsockopen('localhost', 3306);
    if ($mysqlStatus !== false) {
        fclose($mysqlStatus);
        return true;
    }
    return false;
}

// Check if Apache and MySQL services are running
$apacheStatus = isApacheRunning();
$mysqlStatus = isMySQLRunning();

// Determine the overall system status and dot color
$status = ($apacheStatus && $mysqlStatus) ? 'Online' : 'Offline';
$dotColor = ($status === 'Online') ? 'green' : 'red';

// Create an associative array with the status and dot color data
$data = [
    'status' => $status,
    'dotColor' => $dotColor
];

// Set the response content type as JSON
header('Content-Type: application/json');

// Output the data as JSON
echo json_encode($data);
?>
