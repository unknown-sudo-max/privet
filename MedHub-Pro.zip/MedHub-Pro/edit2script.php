<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<?php


require_once 'connect.php';
//require_once 'Add_new_user.php';


if(isset($_GET['update'])){



//@$alert =$_GET['alert'];






if (!empty($_GET['filetitle'])) {

	# code...


	if ($_SERVER['REQUEST_METHOD'] == 'GET') {
$id            = strip_tags($_GET['id']);
$filetitle      = strip_tags($_GET['filetitle']);
$filedesc        = strip_tags($_GET['filedesc']);
$addedon        = strip_tags($_GET['addedon']);



$sql= "UPDATE hruploadedfiles SET  titleF='$filetitle', descF='$filedesc', date='$addedon' WHERE id='$id'  ";


//$sql= "UPDATE `hruploadedfiles` SET `titleF`='$filetitle',`descF`='$filedesc' WHERE id='$id' ";

//$sql= "UPDATE records set  fullname='$_GET[fullname]', pcuser='$_GET[pcuser]', pcpass='$_GET[pcpass]', login='$_GET[login]', shifttime='$_GET[shifttime]', sitestatus='$_GET[sitestatus]', arrivalstatus='$_GET[fullname]', recordstatus='$_GET[recordstatus]', comment='$_GET[comment]', shiftondate='$_GET[arrivalstatus]', addedon='$_GET[addedon]' WHERE id='$_GET[id]' ";


}


if (@mysqli_query($conn, $sql)) {

	# code...

	echo "<br><i class=\"fa fa-check-circle\" style=\"position: relative; left: 45%; top:-20px; font-size:48px;color:green\"></i> <div style='color:green; text-align: center; font-weight: bold; position: relative; ' >Your File Updated Successfully</div><br>";
}
	else{

		echo "<p style='color:red; font-size:15px;'>Failed TO Updated The Record !!!</p>";

	}

//@mysqli_close($conn);

}
else{
	echo "<div style='position: relative;
      text-align: right;
    font-weight: bold;
    top: -10px;
    width :90%;
    font-size: 70%;
    left: -75px;
    color: red;
    '><i class=\"fa fa-close\" style=\"font-size:50px;color:red position: relative; text-align: center;\"></i> <p style='color:red; font-size:15px;'>The  <u style='font-weight:  bold;'>File Name </u>   Field Are Required !!! </p></div>";
}
/*
if (mysqli_query($conn, $db )) {

	# code...

	echo "user added success";
}
	else{

		echo "failed";
	}

mysqli_close($conn);

*/



}

ob_start();

@session_start();
//@$_SESSION['theuser'] = $_GET['theuser'];

//@$_SESSION['thepass'] = $_GET['thepass'];

//@$_SESSION['thefname'] = $_GET['thefname'];

/*


if(isset($_GET['save'])){

extract($_REQUEST);
$file=fopen('myusers2.php' , 'a');
fwrite(@$file, "///////////////");
fwrite(@$file, $thefname);
fwrite(@$file, " User");
fwrite(@$file, "//");
fwrite(@$file, "\n");
fwrite(@$file, "if(isset($");
fwrite(@$file, "_");
fwrite(@$file, "GET['submit'])){");
fwrite(@$file, "if(");
fwrite(@$file, "$");
fwrite(@$file, "user ");
fwrite(@$file, "== '");
fwrite(@$file, $theuser);
fwrite(@$file, "'){");
fwrite(@$file, "if(");
fwrite(@$file, "$");
fwrite(@$file, "pass ");
fwrite(@$file, "== '");
fwrite(@$file, $thepass);
fwrite(@$file, "'){");
fwrite(@$file, "echo ");
fwrite(@$file, "\"<script>");
fwrite(@$file, "window.location.href=");
fwrite(@$file, "('Avaya_vaildation.php');");
fwrite(@$file, "</script>\";");
fwrite(@$file, "}");

fwrite(@$file, "else{");

fwrite(@$file, "$");
fwrite(@$file, "error ");
fwrite(@$file, "= ");
fwrite(@$file, "\"<div ");
fwrite(@$file, "style='position: relative;text-align: center;'>");
fwrite(@$file, "<n style='color: red;'>");
fwrite(@$file, "Invalid Login</n>");
fwrite(@$file, "<br><k>");
fwrite(@$file, "Check your password again , OR refer to your Adminstrator");
fwrite(@$file, "</k><div>\";");
//fwrite(@$file, "$error = \'<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid Login</n><br><k>Check your password again , OR refer to your Adminstrator</k><div>\';");
   
fwrite(@$file, "$");
fwrite(@$file, "success ");
   fwrite(@$file, "= '';"); 


     fwrite(@$file, "echo \"<br><br> <br> ");    
     fwrite(@$file, "$");
     fwrite(@$file, "error\";");       
     fwrite(@$file, "}}}");  
     fwrite(@$file, "\n");       

            
}

*/


if(isset($_GET['delete'])){



//@$alert =$_GET['alert'];






if (!empty($_GET['filetitle'])) {

	# code...
$id            = $_GET['id'];
$filetitle      = $_GET['filetitle'];
$filedesc        = $_GET['filedesc'];





$sql= "DELETE from hruploadedfiles  WHERE id='$id' ";

//$sql= "UPDATE records set  fullname='$_GET[fullname]', pcuser='$_GET[pcuser]', pcpass='$_GET[pcpass]', login='$_GET[login]', shifttime='$_GET[shifttime]', sitestatus='$_GET[sitestatus]', arrivalstatus='$_GET[fullname]', recordstatus='$_GET[recordstatus]', comment='$_GET[comment]', shiftondate='$_GET[arrivalstatus]', addedon='$_GET[addedon]' WHERE id='$_GET[id]' ";




if (mysqli_query($conn, $sql)) {

	# code...

	echo "<p style='color:green; font-size:15px;'>The Record Deleted Successfully</p>";
}
	else{

		echo "<p style='color:red; font-size:15px;'>Failed TO Deleted The Record !!!</p>";
	}

//mysqli_close($conn);

}
else{
	echo "<div style='position: relative;
      text-align: right;
    font-weight: bold;
    top: -10px;
    width :90%;
    font-size: 70%;
    left: -75px;
    color: red;
    '><i class=\"fa fa-close\" style=\"font-size:50px;color:red position: relative; text-align: center;\"></i> <p style='color:red; font-size:15px;'>The  <u style='font-weight:  bold;'>File Name </u>   Field Are Required !!! </p></div>";
}
/*
if (mysqli_query($conn, $db )) {

	# code...

	echo "user added success";
}
	else{

		echo "failed";
	}

mysqli_close($conn);

*/



}


  

?>
