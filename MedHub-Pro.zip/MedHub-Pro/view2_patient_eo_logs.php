
<?php 

require_once('header.php');
// include 'access.php';
access('EO_VIEWER');

      
 
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="ircss.css">
  <link rel="stylesheet" type="text/css" href="cdn/printeo.css" media="print">


<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />



<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
 <script type="text/javascript" src="cdn/xlsx.full.min.js"></script>
 <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script src="cdn/dd9c95f04f.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.debug.js"></script>
<script src="cdn/table2excel-master"></script>
<script type="text/javascript">

 


$(document).ready(function() {
    // body...






let topbutton = document.getElementById("topBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    topbutton.style.display = "block";
  } else {
    topbutton.style.display = "none";
  }
}



var nonne = $('#lau').html();

if (nonne == 'لا يوجد ملفات تم ارفاقها') {
  document.getElementById("printeo").remove();
 document.getElementById("export_button").remove();
 document.getElementById("export_button2").remove();
 document.getElementById("editbtn").remove();

}


$("#record_status").on('change', function(){


 

  $(".exit_date_box").hide();
  // $("#exit_date").val('');
  $("#" + $(this).val()).fadeIn(300);
 
}).change();


var now = new Date();
var this_year = now.getFullYear();
var month = ("0" + (now.getMonth() + 1)).slice(-2);
var day = ("0" + now.getDate()).slice(-2);
var st_year = this_year.toString();
var last_two_dig_of_year = st_year[2]+st_year[3];
var pa_national_id = $('#pa_national_id').html();
var national_id = pa_national_id.toString();
var select_gender = national_id[12];
var select_century = national_id[0];
var select_birthdate = national_id[1]+national_id[2]+'-'+national_id[3]+national_id[4]+'-'+national_id[5]+national_id[6];
var select_birthmonth = national_id[3]+national_id[4];
var select_birthday = national_id[5]+national_id[6];
var select_year_of_birth = national_id[1]+national_id[2];
var age_last_century = (this_year+month+day)- ("19"+select_year_of_birth+select_birthmonth+select_birthday);
var st_age_last_century = age_last_century.toString();

var age_this_century = (this_year+month+day)-("20"+select_year_of_birth+select_birthmonth+select_birthday);
var st_age_this_century = age_this_century.toString();


if (select_century == '2') {


$(age).html(st_age_last_century[0]+st_age_last_century[1]+ '&nbsp;'+'عام');
 

}else if (select_century == '3') {


  $(age).html(st_age_this_century[0]+st_age_this_century[1]+ '&nbsp;'+'عام');

}




var now = new Date();
 
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);

    var today = now.getFullYear()+"-"+(month)+"-"+(day) ;


   $('#exit_date').val(today);

  
 

 

 function html_table_to_excel(type)
    {

        var data = document.getElementById('myTable');
         var patientname      = $('#patient_name').html();
         
        
       
 

        var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});


        XLSX.write(file, { bookType: type, type : 'binary', cellStyles : true, bookSST: true, type: 'base64' });

         

        XLSX.writeFile(file, patientname + '_patient logs in DB file.' + type);

    }

    const export_button = document.getElementById('export_button');



    export_button.addEventListener('click', () =>  {


        html_table_to_excel('xlsx');


 



    });
 


});
 


// var newImage, showImg;
// function loadFile(event) {
//   showImg = document.getElementById('showImg');
//   showImg.src = URL.createObjectURL(event.target.files[0]);

//   newImage = document.createElement('img');
//   newImage.src = URL.createObjectURL(event.target.files[0]);
  
//   showImg.onload = function() {
//     URL.revokeObjectURL(showImg.src) // free memory
//   }
// };

// function pdfDown(){
//   console.log(newImage)
//   var doc = new jsPDF();
//   doc.addImage(newImage,10,10);
//   doc.save('ImgToPDF.pdf')
// }


function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
  // window.scrollTo({ top: 0, behavior: 'smooth' });
}
 
</script>

<style type="text/css">

#topBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  left: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: #b95656;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
}

#topBtn:hover {
  background-color: #555;
}


.export_button {
    font-size: 16px;
    border: none;
    outline: none;
    color: white;
    cursor: pointer;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}


input[type="date"]::-webkit-datetime-edit, input[type="date"]::-webkit-inner-spin-button, input[type="date"]::-webkit-clear-button {
  color: #fff;
  position: relative;
}

input[type="date"]::-webkit-datetime-edit-year-field{
  position: absolute !important;
  border-left:1px solid #8c8c8c;
  padding: 2px;
  color:#000;
  left: 56px;
}

input[type="date"]::-webkit-datetime-edit-month-field{
  position: absolute !important;
  border-left:1px solid #8c8c8c;
  padding: 2px;
  color:#000;
  left: 26px;
}


input[type="date"]::-webkit-datetime-edit-day-field{
  position: absolute !important;
  color:#000;
  padding: 2px;
  left: 4px;
  
}
 
select{
background-color: #bbb8b8;
}

.logomain {
    width: 80%;
    position: absolute;
    right: -70px;
    top: -175px;
    cursor: pointer;
}


.demo-wrap {
  position: relative;
}

.demo-wrap:after {
  content: ' ';
  display: block;
  position: absolute;
  float: left;
  left: 0;
  top: 0;
  width: 22%;
  height: 100%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}

li{
  list-style-type: none;

}

/*a {
  float: left;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
  background-color: #30072c;
  color: white;
  font-weight: bold;
    

}
 a:hover {
  background-color: #a5707a;
  color: black;
  font-weight: bold;
}*/

  .btnup{

padding: 10px;
margin: 8px;
border-radius: 5px;
border: none;
text-decoration: none;
background-color: #30072c;
  color: white;
  font-weight: bold;
    
transition-duration: 0.4s;
cursor: pointer;
left: -7px;
position: relative;

  }


  .btnup:hover{

 background-color: #a5707a;
  color: black;
  font-weight: bold;



  }
  .fn{

align-items: center;

  }

  .com{
 
 align-items: center;

  }
  .divup{
    padding: 10px;
  }


  details > summary {
  list-style: none;

}
.allofthelist{

width: 70%;
position: absolute;
float: left;
left: 3%;

}

/*.cpr{

  padding: 12px;
  margin: 12px;
  position: absolute;

  text-align: center;
 cursor: not-allowed;
  top: 99%;
  left: 30%;
  
}*/
 
details > summary {
  list-style: none;
}

#left{
   position: absolute; 
   left:0;
}


 
  </style>
  <button onclick='topFunction()' id='topBtn' title='Go to top'><span class="material-symbols-outlined">arrow_upward</span></button>
  <div style="padding: 29px;" id="hhdd" hidden>
    <span style="text-align: center; position: absolute; left: 2px; margin: 15px; padding: 15px; font-family: 'Reem Kufi', sans-serif; ">
    <p>MINISTRY OF HEALTH AND POPULATION</p>
    <p>SPECIALIZED MEDICAL CENTER</p>
    <p>Agouza Hospital</p>
    </span>
    <img src="./img/rrrrr.png" style="width:10%;position: relative; left: 46%;">
    <span style="text-align: center; position: absolute; right: 2px; margin: 15px; padding: 15px;font-family: 'Reem Kufi', sans-serif;">
      <p>وزارة الصحة والسكان</p>
    <p>امانة المراكز الطبية المتخصصة</p>
    <p>مستشفى العجوزة</p>
    </span>
    <hr>
    <ti id="ti" hidden >Printing Date :- &nbsp; <?php date_default_timezone_set('Africa/Cairo'); $timee = date('d/m/Y, h:i:s A'); echo ($timee);?>&nbsp;   ||  &nbsp; Printer user : <?php echo $_SESSION['user'];?></ti>

  </div>
  <br  id="brh" hidden>

  <div style="display: flex; justify-content: center;"><span style="font-size: 30px; padding: 4px; margin: 3px;font-family: 'Reem Kufi', sans-serif; " id="heed2" hidden>عرض بيانات مريض</span></div>
  <hr id="brh" hidden>

 <co class="co" hidden>
<?php

require_once('connect.php');


?>
</co>
  <?php
 
$unique_id =$_GET['unique_id'];

$query = "SELECT * FROM patient_login_eo WHERE unique_id='$unique_id' ";
$query_run = mysqli_query($conn, $query);
if (mysqli_num_rows($query_run) > 0 ) {
    # code...
   foreach ($query_run as $row) {
    // code...
echo "
<div dir='rtl' id='paid' style='margin: 6px; padding: 2px;' hidden>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">اسم المريض :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[patient_name]&nbsp;<font color=\"red\"></font></span></span>
</div>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\">
  <span class=\"rnr-label\">الرقم الطبي :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[medical_number]&nbsp;<font color=\"red\"></font></span></span>
</div>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">تاريخ الميلاد :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[date_of_birth]&nbsp;<font color=\"red\"></font></span></span>
  <span class=\"rnr-label\" style='min-width: 0px;'>السن :</span><span class=\"rnr-label\" id='age' style='min-width: 0px;'>0</span>
</div>


    <div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
 <span class=\"rnr-label\">رقم هاتف المريض :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[pa_phone_num]</span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
   <span class=\"rnr-label\">الرقم القومي :</span>
  <span class=\"rnr-control style3\"><span id=\"pa_national_id\" class=\"rnr-nowrap\">$row[pa_national_id]</span></span>
</div>








<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\">
  <span class=\"rnr-label\">النوع :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[gender]&nbsp;<font color=\"red\"></font></span></span>
</div> 





<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">اسم المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[sponsor_name]&nbsp;<font color=\"red\"></font></span></span>
</div>
<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\">
  <span class=\"rnr-label\">درجة قرابة المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[spo_degree_of_kinship]&nbsp;<font color=\"red\"></font></span></span>
</div>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">رقم هاتف المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[spo_phone_num]&nbsp;<font color=\"red\"></font></span></span>
</div>

</div>



";

}}




// $unique_id =$_GET['unique_id'];

$query4 = "SELECT * FROM eo_uploaded_files WHERE unique_id='$unique_id' ";

$query_run4 = mysqli_query($conn, $query4);
if (mysqli_num_rows($query_run4) > 0 ) {
    # code...
   
    // code...


  echo "

  <div class='show' hidden>
   <hr>
   <br>

<span style='text-align:center;justify-items: center;display: grid;font-family: \"Reem Kufi\", sans-serif; font-size:20px;'>ملفات تم ارفاقها</span> </div>";



  while($row = $query_run4->fetch_assoc() ){
    echo "

    <div class='show' hidden style='margin:6px; padding: 2px;'>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1\" dir='ltr'>
 
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><a href='uploads/eo_uploads/$row[file_Full_Name]' target=\"_blank\">$row[file_Full_Name]</a>&nbsp;&nbsp;&nbsp;<font color=\"red\"></font></span></span>&nbsp;&nbsp;&nbsp;&nbsp;<span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[added_by]</span>&nbsp;&nbsp;&nbsp;&nbsp;<span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[added_on]</span>
</div>
</div>



";
}

}






 

$query22 = "SELECT * FROM patient_eo_logs WHERE unique_id='$unique_id' ";
$query_run22 = mysqli_query($conn, $query22);
if (mysqli_num_rows($query_run22) > 0) {
    # code...

echo "<div class='show'  hidden>";

  echo "



<hr>
<span style='text-align:center;justify-items: center;display: grid;font-family: \"Reem Kufi\", sans-serif; font-size:30px;'>السجلات</span>
<hr>";

echo "<table  style=\"width:99%; font-size: 15px; font-family: sans-serif; margin: 7px; padding: 4px;\" dir='rtl'>";

echo "
  <tr>


  <th style=\"background-color :#2E2D2D; color:white;\">اسم المريض </th>


   <th style=\"background-color :#2E2D2D; color:white;\" >الرقم الطبي</th>
   <th style=\"background-color :#1c562b; color:white;\" >تاريخ الدخول</th>
   <th style=\"background-color :#721d1d; color:white;\" >تاريخ الخروج</th>

   <th style=\"background-color :#2E2D2D; color:white;\"  >نوع الدخول</th>

   <th style=\"background-color :#2E2D2D; color:white;\" >القسم</th>

    <th style=\"background-color :#2E2D2D; color:white;\">الحجرة</th>

    <th style='background-color :#2E2D2D; color:white;' >الدرجة</th>
    <th style='background-color :#2E2D2D; color:white;' >الطبيب</th>
    <th style='background-color :#2E2D2D; color:white;' >التخصص</th>
    <th style='background-color :#2E2D2D; color:white;' >المعاملة المالية</th>
    <th style='background-color :#2E2D2D; color:white;' >التامين</th>
    <th style='background-color :#2E2D2D; color:white;' >حالة الملف</th>
    <th style='background-color :#2E2D2D; color:white;' >الاضافه</th>
    <th style='background-color :#2E2D2D; color:white;' >التعديل</th>
    <th style='background-color :#2E2D2D; color:white;' >تاريخ</th>
   

    

    


    
    
  </tr>
 


";




  while($row = $query_run22->fetch_assoc() ){
 
 


echo "<div class='show' hidden><tr>";

      echo "<td>$row[patient_name]</td>";
      echo "<td>$row[medical_number]</td>";
      echo "<td style='font-size:13px;'>$row[date_of_entry]</td>";
      echo "<td style='font-size:13px;'>$row[exit_date]</td>";
      echo "<td>$row[entry_type]</td>";
      echo "<td>$row[section]</td>";
      echo "<td>$row[room]</td>";
      echo "<td>$row[grade]</td>";
      echo "<td>$row[doctor]</td>";
      echo "<td>$row[specialization]</td>";
      echo "<td>$row[financial_transaction]</td>";
      echo "<td>$row[health_insurance_beneficiary]</td>";
      echo "<td><rs>$row[record_status]</rs></td>";
      echo "<td style='font-size:10px;'>$row[added_by]</td>";
      echo "<td style='font-size:10px;'>$row[last_edit_by]</td>";
      echo "<td style='font-size:10px;'>$row[added_on]</td>";
      

     

      
      
      
      
        //echo "<td>$row[ip]</td>";
      


      echo "</tr></div>";




}
 
echo "</table>";
echo "</div>";

   }


 
?>
<hr id="brh" hidden>
<br id="brh" hidden>
<!-- 

<div id="content" style="display: grid; justify-content:center;" hidden>

  <div id="pageFooter" hidden>Page </div>
   
</div>
 -->
 
<div class="eocontainer" style="width: 73%; background-color: ; position: absolute; left: 2%;">


  <div style="" id="heeed"><span style="font-size: 30px; border: 2px #958997 solid; padding: 4px; margin: 3px; box-shadow: 3px 3px 50px 3px #4c1943; font-weight: bold; border-radius: 12px; text-shadow: 8px 6px 8px #784a73;font-family: 'Reem Kufi', sans-serif; " id="heed">عرض بيانات مريض</span></div>
 
<hr class="hrh">
<div>
  <title>View</title>






<style type="text/css">
  

.box{
  display: none;
}
  table {
   font-family: 'Reem Kufi', sans-serif;
  border-collapse: collapse;
  width: 100%;
}

  td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}



/*.body{
  position: absolute;
  right: 37%;
  width: 50%;
}*/


 .w3-sidebar{

     position: relative;
     right: 0;
     top: 0;
  }

   .sessiondiv{

    position: relative;
    top:  -13px;

   }

     header{

  position: absolute;
  left: 0;
  padding: 10px;

  }


 @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){

#divco{
    overflow: scroll;
    width: 100%;
    position: relative;
  }

  #heeed{
    display: flex;
    justify-content: center;
    position: relative;
     

 }

  }
 
 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){

.body{
  

     top: 169px;
    position: absolute;
    right: -30%;
    width: 130%;

}


 #heeed{
    display: flex;
    justify-content: center;
    position: relative;
    top: 81px;
    left: 100px;

 }
 #divco{
    overflow: scroll;
    width: 100%;
    position: relative;
  }


 }
@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){

.body{
  position: absolute;
    left: 6%;
    top: 162px;
    width: 120%;
}

  #divco{
    overflow: scroll;
    width: 100%;
    position: relative;
  }

#left{
    position: relative; 
    
}


/*#myTable{
  overflow: scroll;
  display: none;
}
#logstitlespan{
  display: none;
  visibility: hidden;
}*/
 .sglat{
  font-size: 7px;
 }
 #heeed{
    display: flex;
    justify-content: center;
    position: relative;
    top: 81px;
    left: 45px;
 }



.export_button {
    font-size: 10px;
    border: none;
    outline: none;
    color: white;
    cursor: pointer;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

}

</style>



<body dir="ltr">

<div class="body">
<?php
ob_start(); 
/*

fullname
pcuser
pcpass
login
shifttime
sitestatus
arrivalstatus

*/








@session_start();



    

ob_end_flush();
?>
          
<!--

<div class="addnewbox" style="position:relative; left: 30%; width:40%; height:80%; background-color: gray;">


<tr>


<td>

<br>


<th>

<p>your name : </p>
</th>
</td>
<td>
<input type="text"  width:20PX; placeholder="" >
</td>
</tr>
</div>
  -->
  <!--Connection-->  <!--Connection-->
  <co class="co">
<?php

require_once('connect.php');


?>
</co>

<br id="brh" hidden>
<br id="brh" hidden>
 
<h3 style="text-align: center; font-size: 230%; font-family: cursive;" id="ht">( Viewing Reports Area )</h3>
<br id="brh" hidden>
 
<hr color="black" size="5" class="hrh">


<br><br>
<form method="POST" name="myform" autocomplete="on" id="myform"  style="" dir="rtl"  >
<div class="rnr-brickcontents style1 rnr-b-wrapper  rnr-wrapper rnr-cbw-fields"  >

<div class="rnr-cw-fields rnr-s-fields asbuttons MetroOffice"    id="conup">
<div class="rnr-c rnr-cv rnr-c-fields">


<div class="rnr-brickcontents style2 rnr-b-addheader " id="neww" ><span> <h1 style="font-family: 'Reem Kufi', sans-serif;">عرض بيانات مريض</h1>
</span></div>
<div class="rnr-brickcontents style2 rnr-b-addheader " id="neww2"><span> <h1></h1>
</span></div>

<div class="rnr-brickcontents style2 rnr-b-addheader "  id="neww3" ><span> <h1 style="font-family: 'Reem Kufi', sans-serif;"> Record id :  <input type="text"  style="border-radius: 7px; background-color: black; color: white; border: none; outline: none;" readonly=""  id="unique_id" name="unique_id" maxlength="24" value="<?php $unique_id =$_GET['unique_id']; echo $unique_id; ?>"/></h1>
</span></div>
 

 
 

<div class="rnr-brickcontents style1 rnr-b-addfields_simple "><div class="rnr-simplefields edit">
  


  <?php

$unique_id =$_GET['unique_id'];

$query = "SELECT * FROM patient_login_eo WHERE unique_id='$unique_id' ";
$query_run = mysqli_query($conn, $query);
if (mysqli_num_rows($query_run) > 0 ) {
    # code...
   foreach ($query_run as $row) {
    // code...

 


echo "


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \" id=\"left\">
 <span class=\"rnr-label\">رقم هاتف المريض :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[pa_phone_num]</span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
   <span class=\"rnr-label\">الرقم القومي :</span>
  <span class=\"rnr-control style3\"><span id=\"pa_national_id\" class=\"rnr-nowrap\">$row[pa_national_id]</span></span>
</div>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\" id=\"left\">
  <span class=\"rnr-label\">الرقم الطبي :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[medical_number]&nbsp;<font color=\"red\"></font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">اسم المريض :</span>
  <span class=\"rnr-control style3\"><span id=\"patient_name\" class=\"rnr-nowrap\">$row[patient_name]&nbsp;<font color=\"red\"></font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\"  id=\"left\">
  <span class=\"rnr-label\">النوع :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[gender]&nbsp;<font color=\"red\"></font></span></span>
</div> 

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">تاريخ الميلاد :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[date_of_birth]&nbsp;<font color=\"red\"></font></span></span>
  <span class=\"rnr-label\" style='min-width: 0px;'>السن :</span><span class=\"rnr-label\" id='age' style='min-width: 0px;'>0</span>
</div>

 <hr>

 <div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\" id=\"left\">
  <span class=\"rnr-label\">درجة قرابة المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[spo_degree_of_kinship]&nbsp;<font color=\"red\"></font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">اسم المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[sponsor_name]&nbsp;<font color=\"red\"></font></span></span>
</div>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">رقم هاتف المرافق :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[spo_phone_num]&nbsp;<font color=\"red\"></font></span></span>
</div>


<hr>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\" id=\"left\">
  <span class=\"rnr-label\">الطبيب :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[doctor]&nbsp;<font color=\"red\"></font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">تاريخ الدخول :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[date_of_entry]&nbsp;<font color=\"red\"></font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\"  id=\"left\">
  <span class=\"rnr-label\">التخصص :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[specialization]&nbsp;<font color=\"red\"></font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">نوع الدخول :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[entry_type]&nbsp;<font color=\"red\"></font></span></span>
</div>

 
<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\" id=\"left\">
  <span class=\"rnr-label\">اذن القبول :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[acceptance_permission]&nbsp;<font color=\"red\"></font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">القسم :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[section]&nbsp;<font color=\"red\"></font></span></span>
</div>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\"  id=\"left\">
  <span class=\"rnr-label\">المعاملة المالية :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[financial_transaction]&nbsp;<font color=\"red\"></font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">الحجرة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[room]&nbsp;<font color=\"red\"></font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\" id=\"left\">
  <span class=\"rnr-label\">اسم الكفيل :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">&nbsp;<font color=\"red\"></font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">الدرجة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[grade]&nbsp;<font color=\"red\"></font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\" id=\"left\">
  <span class=\"rnr-label\">منتفع بالتامين الصحي :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[health_insurance_beneficiary]&nbsp;<font color=\"red\"></font></span></span>
</div>



<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">نتيجة العينة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[sample_result]&nbsp;<font color=\"red\"></font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\"  id=\"left\">
  <span class=\"rnr-label\">كود منشآة المسح :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[scan_facility_code]&nbsp;<font color=\"red\"></font></span></span>
</div>


<div data-fieldname=\"Ticket\" class=\"rnr-field style1 \">
  <span class=\"rnr-label\">المركز المحال اليه :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[referred_center]&nbsp;<font color=\"red\"></font></span></span>
</div>


















 



<hr>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\"  id=\"left\">
  <span class=\"rnr-label\">حالة الملف :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[record_status]&nbsp;<font color=\"red\"></font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1\" >
  <span class=\"rnr-label\">تم الاضافه بواسطة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[added_by]&nbsp;<font color=\"red\"></font></span></span>
</div>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\"  id=\"left\">
  <span class=\"rnr-label\">نوع الخروج :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[exit_type]&nbsp;<font color=\"red\"></font></span></span>
</div>




<div data-fieldname=\"Ticket\" class=\"rnr-field style1\">
  <span class=\"rnr-label\">تم التعديل بواسطة :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[last_edit_by]&nbsp;<font color=\"red\"></font></span></span>
</div>
<div class='exit_date_box' id='خروج'>
<div data-fieldname=\"Ticket\" class=\"rnr-field style1 s\"  id=\"left\">
  <span class=\"rnr-label\">تاريخ الخروج :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[exit_date]&nbsp;<font color=\"red\"></font></span></span>
</div>
</div>

<div data-fieldname=\"Ticket\" class=\"rnr-field style1\">
  <span class=\"rnr-label\">تاريخ اخر تعديل :</span>
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[added_on]&nbsp;<font color=\"red\"></font></span></span>
</div>





";

     





   }
}
else{
   
   echo "<p style='font-size: 30px; text-align:center;font-family: \"Reem Kufi\", sans-serif;' id='lau'>لا يوجد ملفات تم ارفاقها</p>";
  
  }



 







?>





<div data-fieldname="Ticket" class="rnr-field style1 " hidden="hidden">
  
  <span class="rnr-control style3\"><span id="edit1_Ticket_0" class="rnr-nowrap"><input id="last_edit_by" style="width: 200px;" type="text" name="last_edit_by"  value="<?php echo $_SESSION['user'];?>"readonly>&nbsp;<font color="red">*</font></span></span>
</div>


<div data-fieldname="Ticket" class="rnr-field style1" hidden="hidden">
 
  <span class="rnr-control style3"><span id="edit1_Ticket_0" class="rnr-nowrap"><input id="added_on" style="width: 200px;" type="text" name="added_on"  value=" <?php date_default_timezone_set('Africa/Cairo'); $timeee = date('d/m/Y, h:i:s A'); echo ($timeee);?>" readonly>&nbsp;<font color="red">*</font></span></span>
</div>






<!--
  



  





<div data-fieldname="SMS" class="rnr-field style1 ">
  <span class="rnr-label">SMS</span>
  <span class="rnr-control style3"><span id="edit1_SMS_0" class="rnr-nowrap"><input id="value_SMS_1" type="hidden" name="value_SMS_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_SMS_1_0" name="radio_SMS_1" value="1"> <span id="label_radio_SMS_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_SMS_1_1" name="radio_SMS_1" value="0"> <span id="label_radio_SMS_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="Ststus" class="rnr-field style1 ">
  <span class="rnr-label">Ticket Status</span>
  <span class="rnr-control style3"><span id="edit1_Ststus_0" class="rnr-nowrap"><select size="1" id="value_Ststus_1" name="value_Ststus_1" style="width: 207px"><option value="">Please select</option><option value="Open">Open</option><option value="Waiting For Response">Waiting For Response</option><option value="In-progress">In-progress</option><option value="Waiting For Customer">Waiting For Customer</option><option value="Call Back">Call Back</option><option value="Offline">Offline</option><option value="MSAN Replace">MSAN Replace</option><option value="Major Faults">Major Faults</option><option value="Internal Wiring Vendor Visit">Internal Wiring Vendor Visit</option><option value="Major Fault (Direct)">Major Fault (Direct)</option><option value="Engineering inspection ÊÝÊíÔ åäÏÓì">Engineering inspection ÊÝÊíÔ åäÏÓì</option></select>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="follow_process" class="rnr-field style1 ">
  <span class="rnr-label">Follow Process</span>
  <span class="rnr-control style3"><span id="edit1_follow_process_0" class="rnr-nowrap"><input id="value_follow_process_1" type="hidden" name="value_follow_process_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_follow_process_1_0" name="radio_follow_process_1" value="Yes"> <span id="label_radio_follow_process_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_follow_process_1_1" name="radio_follow_process_1" value="No"> <span id="label_radio_follow_process_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="on_shift" class="rnr-field style1 ">
  <span class="rnr-label">On Shift</span>
  <span class="rnr-control style3"><span id="edit1_on_shift_0" class="rnr-nowrap" style="display: none;"><input id="value_on_shift_1" type="hidden" name="value_on_shift_1" value=""><div class="rnr-horizontal-lookup"><span><input type="Radio" class="rnr-radio-button" id="radio_on_shift_1_0" name="radio_on_shift_1" value="1"> <span id="label_radio_on_shift_1_0" class="rnr-radio-label">Yes</span></span><span><input type="Radio" class="rnr-radio-button" id="radio_on_shift_1_1" name="radio_on_shift_1" value="0"> <span id="label_radio_on_shift_1_1" class="rnr-radio-label">No</span></span></div>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="follow_up_time" class="rnr-field style1 ">
  <span class="rnr-label">Follow Date</span>
  <span class="rnr-control style3"><span id="edit1_follow_up_time_0" class="rnr-nowrap" style="display: none;"><input id="type_follow_up_time_1" type="hidden" name="type_follow_up_time_1" value="date11"><input id="value_follow_up_time_1" style="width: 200px;" type="Text" name="value_follow_up_time_1" value=""><input id="tsvalue_follow_up_time_1" type="Hidden" name="tsvalue_follow_up_time_1" value="0-0-0">&nbsp;<a href="#" id="imgCal_value_follow_up_time_1" data-icon="calendar" title="Click Here to Pick up the date"></a></span></span>
</div>

  
<div data-fieldname="follow_time" class="rnr-field style1 ">
  <span class="rnr-label">Follow Time</span>
  <span class="rnr-control style3"><span id="edit1_follow_time_0" class="rnr-nowrap" style="display: none;"><input id="type_follow_time_1" style="width: 200px;" type="hidden" name="type_follow_time_1" value="time"><input type="text" style="width: 200px;" name="value_follow_time_1" id="value_follow_time_1" value="">&nbsp;<a class="rnr-imgclock" data-icon="timepicker" title="Time" style="display: inline-block; margin: 4px 0px 0px 6px; visibility: visible;" id="trigger-test-value_follow_time_1"></a>&nbsp;<font color="red">*</font></span></span>
</div>

  
<div data-fieldname="Comment" class="rnr-field style1 ">
  <span class="rnr-label">Comment</span>
  <span class="rnr-control style3"><span id="edit1_Comment_0" class="rnr-nowrap"><textarea id="value_Comment_1" name="value_Comment_1" style="width: 200px;height: 100px;"></textarea></span></span>
</div>

  
<div data-fieldname="integration_problem" class="rnr-field style1 ">
  <span class="rnr-label">Integration Problem</span>
  <span class="rnr-control style3"><span id="edit1_integration_problem_0" class="rnr-nowrap"><input id="type_integration_problem_1" type="hidden" name="type_integration_problem_1" value="checkbox"><input id="value_integration_problem_1" type="Checkbox" name="value_integration_problem_1"></span></span>
</div>

  
<div data-fieldname="new_pilot" class="rnr-field style1 ">
  <span class="rnr-label">Valid for proactive concession</span>
  <span class="rnr-control style3"><span id="edit1_new_pilot_0" class="rnr-nowrap" style="display: none;"><select size="1" id="value_new_pilot_1" name="value_new_pilot_1" style="width: 207px"><option value="">Please select</option><option value="Yes">Yes</option><option value="No">No</option></select></span></span>
</div>

</div>
</div>
-->


<div class="rnr-brickcontents style2 rnr-b-addbuttons " id="newwbuttom"><div class="rnr-buttons-left">
    
  <!--
  <input type="submit" class="rnr-button main" name="update" id="update" value="Update">
  
 
  <input type="submit" class="rnr-button main" name="check" id="check" value="check" > 
  
  -->

   <button type="button" id="export_button" class="export_button">تصدير بيانات إلى Excel</button>&nbsp;<i class='fa fa-table' id="export_button2"></i>

  <a onclick="history.back()"  style="cursor: pointer;" class="rnr-button"  name="back" id="backButton1">الرجوع</a>

 <?php  if (access('EO'  , false)): ?> 
<button   class="rnr-button main" id="editbtn"  name="editbtn" style="cursor: pointer; background-color: #d76666; color: black;">تعديل</button>
<?php endif; ?>

<button   class="rnr-button main" id="printeo"  onclick="window.print()" name="printeo" style="cursor: pointer;">طباعة</button>


  <!--
  <input type="submit" class="rnr-button main" name="delete" id="delete" style="position: relative; left: 70px;" value="Delete">
   -->


</div>
</div>


</div>
</div>

</div>



 
</form>

</div>

 <?php 

 if(isset($_POST['editbtn'])){

         
  @$unique_id =$_GET['unique_id'];


           echo "<script> window.location.href=('../test3/edit2_patient_eo_logs.php?unique_id=$unique_id');</script>";
           
        
  
}



 ?>


<?php




$unique_id =$_GET['unique_id'];

$query4 = "SELECT * FROM eo_uploaded_files WHERE unique_id='$unique_id' ";

$query_run4 = mysqli_query($conn, $query4);
if (mysqli_num_rows($query_run4) > 0 ) {
    # code...
   
    // code...


  echo "



  <div class='hrh'>
  <hr>

<span style='text-align:center;justify-items: center;display: grid;font-family: \"Reem Kufi\", sans-serif; font-size:20px;'>ملفات تم ارفاقها</span></div>";


  while($row = $query_run4->fetch_assoc() ){
    echo "

     <div class='sglat'>
  <div class='hrh'>
<div data-fieldname=\"Ticket\" class=\"rnr-field style1\" dir='ltr'>
 
  <span class=\"rnr-control style3\"><span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\"><a href='uploads/eo_uploads/$row[file_Full_Name]' target=\"_blank\">$row[file_Full_Name]</a>&nbsp;&nbsp;&nbsp;<font color=\"red\"></font></span></span>&nbsp;&nbsp;&nbsp;&nbsp;<span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[added_by]</span>&nbsp;&nbsp;&nbsp;&nbsp;<span id=\"edit1_Ticket_0\" class=\"rnr-nowrap\">$row[added_on]</span>
</div>
</div>
</div>

";

}

}
?>

  <?php


 




$unique_id =$_GET['unique_id'];

$query2 = "SELECT * FROM patient_eo_logs WHERE unique_id='$unique_id' ";
$query_run2 = mysqli_query($conn, $query2);
if (mysqli_num_rows($query_run2) > 0) {
    # code...



  echo "

<div class='hrh'>

<hr>
<span style='text-align:center;justify-items: center;display: grid;font-family: \"Reem Kufi\", sans-serif; font-size:30px;'>السجلات</span>
<hr>";
echo "<div id='divco'>";
echo "<table  id=\"myTable\" style=\"width:99.9%; font-size: 15px; font-family: sans-serif; \">";

echo "
  <tr>


  <th style=\"background-color :#2E2D2D; color:white;\" id=\"th1\">اسم المريض </th>


   <th style=\"background-color :#2E2D2D; color:white;\" id=\"th2\">الرقم الطبي</th>
   <th style=\"background-color :#1c562b; color:white;\" id=\"tht\">تاريخ الدخول</th>
   <th style=\"background-color :#721d1d; color:white;\" id=\"tht\">تاريخ الخروج</th>

   <th style=\"background-color :#2E2D2D; color:white;\" id=\"th4\">نوع الدخول</th>

   <th style=\"background-color :#2E2D2D; color:white;\" id=\"th5\">القسم</th>

    <th style=\"background-color :#2E2D2D; color:white;\" id=\"th6\">الحجرة</th>

    <th style='background-color :#2E2D2D; color:white;' id=\"th7\">الدرجة</th>
    <th style='background-color :#2E2D2D; color:white;' id=\"th8\">الطبيب</th>
    <th style='background-color :#2E2D2D; color:white;' id=\"th9\">التخصص</th>
    <th style='background-color :#2E2D2D; color:white;' id=\"th10\">المعاملة المالية</th>
    <th style='background-color :#2E2D2D; color:white;' id=\"th11\">التامين</th>
    <th style='background-color :#2E2D2D; color:white;' id=\"th12\">حالة الملف</th>
    <th style='background-color :#2E2D2D; color:white;' id=\"th13\">الاضافه</th>
    <th style='background-color :#2E2D2D; color:white;' id=\"th14\">التعديل</th>
    <th style='background-color :#2E2D2D; color:white;' id=\"th15\">تاريخ</th>
   

    

    


    
    
  </tr>
</div>


";




  while($row = $query_run2->fetch_assoc() ){
 
 


echo "<div class='hrh'><tr>";

      echo "<td>$row[patient_name]</td>";
      echo "<td>$row[medical_number]</td>";
      echo "<td style='font-size:13px;'>$row[date_of_entry]</td>";
      echo "<td style='font-size:13px;'>$row[exit_date]</td>";
      echo "<td>$row[entry_type]</td>";
      echo "<td>$row[section]</td>";
      echo "<td>$row[room]</td>";
      echo "<td>$row[grade]</td>";
      echo "<td>$row[doctor]</td>";
      echo "<td>$row[specialization]</td>";
      echo "<td>$row[financial_transaction]</td>";
      echo "<td>$row[health_insurance_beneficiary]</td>";
      echo "<td><rs>$row[record_status]</rs></td>";
      echo "<td style='font-size:10px;'>$row[added_by]</td>";
      echo "<td style='font-size:10px;'>$row[last_edit_by]</td>";
      echo "<td style='font-size:10px;'>$row[added_on]</td>";
      

     

      
      
      
      
        //echo "<td>$row[ip]</td>";
      


      echo "</tr></div>";




}
 
echo "</table>";
echo "</div>";

   }




    ?>
  
</div>



<?php

 









if (@$_SESSION['type']=='admin' ) {

        echo "<script>document.getElementById('unique_id').style.backgroundColor = '#081a36';</script>";

         echo "<script>document.getElementById('added_by').style.backgroundColor = '#bfdeef';</script>";
          echo "<script>document.getElementById('last_edit_by').style.backgroundColor = '#bfdeef';</script>";
           echo "<script>document.getElementById('added_on').style.backgroundColor = '#bfdeef';</script>";
 
        echo "<script>document.getElementById('neww').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('heed').style.boxShadow = '3px 3px 50px 3px #21478b';</script>";
        echo "<script>document.getElementById('heed').style.textShadow = '8px 6px 8px #143970';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#081a36';</script>";
       
        
 





  }elseif (@$_SESSION['type']=='it_user' || @$_SESSION['type']=='ad_it_user') {

      
  echo "<script>document.getElementById('unique_id').style.backgroundColor = '#15483f';</script>";
 
        echo "<script>document.getElementById('added_by').style.backgroundColor = '#799f96';</script>";
        echo "<script>document.getElementById('last_edit_by').style.backgroundColor = '#799f96';</script>";
        echo "<script>document.getElementById('added_on').style.backgroundColor = '#799f96';</script>";

        echo "<script>document.getElementById('neww').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('heed').style.boxShadow = '3px 3px 50px 3px #15483f';</script>";
        echo "<script>document.getElementById('heed').style.textShadow = '8px 6px 8px #15483f';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#15483f';</script>";
         
 

     
  }elseif (@$_SESSION['type']=='eo_user') {

      
  echo "<script>document.getElementById('unique_id').style.backgroundColor = '#1c2827';</script>";
 
        echo "<script>document.getElementById('added_by').style.backgroundColor = '#799f96';</script>";
        echo "<script>document.getElementById('last_edit_by').style.backgroundColor = '#799f96';</script>";
        echo "<script>document.getElementById('added_on').style.backgroundColor = '#799f96';</script>";

        echo "<script>document.getElementById('neww').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('heed').style.boxShadow = '3px 3px 50px 3px #1c2827';</script>";
        echo "<script>document.getElementById('heed').style.textShadow = '8px 6px 8px #1c2827';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#1c2827';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#1c2827';</script>";
        
 

     
  }elseif (@$_SESSION['type']=='eo_viewer') {

      
  echo "<script>document.getElementById('unique_id').style.backgroundColor = 'gray';</script>";
 
        echo "<script>document.getElementById('neww').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = 'gray';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = 'gray';</script>";
     
  }else{
            echo "<script>function(){ history.back(); }</script>";
  }


?>
