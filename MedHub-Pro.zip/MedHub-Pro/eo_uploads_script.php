<?php



if (isset($_POST['eo_upload'])) {
	# code...

//$newFlieName = $_POST['filename'];

// if (empty($_POST['filename'])) {
//    	// code...
// $newFlieName = "sheet";


//    } else{
//         $newFlieName =strtolower(str_replace(" ", "_", $newFlieName));


//    }  

// $fileTitle = strip_tags($_POST['filetitle']);

// $fileDesc = strip_tags($_POST['filedesc']);

// $addedon = $_POST['addedon'];

$file = $_FILES['file'];
//print_r($file);


 $fileName = $file["name"];
 $fileTmpName = $file["tmp_name"];
 $fileSize = $file["size"];
 $fileError = $file["error"];
 $fileType = $file["type"];
@$medical_number                 = strip_tags($_POST['medical_number']);


$fileExt = explode('.', $fileName);
$fileActualExt = strtolower(end($fileExt));



 //////////////////////////////second phase//////////////////.....
$fileNameExt = explode('.', $fileName);
 $fileActualName = strtolower(current($fileNameExt));
 //////////////////////////////second phase//////////////////.....




$allowed = array('jpg','png','jpeg');

if (in_array($fileActualExt, $allowed)) {
	// code...
	if ($fileError === 0 ) {

////
      
   if ($fileSize < 1000000) {
 			// code...
 			
 $fileNameNew = uniqid(str_replace(" ", "_", $medical_number."_".$fileActualName)."____" , false).".".$fileActualExt;

             $fileDestination = 'uploads/eo_uploads/'.$fileNameNew;
             
            


       

       	    


           $sql = "SELECT * FROM eo_uploaded_files;";
           $stmt = mysqli_stmt_init($conn);
           if (!mysqli_stmt_prepare($stmt,$sql)) {
           	// code...
           	echo "SQL Failed";

           }else{
           	mysqli_stmt_execute($stmt);
           	$result = mysqli_stmt_get_result($stmt);
           	$rowCount = mysqli_num_rows($result);
           	$setfileOrder = $rowCount + 1;
           	$ip = $_SERVER['REMOTE_ADDR'];
@$unique_id                      = strip_tags($_POST['unique_id']);
@$medical_number                 = strip_tags($_POST['medical_number']);
@$patient_name                   = strip_tags($_POST['patient_name']);
@$pa_national_id                 = strip_tags($_POST['pa_national_id']);
@$added_by                       = strip_tags($_POST['added_by']);
@$added_on                       = strip_tags($_POST['added_on']);


            
            $sql = "INSERT INTO eo_uploaded_files (unique_id, medical_number, pa_national_id, patient_name, file_Full_Name , added_by , added_on) VALUES(?,?,?,?,?,?,?) ;";
            if (!mysqli_stmt_prepare($stmt, $sql)) {
           	// code...
           	echo "SQL Failed2";

           }else{

            
           	mysqli_stmt_bind_param($stmt, "sssssss", $unique_id, $medical_number, $pa_national_id , $patient_name ,$fileNameNew ,$added_by ,$added_on);

            mysqli_stmt_execute($stmt);



            move_uploaded_file($fileTmpName, $fileDestination);

              //include_once 'connect.php'; 


            //echo "<br><br><n style='color:green';>Your File Uploaded Successfully</n>";
            echo "upload=Success";
            echo "<script> window.location.href=('edit2_patient_eo_logs.php?unique_id=$unique_id');</script>";
        exit();


           }

           

       }






 			}else{
 			echo "<br><br><n style='color:red; position: relative; top:-145px;' >This File Is Too Big ! ".$fileSize/1000000 . " _MB , </n>";
 			//echo "<br><br>";
      echo "<n1 style=' position: relative; top:-145px;' >Try Something Smaller Than ( 3_MB )</n1>";

      //echo "<script> window.location.href=('upload.php?file=size');</script>";
        exit();
 		}
  
	}else{
 		echo "<br><br><n style='color:red; position: relative; top:-145px;'>There An Error While uploading The File !</n>";
 	}

}else{
	echo "<br><br><n style='color:red;  position: relative; top:-145px;'>You Can't Upload Files Of This Type" . "__" . "(<mark>." . $fileActualExt ."</mark>)</n>";
	exit();
}


}




