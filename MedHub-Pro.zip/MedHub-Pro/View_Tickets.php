<co hidden>
	
	<?php require_once('connect.php');
 
		



	?>



</co>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />

<style type="text/css">
	
	.title-container {
  position: relative;
  display: inline-block;
  display: flex;
      justify-content: center;
      align-items: center;
}

.title {
  font-size: 90px;
  color: #FF4081; /* Rose */
  position: relative;
  display: inline-block;
  text-transform: uppercase;
  transition: transform 0.3s ease-in-out;
}

.title:hover {
  transform: scale(1.1);
  animation: title 6s infinite;
}

@keyframes title {
  0% { transform: scale(1); }
  50% { transform: scale(1.2); }
  100% { transform: scale(1); }
}



    /* CSS for table */
   .tickets-table {
  width: 100%;
  border-collapse: collapse;
  font-family: Arial, sans-serif;
  color: #555;
  background-color: #f5f5f5;
}

.tickets-table th,
.tickets-table td {
  padding: 16px;
  text-align: left;
}

.tickets-table th {
  background-color: #333;
  color: #fff;
  text-transform: uppercase;
}

.tickets-table td {
  background-color: #fff;
  border-bottom: 1px solid #ddd;
  transition: background-color 0.3s ease;
}

.tickets-table tbody tr:hover {
  background-color: #f9f9f9;
}

.tickets-table tbody tr:hover td {
  background-color: #d9d9d9;
}

.tickets-table tbody tr:hover .status.open {
  color: #e74c3c;
  background-color: #ffcccc;
}

.tickets-table tbody tr:hover .status.pending {
  color: #f39c12;
  background-color: #ffe5cc;
}

.tickets-table tbody tr:hover .status.in-progress {
  color: #3498db;
  background-color: #cce5ff;
}

.tickets-table tbody tr:hover .status.closed {
  color: #2ecc71;
  background-color: #e6ffe6;
}

.tickets-table tbody tr:last-child td {
  border-bottom: none;
}

.tickets-table .ticket-id {
  font-weight: bold;
}


.tickets-table .status {
  font-weight: bold;
  transition: color 0.3s ease;
}

.tickets-table .status.open {
  color: #e74c3c;
}

.tickets-table .status.pending {
  color: #f39c12;
}

.tickets-table .status.in-progress {
  color: #3498db;
}

.tickets-table .status.closed {
  color: #2ecc71;
}

.tickets-table .ticket-id:before {
  content: "#";
  font-weight: normal;
  color: #aaa;
}

.tickets-table .ticket-id span {
  display: inline-block;
  vertical-align: middle;
  font-size: 18px;
  margin-left: 5px;
}

.tickets-table .title {
  font-size: 16px;
  color: #444;
}

.tickets-table .subject {
  font-size: 14px;
  color: #666;
}

.tickets-table .problem-type:before {
  content: "Problem Type: ";
  font-weight: normal;
  color: #aaa;
}

.tickets-table .status:before {
  content: "Status: ";
  font-weight: normal;
  color: #aaa;
}

.tickets-table .problem-type {
  font-weight: bold;
  color: #ff8c00;
}

.tickets-table .problem-type.password_issue {
  color: #e55598;
}

.tickets-table .problem-type.uploading_issue {
  color: #3bcfc2;
}

.tickets-table .problem-type.adding_issue {
  color: #897c23;
}

.tickets-table .problem-type.other {
  color: #9b59b6;
}

 .Logs {
        display: inline-block;
        padding: 5px 10px;
        background-color: #f2f2f2;
        color: #333;
        font-weight: bold;
        border-radius: 4px;
        display: flex;
        justify-content: center;
        align-items: center;   
         }

</style>

<div class="title-container">
  <h1 class="title"><i class="fas fa-ticket-alt"></i></h1>
</div>


<div id="popupFormView" class="popup-form">
  <div class="form-content">
 <!--    <span class="close-popup" onclick="closeViewPopup()">&times;</span> -->

    <h2>Ticket Details</h2>
    <div id="ticketDetails">
       <label for="ticketId">Ticket ID:</label>
           <input type="number" id="unique_id" name="unique_id" style="border: none; outline: none; width: 8%; font-size: 12px;"  onKeyPress="if(this.value.length==4) return false;" readonly=""  value="<?php $unique_id =$_GET['unique_id']; echo $unique_id; ?>" >

    </div>


  <?php



$unique_id =$_GET['unique_id'];

$query = "SELECT * FROM irtickets WHERE unique_id='$unique_id' ";
$query_run = mysqli_query($conn, $query);
if (mysqli_num_rows($query_run) > 0) {
    # code...
   foreach ($query_run as $row) {
    // code...
    echo "
     
    <p><strong>Title:</strong> $row[title]</p>
    <p><strong>Subject:</strong> $row[subject]</p>
    <p><strong>Problem Type:</strong> $row[problemtype]</p>
    <p><strong>Status:</strong> $row[status]</p>
    <p><strong>Comment:</strong> $row[comment]</p>
    <p><strong>Closing Reason:</strong> $row[closing_reason]</p>
    <p><strong>Added BY:</strong> $row[addedby]</p>
    <p><strong>TKT-Segmentation:</strong> $row[segmentation]</p>
    <p><strong>Date:</strong> $row[date]</p>
    <p><strong>Handler:</strong> $row[handler]</p>";
}
 }else{
   echo "<p style='font-size: 30px; text-align:center;='>There's None to View ..</p>";
  }
?>
  </div>
</div>
<hr>
<span class="Logs">Logs</span>

<br>



<?php



   
$sql = "SELECT * from irtickets_logs WHERE unique_id='$unique_id'";

$result = $conn->query($sql);

if ($result->num_rows > 0){

	echo "<table class='tickets-table'>
  <thead>
    <tr>
      <th>Ticket ID</th>
      <th>Title</th>
      <th>Subject</th>
      <th>Problem Type</th>
      <th>Status</th>
      <th>comment</th>
      <th>closing reason</th>
      <th>handler</th>
      <th>date</th>
    </tr>
  </thead>
  <tbody>";

	while($row = $result->fetch_assoc() ){


echo " <tr>
      <td class='ticket-id'>
        <span>$row[unique_id]</span>
        <div class='action-buttons'>
          
      </td>
      <td>$row[title]</td>
      <td>$row[subject]</td>
      <td class='problem-type $row[problemtype]'>$row[problemtype]</td>
      <td class='status $row[status]'>$row[status]</td>
      <td>$row[comment]</td>
      <td>$row[closing_reason]</td>
      <td>$row[handler]</td>
      <td>$row[date]</td>
    </tr>";
   
}

echo "</tbody></table>";

 }
else {
   echo "<p style='font-size: 30px; text-align:center;font-family: \"Reem Kufi\", sans-serif;'></p>";
}


	?>


