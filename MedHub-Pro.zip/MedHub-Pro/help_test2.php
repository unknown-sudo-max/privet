
  <!-- Header -->
<?php 
$start_time = microtime(TRUE);
require_once('header.php');


?>
<!-- End page content -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">

//   $(document).ready(function(){

// //Using setTimeout to execute a function after 5 seconds.
// setTimeout(function () {
//    //Redirect with JavaScript
//    window.history.pushState("/test2.php", "", '/test3/test2.php');
// }, 0);


// window.scrollTo(1000,0);

// });




</script>
<style>


* {box-sizing: border-box;}

body{ 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    

}
/*
body::before { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    content: "";
      background-image: url('pngegg.png');
      background-size: cover;
      position: absolute;
      top: 0px;
      right: 0px;
      bottom: 0px;
      left: 0px;
      opacity: 0.10;
      z-index: -1;
}
 */
#navbar {
  overflow: hidden;
  background-color: #9f8398;
  padding: 90px 10px;
  transition: 0.4s;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 99;

}

#navbar a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;

}
ul{

  list-style-image: url('fas fa-folder-open');
}
#navbar #logo {
  font-size: 35px;
  font-weight: bold;
  transition: 0.4s;

}

#navbar a:hover {
  background-color: #b99fb2;
  color: black;
}

#navbar a.active {
  background-color: #7d1d64;
  color: white;
}

#navbar-right {
  float: right;
  padding: 12px;
}

 
.container a {
  
  display: block;
  color: black;
  text-align: left;
  padding: 10px;
  
  font-size: 17px;
  list-style-image: url('sqpurple.gif');
}

.container a:hover {
  background-color: #ddd;
  color: black;
  border-radius: 5px;
  padding: 8;
  margin: 4;
  opacity: 0.5;

}

.container a.active {
  background-color: #2196F3;
  color: white;
  

}

.container{
float: left;
text-align: left;
position: absolute;
left: 1%;
width: 70%;

}

.list{
  width: 100%;
  align-items: left;

}

.ifrm{
  width: 100%;
  height: 100%;
  border: none;
}


.list li {
  list-style-type: 'fas fa-folder-open';
  list-style-type: '📂 ';
}

.logo{

  //display: block;
  position: relative;
  float: right;
  left:  -30px;
  width: 20%;
  height: 27%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}

.cpr{

 /* padding: 12px;
  margin: 12px;
  position: absolute;*/

  text-align: center;
 cursor: not-allowed;
  /*top: 84%;
  left: 30%;*/
  
}


img {
    width: 160px;
}

 .btnhelp {
    cursor: pointer;
    outline: 0;
    width: 180px;
    height: 48px;
    border-radius: 8px;
    background-color: #2C3138;
    margin-top: 40px;
    overflow: hidden;
    -webkit-transform: scale(.7);
            transform: scale(.7);
}

 .btnhelp::after {
    content: "";
    position: relative;
    top: -40px;
    display: block;
    width: 48px;
    height: 107%;
    background-color: #000;
    margin-top: -1px;
    margin-left: -7px;
    border-radius: 6px 0 0 6px;
   /* background-image: url('data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTRweCIgaGVpZ2h0PSIxN3B4IiB2aWV3Qm94PSIwIDAgMTQgMTciIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDUxLjEgKDU3NTAxKSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5TaGFwZTwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPjwvZGVmcz4KICAgIDxnIGlkPSJQYWdlLTEiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSJEZXNrdG9wLUhELUNvcHktMyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTYwOS4wMDAwMDAsIC0xMDA4LjAwMDAwMCkiIGZpbGw9IiNGOUZDRkYiIGZpbGwtcnVsZT0ibm9uemVybyI+CiAgICAgICAgICAgIDxnIGlkPSJHcm91cC0xMSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNTQ3LjAwMDAwMCwgNDk5LjAwMDAwMCkiPgogICAgICAgICAgICAgICAgPGcgaWQ9Ikdyb3VwLTYtQ29weSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNDYuMDAwMDAwLCA0OTUuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICAgICAgPGcgaWQ9ImljX2ZpbGVfZG93bmxvYWRfYmxhY2tfMjRweC0oMSkiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDE2LjAwMDAwMCwgOC4wMDAwMDApIj4KICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTE0LDEyIEwxMCwxMiBMMTAsNiBMNCw2IEw0LDEyIEwwLDEyIEw3LDE5IEwxNCwxMiBaIE0wLDIxIEwwLDIzIEwxNCwyMyBMMTQsMjEgTDAsMjEgWiIgaWQ9IlNoYXBlIj48L3BhdGg+CiAgICAgICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICAgICAgPC9nPgogICAgICAgICAgICA8L2c+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4=');
    */
    background-repeat: no-repeat;
    background-position: center;
}

 .btnhelp::before {
    content: "";
    display: block;
    width: 48px;
    height: 46px;
    margin-left: -7px;
    margin-top: -1px;
    -webkit-transition: all 200ms cubic-bezier(0.25, 0.75, 0.5, 1.25);
    transition: all 200ms cubic-bezier(0.25, 0.75, 0.5, 1.25);
}

.box-1:hover  .btnhelp::before {
    width: 120%;
    opacity: .8;
    background-color: #00BF9C;
}

.box-2:hover  .btnhelp::before {
    width: 120%;
    opacity: .8;
    background-color: #653EE6;
}

.box-3:hover  .btnhelp::before {
    width: 120%;
    opacity: .8;
    background-color: #008BFF;
}

.box-4:hover  .btnhelp::before {
    width: 120%;
    opacity: .8;
    background-color: #FF6500;
}

.box-5:hover  .btnhelp::before {
    width: 120%;
    opacity: .8;
    background-color: #541337;
}

.container {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
        -ms-flex-align: center;
            align-items: center;
    -ms-flex-pack: distribute;
        justify-content: space-around;
    -ms-flex-wrap: wrap;
        flex-wrap: wrap;
    width: 55vw;
    height: 100vh;
    margin-left: 6vw;
    /* transform:rotateX(7deg) rotateZ(-4deg) rotateY(13deg) scale3d(1, 1, -0.9); */
    -webkit-transform: rotateX(23deg) rotateZ(-9deg) rotateY(15deg) scale3d(1, 1, -0.9);
            transform: rotateX(23deg) rotateZ(-9deg) rotateY(15deg) scale3d(1, 1, -0.9);
}

.box {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
        -ms-flex-align: center;
            align-items: center;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
        -ms-flex-direction: column;
            flex-direction: column;
    -webkit-transition: all .3s ease-out;
    transition: all .3s ease-out;
    will-change: transform;
}

.box:hover .cover {
    -webkit-transform: translateY(-14px) scale(1.04);
            transform: translateY(-14px) scale(1.04);
}

.box-1  .btnhelp {
    border: 1px solid #00BF9C;
    color: #fff;
    font-size: 22px;
    text-align: right;
    padding-right: 20px;
    line-height: 40px;
    width: 130%;
}

.box-1  .btnhelp::after {
    content: "";
    background-color: #00BF9C;
    top: -85px
}

.box-2  .btnhelp {
    border: 1px solid #653EE6;
    color: #fff;
    font-size: 22px;
    text-align: right;
    padding-right: 20px;
    line-height: 40px;
    width: 130%;
}

.box-2  .btnhelp::after {
    content: "";
    background-color: #653EE6;
    top: -85px
}

.box-3  .btnhelp {
    border: 1px solid #008BFF;
    color: #fff;
    font-size: 22px;
    text-align: right;
    padding-right: 20px;
    line-height: 40px;
    width: 130%;
}

.box-3  .btnhelp::after {
    content: "";
    background-color: #008BFF;
    top: -85px
}

.box-4  .btnhelp {
    border: 1px solid #FF6500;
    color: #fff;
    font-size: 22px;
    text-align: right;
    padding-right: 20px;
    line-height: 40px;
    width: 130%;

}

.box-4  .btnhelp::after {
    content: "";
    background-color: #FF6500;
    top: -85px
}

.box-5  .btnhelp {
    border: 1px solid #541337;
    color: #fff;
    font-size: 22px;
    text-align: right;
    padding-right: 20px;
    line-height: 40px;
    width: 130%;

}

.box-5  .btnhelp::after {
    content: "";
    background-color: #541337;
    top: -85px
}

.cover {
    -webkit-transition: all 400ms ease-in-out;
    transition: all 400ms ease-in-out;
    will-change: transform;
}

.cover img {
    -webkit-transition: all 260ms ease-in-out;
    transition: all 260ms ease-in-out;
}

.box .cover::after {
    content: "";
    z-index: -99;
    position: absolute;
    top: 20px;
    left: -20px;
    display: block;
    width: 160px;
    height: 214px;
    opacity: 0;
    background-position: center;
    background-repeat: no-repeat;
    background-size: 160px 214px;
    -webkit-filter: blur(24px);
            filter: blur(24px);
    -webkit-transition: all 260ms ease-in-out;
    transition: all 260ms ease-in-out;
    will-change: transform;
    -webkit-transform: scale(.6);
            transform: scale(.6);
}

.box:hover .cover::after {
    opacity: 1;
    -webkit-transform: scale(1);
            transform: scale(1);
}

.box-1 .cover::after {
    background-image: url('img/change.png');
}

.box-2 .cover::after {
    background-image: url('img/tickets.png');
}

.box-3 .cover::after {
    background-image: url('img/request.png');
}

.box-4 .cover::after {
    background-image: url('img/suggest.png');
}
.box-5 .cover::after {
    background-image: url('img/delete.png');
}



.box-1  .btnhelp div::before {
    content: 'Change Password';
    position: relative;
    top: -44px;
    left: -4px;
    color: #00BF9C;
    font-size: 21px;
    font-weight: 300;
}

.box-1:hover  .btnhelp div::before {
    color: #fff;
}

.box-2  .btnhelp div::before {
    content: 'Tickets Area';
    position: relative;
    top: -44px;
    left: -6px;
    color: rgb(154, 123, 255);
    font-size: 21px;
    font-weight: 300;
}

.box-2:hover  .btnhelp div::before {
    color: #fff;
}

.box-3  .btnhelp div::before {
    content: 'Add New User';
    position: relative;
    top: -44px;
    left: 3px;
    color: #008BFF;
    font-size: 21px;
    font-weight: 300;
}

.box-3:hover  .btnhelp div::before {
    color: #fff;
}

.box-4  .btnhelp div::before {
    content: 'Suggestion';
    position: relative;
    top: -44px;
    left: -9px;
    color: #FF6500;
    font-size: 21px;
    font-weight: 300;
}

.box-4:hover  .btnhelp div::before {
    color: #fff;
}



.box-5  .btnhelp div::before {
    content: 'Delete User';
    position: relative;
    top: -44px;
    left: -9px;
    color: #d56fa7;
    font-size: 21px;
    font-weight: 300;
}

.box-5:hover  .btnhelp div::before {
    color: #fff;
}

.dr {
position: absolute;
  bottom: 16px; 
  right: 16px;
  width:100px;
}
 
details > summary {
  list-style: none;
}
@media screen and (max-width: 580px) {
  #navbar {
    padding: 20px 10px !important;
  }
  #navbar a {
    float: none;
    display: block;
    text-align: left;
  }
  #navbar-right {
    float: none;
  }


details > summary {
  list-style: none;
}


.h4{
  font-family: 'Carattere', cursive; 
  font-size: 90px;
}


.bkga{

width: 40%;

}
 @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){



  }
 
 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){



.h4{
  font-family: 'Carattere', cursive; 
  font-size: 40px;
}




 }



@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){


.container {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
        -ms-flex-align: center;
            align-items: center;
    -ms-flex-pack: distribute;
        justify-content: space-around;
    -ms-flex-wrap: wrap;
        flex-wrap: wrap;
    width: 55vw;
    height: 100vh;
    margin-left: 6vw;
    /* transform:rotateX(7deg) rotateZ(-4deg) rotateY(13deg) scale3d(1, 1, -0.9); */
    -webkit-transform: rotateX(23deg) rotateZ(-9deg) rotateY(15deg) scale3d(1, 1, -0.9);
            transform: rotateX(23deg) rotateZ(-3deg) rotateY(15deg) scale3d(1, 1, -0.9);
}



.h4{
  font-family: 'Carattere', cursive; 
  font-size: 40px;
}


.bkga{

width: 120%;

}

}




</style>


 <form method="post">
<div class="container" style="float: left" dir="ltr">
<img src="img/rrrrr.png" class="bkga"   >
<h4 class="h4"  >Help-_-List</h4>

 <div class="box box-1">
<?php
  require_once  'access.php';
      if (access('HR'  , false) || access('ACC'  , false)  || access('EO'  , false)): ?>
           <label  for="change" style="cursor: pointer;" ><div class="cover" ><img src="img/change.png" alt=""></div></label>
            <button class="btnhelp" name="change" id="change"><div></div></button>
        </div>
        <div class="box box-2" >
             <label  for="tickets" style="cursor: pointer;" ><div class="cover" for="tickets" ><img src="img/tickets.png" alt="" ></div></label>
            <button class="btnhelp" name="tickets" id="tickets" ><div></div></button>
        </div>
         <?php endif; ?>
         <?php
   
      if (access('AIT'  , false)): ?>
        <div class="box box-3">
             <label  for="request" style="cursor: pointer;" ><div class="cover"><img src="img/request.png" alt=""></div></label>
            <button class="btnhelp" name="request" id="request"><div></div></button>
        </div>
        <?php endif; ?>
<?php
   
      if (access('ADMIN'  , false)): ?>
         <div class="box box-5">
             <label  for="delete" style="cursor: pointer;" ><div class="cover"><img src="img/delete.png" alt=""></div></label>
            <button class="btnhelp" name="delete" id="delete"><div></div></button>
        </div>

        <?php endif; ?>
        <div class="box box-4">
             <label  for="suggest" style="cursor: pointer;" ><div class="cover"><img src="img/suggest.png" alt=""></div></label>
            <button class="btnhelp" name="suggest" id="suggest" disabled><del><div></div></del></button>
        </div>
<footer class="custom-footer">
      <?php
      $end_time = microtime(TRUE);
      $time_taken = $end_time - $start_time;
      $total_time = round($time_taken, 4);
      ?>
      <p>
        <span class="description">⏱️ Render:</span>
        <span class="result"><?php echo $total_time; ?> sec</span>
      </p>
      <p>&copy; 2023 M_G_X. All rights reserved.</p>
    </footer>
      
    
</div>
 </form>

<?php



/////////////////////////////Change PASS ///////////////////////////M_G_X

 if(isset($_POST['change'])){

if (@$_SESSION['type']=='admin'  || @$_SESSION['type']=='ad_it_user' || @$_SESSION['type']=='it_user' || @$_SESSION['type']=='eo_user' || @$_SESSION['type']=='hr_user'  || @$_SESSION['type']=='acc_user') {

  echo "<script> window.location.href=('./Change_User_Pass.php');</script>";
  
}else {
 
    echo "<script> history.back(); </script>";
}
}


/////////////////////////Tickets Area////////////////////////M_G_X



if(isset($_POST['tickets'])){

if (@$_SESSION['type']=='admin'  || @$_SESSION['type']=='ad_it_user' || @$_SESSION['type']=='it_user' || @$_SESSION['type']=='eo_user' || @$_SESSION['type']=='hr_user'  || @$_SESSION['type']=='acc_user') {

  echo "<script> window.location.href=('./Tickets.php');</script>";
  
}else {
 
    echo "<script> history.back(); </script>";
}
}
/////////////////////////ADD NEW USER////////////////////////M_G_X


if(isset($_POST['request'])){

if (@$_SESSION['type']=='admin' || @$_SESSION['type']=='ad_it_user' ) {

  echo "<script> window.location.href=('./Add_New_User.php');</script>";
  
}else{
 
  echo "<script> history.back(); </script>";
}

}


/////////////////////////Delete USER////////////////////////M_G_X


if(isset($_POST['delete'])){

if (@$_SESSION['type']=='admin' ) {

  echo "<script> window.location.href=('./Delete_Users.php');</script>";
  
}else{
 
  echo "<script> history.back(); </script>";
}

}

?>





<!-- M_G_X Container -->

<!-- <div class="cpr">

<details style="float: center;">
<summary style="scale:120px right;">
  <u style="color:gray;">
    جميع الحقوق محفوظة © 2022-2023
</u>
</summary>
  <p> * Powered BY <a target="_top" disabled="" style="color: gray; cursor: pointer;"><u>MG</u></a>*</p>

</details>
</div> -->