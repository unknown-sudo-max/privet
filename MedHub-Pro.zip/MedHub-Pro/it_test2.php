
  <!-- Header -->
<?php 
 $start_time = microtime(TRUE);

require_once('header.php');
// include 'access.php';
access('IT');


?>
<?php

 
 

  



 

?>
<!-- End page content -->
<link rel="stylesheet" href="cdn/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
 <script type="text/javascript" src="cdn/xlsx.full.min.js"></script>
 <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script src="cdn/dd9c95f04f.js" crossorigin="anonymous"></script>

<script type="text/javascript">

//   $(document).ready(function(){

// //Using setTimeout to execute a function after 5 seconds.
// setTimeout(function () {
//    //Redirect with JavaScript
//    window.history.pushState("/test2.php", "", '/test3/test2.php');
// }, 0);


// window.scrollTo(1000,0);

// });

 
  $(document).ready(function(){

var userContent = document.getElementById("user-content");
userContent.classList.add("hidden");

var ticketsContent = document.getElementById("tickets-content");
      ticketsContent.classList.add("hidden");


 var ttriangleIcon = document.querySelector("#tickets-heading .triangle");
 ttriangleIcon.classList.toggle("rotate");
var utriangleIcon = document.querySelector("#user-heading .triangle");
 utriangleIcon.classList.toggle("rotate");



 function html_table_to_excel(type)
    {
        var data = document.getElementById('myTable');

        var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

        XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

        XLSX.writeFile(file, 'All patient in DB file.' + type);
    }

    const export_button = document.getElementById('export_button');

    export_button.addEventListener('click', () =>  {
        html_table_to_excel('xlsx');
    });






});
 
  

</script>
<style>


.hidden {
      display: none;
    }

    td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

tr:hover {
  background-color: #85aae5;
}


* {box-sizing: border-box;}

body{ 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
 
    

}


.dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
            margin-left: 5px;
        }
        .dot-green {
            background-color: green;
        }
        .dot-red {
            background-color: red;
        }
        .dot-yellow {
            background-color: yellow;
        }
/*
body::before { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    content: "";
      background-image: url('pngegg.png');
      background-size: cover;
      position: absolute;
      top: 0px;
      right: 0px;
      bottom: 0px;
      left: 0px;
      opacity: 0.10;
      z-index: -1;
}
 */
#navbar {
  overflow: hidden;
  background-color: #9f8398;
  padding: 90px 10px;
  transition: 0.4s;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 99;

}

#navbar a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;

}
ul{

  list-style-image: url('fas fa-folder-open');
}
#navbar #logo {
  font-size: 35px;
  font-weight: bold;
  transition: 0.4s;

}

#navbar a:hover {
  background-color: #b99fb2;
  color: black;
}

#navbar a.active {
  background-color: #7d1d64;
  color: white;
}

#navbar-right {
  float: right;
  padding: 12px;
}

 
.container a {
  
  display: block;
  color: black;
  text-align: left;
  padding: 10px;
  
  font-size: 17px;
  list-style-image: url('sqpurple.gif');
}

.container a:hover {
  background-color: #ddd;
  color: black;
  border-radius: 5px;
  padding: 8;
  margin: 4;
  opacity: 0.5;

}

.container a.active {
  background-color: #2196F3;
  color: white;
  

}

.container{
float: left;
text-align: left;
position: absolute;
left: 1%;
width: 70%;

}

.list{
  width: 100%;
  align-items: left;

}

.ifrm{
  width: 100%;
  height: 100%;
  border: none;
}


.list li {
  list-style-type: 'fas fa-folder-open';
  list-style-type: '📂 ';
}

.logo{

  //display: block;
  position: relative;
  float: right;
  left:  -30px;
  width: 20%;
  height: 27%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}

.cpr{

/*  padding: 12px;
  margin: 12px;
  position: absolute;*/

  text-align: center;
 cursor: not-allowed;
/*  top: 84%;
  left: 30%;*/
  
}
 
details > summary {
  list-style: none;
}



.navbarh {
  overflow: hidden;
  background-color: #333;
}

.navbarh a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}


.navbarh span {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;

}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}



.export_button {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  cursor: pointer;
  
  background-color: inherit;
  font-family: inherit;
  margin: 0;
   
}

.export_button:hover {
  background-color: red;
}

.navbarh a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}




.view-users {
  background-color: gray;
  border-radius: 5px;
  padding: 5px;
  color: white;
}
.num-users {
  background-color: #333;
  border-radius: 5px;
  padding: 5px 10px;
  color: white;
}
.admin-users {
  background-color: #ffcc00;
  border-radius: 5px;
  padding: 5px 10px;
  color: black;
}


 .triangle {
    display: inline-block;
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 5px 5px 0 5px;
    border-color: #000000 transparent transparent transparent;
    margin-right: 10px;
    transition: transform 0.3s;
  }

  .rotate {
    transform: rotate(-90deg);
  }


  .custom-footer {
      color: #554949;
      font-size: 13px;
      margin-top: 2rem;
    }


@media screen and (max-width: 580px) {
  #navbar {
    padding: 20px 10px !important;
  }
  #navbar a {
    float: none;
    display: block;
    text-align: left;
  }
  #navbar-right {
    float: none;
  }


details > summary {
  list-style: none;
}





  @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){
.navbarh{
    width: 120%;
    position: relative;
    top: 20px;

  }
#navbarv{
    width: 70%;
    position: relative;
  }
  }



 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){
.navbarh{
    width: 120%;
    position: relative;
    top: 20px;

  }

  #navbarv{
    width: 70%;
    position: relative;
  }
   h4{
    top: 75px;
    position: relative;
  }


}


@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){

  .navbarh{
    width: 130%;
    position: relative;
    top: 75px;
    height: 150px;

  }

  h4{
    top: 75px;
    position: relative;
  }

  #navbarv{
    width: 80%;
    position: relative;
  }

    #divco{
    overflow: scroll;
    width: 140%;
    position: relative;
  }

}

</style>

 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">


<div class="container" style="float: left" dir="ltr">

<h4 style="font-family: 'Carattere', cursive; font-size: 30px;">IT-_-List</h4>
 

 

<!DOCTYPE html>
<html>
<head>
  <title>El-Agouza Hospital IT Department</title>
  <link rel="stylesheet" href="styles.css">
  <script  >
    function openPopup(url) {
  var features = 'width=800,height=600,toolbar=no,location=no,status=no';
  window.open(url, '_blank', features);

}


 function toggleDashboardContent() {
    var dashboardContent = document.getElementById("dashboard-content");
    var dtriangleIcon = document.querySelector("#dashboard-heading .triangle");
    
    dashboardContent.classList.toggle("hidden");
    dtriangleIcon.classList.toggle("rotate");
  }


    function toggleTicketsContent() {
      var ticketsContent = document.getElementById("tickets-content");
      var ttriangleIcon = document.querySelector("#tickets-heading .triangle");
      ticketsContent.classList.toggle("hidden");
       ttriangleIcon.classList.toggle("rotate");

    }

    function toggleUserContent() {
      var userContent = document.getElementById("user-content");
      var utriangleIcon = document.querySelector("#user-heading .triangle");
      userContent.classList.toggle("hidden");
       utriangleIcon.classList.toggle("rotate");
    }


  </script>
</head>
<body>
<header>
    <h1>Welcome to El-Agouza Hospital IT Department</h1>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <!-- Navigation menu items -->
      <ul class="navbar-nav" style="width: 70%;">
        <!-- <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li> -->
        <li class="nav-item"><a class="nav-link" href="tickets.php">🎫 Support Tickets</a></li>
        <li class="nav-item"><a class="nav-link" href="users.php">🪪User Accounts</a></li>
        <?php if (access('AIT', false)): ?>
          <li class="nav-item"><a class="nav-link" href="monitoring.php">📈 System Monitoring</a></li>
        <?php endif; ?>
        <?php if (access('ADMIN', false)): ?>
          <li class="nav-item"><a class="nav-link" href='javascript:void(0)' onclick="openPopup('servercheck.php')">💻 Server Checker</a></li>
        <?php endif; ?>
        <li class="nav-item"><a class="nav-link" href="configurations.php">⚙️ Configuration Management</a></li>
      </ul>
    </nav>
  </header>

  <main class="container">
    <section style="width: 80%;">
      <h2 id="dashboard-heading" onclick="toggleDashboardContent()" style="cursor: pointer;user-select: none;"><span class="triangle"></span>Dashboard</h2>
      <div id="dashboard-content">
        <div class="row">
          <div class="col-md-6">
            <div class="card">
              <div class="card-header">
                System Status
              </div>
              <div class="card-body">
                <p>Status: <span id="status"></span><span id="dot"></span></p>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="card">
              <div class="card-header">
                Server Health
              </div>
              <div class="card-body">
                <p id="serverHealthStatus">Server Health Status <i id="serverHealthIcon" class=""></i></p>
                <p>Server CPU Usage: <span id="cpuUsage"></span>%</p>
                <p>Server Memory Usage: <span id="memoryUsage"></span>%</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <hr>
    <section>
  <h2 id="tickets-heading" onclick="toggleTicketsContent()"  style="cursor: pointer;user-select: none;"><span class="triangle"></span>Support Tickets</h2>
  <co hidden>
    <?php
      require_once 'connect.php';
    ?>
    <?php
  
  // Execute SQL query to retrieve ticket counts
  $query = "SELECT status, COUNT(*) AS count FROM irtickets GROUP BY status";
  $result = mysqli_query($conn, $query);

  // Initialize variables for different status counts
  $openCount = 0;
  $closedCount = 0;
  $inProgressCount = 0;
  $pendingCount = 0;

  // Process the query result
  while ($row = mysqli_fetch_assoc($result)) {
    $status = $row['status'];
    $count = $row['count'];

    // Update the respective count variable based on status
    if ($status == 'open') {
      $openCount = $count;
    } elseif ($status == 'closed') {
      $closedCount = $count;
    } elseif ($status == 'in_progress') {
      $inProgressCount = $count;
    } elseif ($status == 'pending') {
      $pendingCount = $count;
    }
  }
  ?>

  </co>
  <div id="tickets-content">
  <div class="row">
    <div class="col-md-6 col-lg-3">
      <div class="card bg-danger text-white" style="width: 50%;">
        <div class="card-body">
          <h5 class="card-title">Open Tickets</h5>
          <p class="card-text"><span id="openTicketsCount"><?php echo $openCount; ?></span></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-3">
      <div class="card bg-success text-white" style="width: 50%;">
        <div class="card-body">
          <h5 class="card-title">Closed Tickets</h5>
          <p class="card-text"><span id="closedTicketsCount"><?php echo $closedCount; ?></span></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-5">
      <div class="card bg-warning" style="width: 50%;">
        <div class="card-body">
          <h5 class="card-title">In-progress Tickets</h5>
          <p class="card-text"><span id="inProgressTicketsCount"><?php echo $inProgressCount; ?></span></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-5">
      <div class="card bg-info text-white" style="width: 50%;">
        <div class="card-body">
          <h5 class="card-title">Pending Tickets</h5>
          <p class="card-text"><span id="pendingTicketsCount"><?php echo $pendingCount; ?></span></p>
        </div>
      </div>
    </div>
  </div>
  </div>

</section>

 <?php if (access('AIT', false)): ?>
 <hr>
  <section style="width: 70%;">
  <h2 id="user-heading" onclick="toggleUserContent()"  style="cursor: pointer;user-select: none;"><span class="triangle"></span>User Accounts</h2>
  <div id="user-content">
  <div class="row">
    <div class="col-md-6">
      <div class="card bg-gray" style="width: 50%;">
        <div class="card-body">
          <h4 class="card-title ">HR Department</h4>
          <p class="card-text num-users">Num of users: <span id="hrCount"><?php echo getUserCount($conn, 'hr_user'); ?></span></p>
          <p class="card-text view-users">View users: <span id="hrCount"><?php echo getUserCount($conn, 'hr_viewer'); ?></span></p>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card bg-gray" style="width: 50%;">
        <div class="card-body">
          <h4 class="card-title">Accounting Department</h4>
          <p class="card-text num-users">Num of users: <span id="accountingCount"><?php echo getUserCount($conn, 'acc_user'); ?></span></p>
          <p class="card-text view-users">View users: <span id="accountingCount"><?php echo getUserCount($conn, 'acc_viewer'); ?></span></p>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <div class="card bg-gray" style="width: 50%;">
        <div class="card-body">
          <h4 class="card-title">Entry Office Department</h4>
          <p class="card-text num-users">Num of users: <span id="entryOfficeCount"><?php echo getUserCount($conn, 'eo_user'); ?></span></p>
          <p class="card-text view-users">View users: <span id="entryOfficeCount"><?php echo getUserCount($conn, 'eo_viewer'); ?></span></p>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card bg-gray" style="width: 50%;">
        <div class="card-body">
          <h4 class="card-title">IT Department</h4>
          <p class="card-text admin-users">Admin users: <span id="itCount"><?php echo getUserCount($conn, 'ad_it_user'); ?></span></p>
          <p class="card-text num-users">Num of users: <span id="itCount"><?php echo getUserCount($conn, 'it_user'); ?></span></p>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <div class="card bg-gray" style="width: 50%;">
        <div class="card-body">
          <h4 class="card-title">Admin Department</h4>
          <p class="card-text admin-users">Admin users: <span id="adminCount"><?php echo getUserCount($conn, 'admin'); ?></span></p>
        </div>
      </div>
    </div>
  </div>
  </div>
</section>
 
<?php endif; ?>

<?php
function getUserCount($conn, $type)
{
  // Assuming you have a "users" table in your database with a column named "type" to store the user type.
  $query = "SELECT COUNT(*) as count FROM users WHERE type = ?";
  $stmt = $conn->prepare($query);
  $stmt->bind_param("s", $type);
  $stmt->execute();
  $result = $stmt->get_result();
  $row = $result->fetch_assoc();
  return $row['count'];
}
?>


    <!-- Add more sections as needed -->


    <?php
    $end_time = microtime(TRUE);
    $time_taken = $end_time - $start_time;
    $total_time = round($time_taken, 4);
  ?>
  <hr>
  <footer  class="custom-footer">
    <p style="color: #554949; font-size: 13px;">
      <span class="description">⏱️ Render:</span>
      <span class="result"><?php echo $total_time; ?> sec</span>
    </p>
    <p>&copy; 2023 M_G_X. All rights reserved.</p>
  </footer>




  </main>


  <!-- Include Bootstrap JS -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

  
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // JavaScript/jQuery code to update the dashboard data

        // Function to fetch and update system status
        function updateSystemStatus() {
            // Make an AJAX request to the server
            $.ajax({
                url: 'system_status.php',
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    // Update the status element with the received data
                    $('#status').text(data.status);
                    $('#dot').removeClass().addClass('dot dot-' + data.dotColor);
                },
                error: function() {
                    // Handle errors if any
                    $('#status').text('Error retrieving status');
                }
            });
        }

        // Function to fetch and update server health
        function updateServerHealth() {
            // Make an AJAX request to the server
            $.ajax({
                url: 'server_health.php',
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    // Update the CPU and memory usage elements with the received data
                    $('#cpuUsage').text(data.cpuUsage);
                    $('#memoryUsage').text(data.memoryUsage);

                    // Update the server health status based on CPU and memory usage
                    var cpuUsage = parseInt(data.cpuUsage);
                    var memoryUsage = parseInt(data.memoryUsage);
                    var serverHealthIcon = $('#serverHealthIcon');

                    if (cpuUsage > 85 && memoryUsage > 85) {
                        $('#serverHealthStatus').removeClass().addClass('text-danger');
                        serverHealthIcon.removeClass().addClass('fas fa-exclamation-triangle');
                    } else if (cpuUsage < 60 && memoryUsage < 60) {
                        $('#serverHealthStatus').removeClass().addClass('text-success');
                        serverHealthIcon.removeClass().addClass('fas fa-check-circle');
                    } else {
                        $('#serverHealthStatus').removeClass().addClass('text-warning');
                        serverHealthIcon.removeClass().addClass('fas fa-exclamation-circle');
                    }
                },
                error: function() {
                    // Handle errors if any
                    $('#cpuUsage').text('Error retrieving CPU usage');
                    $('#memoryUsage').text('Error retrieving memory usage');
                    $('#serverHealthStatus').removeClass().addClass('text-secondary');
                    $('#serverHealthIcon').removeClass();
                }
            });
        }

        // Update the dashboard data on page load
        $(document).ready(function() {
            updateSystemStatus();
            updateServerHealth();
        });

        // Update the dashboard data every 10 seconds
        setInterval(function() {
            updateSystemStatus();
            updateServerHealth();
        }, 10000);
    </script>


</body>
</html>





<!-- M_G_X Container -->

<!-- <div class="cpr">

<details style="float: center;">
<summary style="scale:120px right;">
  <u style="color:gray;">
    جميع الحقوق محفوظة © 2022-2023
</u>
</summary>
  <p> * Powered BY <a target="_top" disabled="" style="color: gray; cursor: pointer;"><u>MG</u></a>*</p>

</details>
</div> -->


<?php







if (@$_SESSION['type']=='admin' ) {

        echo "<script>document.getElementById('navbarh').style.backgroundColor = '#081a36';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#081a36';</script>";
        echo "<script>
                       document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                       document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                       function mouseEnter() {
                         document.getElementById('tr').style.backgroundColor = '#9ab3cd';
                       }

                       function mouseLeave() {
                         document.getElementById('tr').style.backgroundColor = '';
                       }
            </script>";






  }elseif (@$_SESSION['type']=='it_user' || @$_SESSION['type']=='ad_it_user') {

      
  echo "<script>document.getElementById('navbarh').style.backgroundColor = '#15483f';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#15483f';</script>";
        echo "<script>
                      document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                      document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                      function mouseEnter() {
                        document.getElementById('tr').style.backgroundColor = '#7e9996';
                      }

                      function mouseLeave() {
                        document.getElementById('tr').style.backgroundColor = '';
                      }
              </script>";


     
  }else{
            echo "<script>function(){ history.back(); }</script>";
  }


?>
