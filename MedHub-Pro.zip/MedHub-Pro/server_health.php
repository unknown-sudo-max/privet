<?php

// Function to get CPU usage
function getCPUUsage() {
    if (stristr(PHP_OS, 'win')) {
        // Windows server
        $output = [];
        exec('wmic cpu get loadpercentage', $output);

        if (isset($output[1])) {
            $cpuUsage = intval($output[1]);
        } else {
            $cpuUsage = 'N/A';
        }
    } else {
        // Unix/Linux server
        $output = [];
        exec("top -bn1 | grep 'Cpu(s)' | awk '{print $2 + $4}'", $output);

        if (isset($output[0])) {
            $cpuUsage = floatval($output[0]);
        } else {
            $cpuUsage = 'N/A';
        }
    }

    return $cpuUsage;
}

// Function to get memory usage
function getMemoryUsage() {
    if (stristr(PHP_OS, 'win')) {
        // Windows server
        $output = [];
        exec('wmic OS get FreePhysicalMemory,TotalVisibleMemorySize /Value', $output);

        $totalMemory = 0;
        $freeMemory = 0;

        foreach ($output as $line) {
            if (strpos($line, 'TotalVisibleMemorySize') !== false) {
                $totalMemory = intval(str_replace('TotalVisibleMemorySize=', '', $line));
            } elseif (strpos($line, 'FreePhysicalMemory') !== false) {
                $freeMemory = intval(str_replace('FreePhysicalMemory=', '', $line));
            }
        }

        if ($totalMemory > 0) {
            $memoryUsage = (($totalMemory - $freeMemory) / $totalMemory) * 100;
        } else {
            $memoryUsage = 'N/A';
        }
    } else {
        // Unix/Linux server
        $output = [];
        exec("free -m | awk 'NR==2{printf \"%d\", (($2-$7)/$2)*100}'", $output);

        if (isset($output[0])) {
            $memoryUsage = floatval($output[0]);
        } else {
            $memoryUsage = 'N/A';
        }
    }

    return $memoryUsage;
}

// Create an associative array with the server health data
$data = [
    'cpuUsage' => getCPUUsage(),
    'memoryUsage' => getMemoryUsage()
];

// Set the response content type as JSON
header('Content-Type: application/json');

// Output the data as JSON
echo json_encode($data);
