<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>






<?php

require_once 'connect.php';






if(isset($_POST['delete'])){




  // $_SESSION['user1'] = $_POST['user1'];

  //$user = $_SESSION['user'];

//////////////////////////////first phase//////////////////////////////





  $user1 = $_POST['user1'];

$error = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid User</n><br><k>This User Are Not Exsit in Our DataBase  , So  refer to your Adminstrator</k><div>";
$success = "";

$query2 = "SELECT * FROM users WHERE user='$user1'";
$result = mysqli_query($conn, $query2 );
$count = mysqli_num_rows($result);
if ($count>0) {






////////////////////////////////////////////////////second phase/////////////////////






if (!empty($_POST['user1'])) {

    # code...
@$user1       = $_POST['user1'];





$sql= "DELETE from users  WHERE user='$user1' ";

//$sql= "UPDATE records set  fullname='$_POST[fullname]', pcuser='$_POST[pcuser]', pcpass='$_POST[pcpass]', login='$_POST[login]', shifttime='$_POST[shifttime]', sitestatus='$_POST[sitestatus]', arrivalstatus='$_POST[fullname]', recordstatus='$_POST[recordstatus]', comment='$_POST[comment]', shiftondate='$_POST[arrivalstatus]', addedon='$_POST[addedon]' WHERE id='$_POST[id]' ";




if (mysqli_query($conn, $sql)) {

    # code...

    echo "<p style='color:green; font-size:15px;'>The User Deleted Successfully</p>";
}
    else{

        echo "<p style='color:red; font-size:15px;'>Failed TO Deleted The User !!!</p>";
    }

mysqli_close($conn);

}
else{
    echo "<p style='color:red; font-size:15px;'>The  ..<u style='font-weight:  bold;'>' User '</u>   
      .. Fields Are Required !!! </p>";
}



















////////////////////////////////////////////////////second phase/////////////////////


}
else{
             $error2 = "<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid User </n> ' $user1 '<br><k>This User Are Not Exsit in Our DataBase  , So  refer to your Adminstrator</k><div>";
            
            echo "<br><br> <br> $error2";
        }






}




//////////////////////////////first phase//////////////////////////////






?>


<script type="text/javascript">






    
    var tbl = document.getElementById('myTable');

    for (var x = 1 ;  x < tbl.rows.length ; x++ ){

      tbl.rows[x].onclick = function () {
        // body...

        
        document.getElementById('user1').value = this.cells[2].innerHTML;
        document.getElementById('type').value = this.cells[4].innerHTML;
        
      }
    }

  </script>
