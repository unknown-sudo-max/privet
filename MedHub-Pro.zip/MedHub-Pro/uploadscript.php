<?php

 include 'connect.php';


if (isset($_POST['submitup'])) {
	# code...

//$newFlieName = $_POST['filename'];

if (empty($_POST['filename'])) {
   	// code...
$newFlieName = "sheet";


   } else{
        $newFlieName =strtolower(str_replace(" ", "_", $newFlieName));


   }  

$fileTitle = strip_tags($_POST['filetitle']);

$fileDesc = strip_tags($_POST['filedesc']);

$addedon = $_POST['addedon'];

$file = $_FILES['file'];
//print_r($file);


 $fileName = $file["name"];
 $fileTmpName = $file["tmp_name"];
 $fileSize = $file["size"];
 $fileError = $file["error"];
 $fileType = $file["type"];



$fileExt = explode('.', $fileName);
$fileActualExt = strtolower(end($fileExt));



 //////////////////////////////second phase//////////////////.....
$fileNameExt = explode('.', $fileName);
 $fileActualName = strtolower(current($fileNameExt));
 //////////////////////////////second phase//////////////////.....




$allowed = array('xls','xlsx','mht');

if (in_array($fileActualExt, $allowed)) {
	// code...
	if ($fileError === 0 ) {

////
      
   if ($fileSize < 1000000) {
 			// code...
 			
 $fileNameNew = uniqid(str_replace(" ", "_", $fileActualName)."____" , false).".".$fileActualExt;

             $fileDestination = 'uploads/'.$fileNameNew;
             
            


       if (empty($fileTitle) || empty($fileTitle)) {
       	// code...
       	echo "<script> window.location.href=('hr_list1.php?upload=empty');</script>";
       	exit();
       }else{

       	    


           $sql = "SELECT * FROM hruploadedfiles;";
           $stmt = mysqli_stmt_init($conn);
           if (!mysqli_stmt_prepare($stmt,$sql)) {
           	// code...
           	echo "SQL Failed";

           }else{
           	mysqli_stmt_execute($stmt);
           	$result = mysqli_stmt_get_result($stmt);
           	$rowCount = mysqli_num_rows($result);
           	$setfileOrder = $rowCount + 1;
           	$ip = $_SERVER['REMOTE_ADDR'];

            
            $sql = "INSERT INTO hruploadedfiles (titleF, descF, fileFullNameF, orderFiles , ip , date) VALUES(?,?,?,?,?,?) ;";
            if (!mysqli_stmt_prepare($stmt, $sql)) {
           	// code...
           	echo "SQL Failed";

           }else{

            
           	mysqli_stmt_bind_param($stmt, "ssssss", $fileTitle, $fileDesc, $fileNameNew , $setfileOrder ,$ip ,$addedon);

            mysqli_stmt_execute($stmt);



            move_uploaded_file($fileTmpName, $fileDestination);

              //include_once 'connect.php'; 


            //echo "<br><br><n style='color:green';>Your File Uploaded Successfully</n>";
            echo "<script> window.location.href=('hr_list1.php?upload=Success');</script>";
        exit();


           }

           }

       }






 			}else{
 			echo "<br><br><n style='color:red; position: relative; top:-145px;' >This File Is Too Big ! ".$fileSize/1000000 . " _MB , </n>";
 			//echo "<br><br>";
      echo "<n1 style=' position: relative; top:-145px;' >Try Something Smaller Than ( 3_MB )</n1>";

      //echo "<script> window.location.href=('upload.php?file=size');</script>";
        exit();
 		}
  
	}else{
 		echo "<br><br><n style='color:red; position: relative; top:-145px;'>There An Error While uploading The File !</n>";
 	}

}else{
	echo "<br><br><n style='color:red;  position: relative; top:-145px;'>You Can't Upload Files Of This Type" . "__" . "(<mark>." . $fileActualExt ."</mark>)</n>";
	exit();
}


}




