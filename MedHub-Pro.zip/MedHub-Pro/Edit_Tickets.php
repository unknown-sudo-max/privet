<co hidden>
	
	<?php require_once('connect.php');
 session_start();
		



	?>



</co>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>



<script type="text/javascript">
  $(document).ready(function() {



    var nonne = $('#nonne').html();

if (nonne == 'There is None to View') {
  document.getElementById("addtktlog").remove();
  document.getElementById("logs").remove();

   

}



// var status      = $('#status').val();

// if (status == 'closed') {
//   document.getElementById("addtktlog").remove();
//   // document.getElementById("checkbox_div").style.display = 'none';
//   // document.getElementById("hrr").style.display = 'none';
//   document.getElementById('title').disabled = true;
//   document.getElementById('subject').disabled = true;
//   document.getElementById('problemtype').disabled = true;
//   document.getElementById('status').disabled = true;
//   document.getElementById('comment').disabled = true;
//   document.getElementById('closing_reason').disabled = true;
 

//   // document.getElementById('exit_date').setAttribute('readonly','readonly');
// }


var status = $('#status').val();

if (status == 'closed') {
  $('input, textarea, select').each(function() {
    var value = $(this).val();
    var span = $('<span>').text(value);
    $(this).replaceWith(span);
  });

  $('h2').text('Closed Ticket');
  $('legend').text('Closed Ticket Details');
   document.getElementById("addtktlog").remove();
   document.getElementById("closing_reason_box").style.display = 'none';
}



$("#status").on('change', function() {
  if ($("#status").val() == 'closed') {
    $(".closing_reason_box").show();
    $("#" + $(this).val()).fadeIn(700);
  } else {
    $(".closing_reason_box").hide();
    $("#" + $(this).val()).fadeIn(700);
  }
}).change();


 

// const subjectObject = {
//   "password_issue": {
//     "reset the pass": [],
//     "work suspension": [],
//     "server error": [],
//     "maintenance time": [],
//     "No problem Found": []
//   },
//   "uploading_issue": {
//     "internet issue": [],
//     "exceeded quota": [],
//     "cach reset": [],
//     "pc performance": [],
//     "server error": [],
//     "maintenance time": [],
//     "No problem Found": []
//   },
//   "adding_issue": {
//     "cach reset": [],
//     "pc performance": [],
//     "server error": [],
//     "maintenance time": [],
//     "No problem Found": []
//   },
//   "other": {
//     "cach reset": [],
//     "pc performance": [],
//     "server error": [],
//     "maintenance time": [],
//     "No problem Found": []
//   }
// };

// window.onload = function() {
//   const problemtype = document.getElementById("problemtype");
//   const closing_reason = document.getElementById("closing_reason");
  
//   problemtype.addEventListener("change", function() {
//     const selectedSubject = subjectObject[this.value];
//     closing_reason.innerHTML = ""; // Clear previous options
    
//     const defaultOption = document.createElement("option");
//     defaultOption.setAttribute("value", "");
//     defaultOption.setAttribute("selected", "selected");
//     defaultOption.innerText = "--please select--";
//     closing_reason.appendChild(defaultOption);
    
//     for (const reason in selectedSubject) {
//       const option = document.createElement("option");
//       option.setAttribute("value", reason);
//       option.innerText = reason;
//       closing_reason.appendChild(option);
//     }
//   });
// };


    });

</script>

<style type="text/css">
	
	.title-container {
  position: relative;
  display: inline-block;
  display: flex;
      justify-content: center;
      align-items: center;
}

.title {
  font-size: 90px;
  color: #FF4081; /* Rose */
  position: relative;
  display: inline-block;
  text-transform: uppercase;
  transition: transform 0.3s ease-in-out;
}

.title:hover {
  transform: scale(1.1);
  animation: title 6s infinite;
}

@keyframes title {
  0% { transform: scale(1); }
  50% { transform: scale(1.2); }
  100% { transform: scale(1); }
}

.form-fieldset {
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 20px;
  margin-bottom: 20px;
}

.form-fieldset legend {
  font-weight: bold;
  font-size: 18px;
  margin-bottom: 10px;
}


    .form-content h2 {
      font-size: 24px;
      margin-bottom: 20px;
    }

    .form-content form {
      display: flex;
      flex-direction: column;
    }

    .form-content label {
      font-size: 18px;
      margin-bottom: 10px;
    }

    .form-content input[type="text"],
    .form-content select,
    .form-content textarea {
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ddd;
      border-radius: 5px;
      margin-bottom: 15px;
    }

    .form-content textarea {
      height: 100px;
    }

    .form-content button {
      padding: 10px 20px;
      font-size: 16px;
      background-color: #324140;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .form-content button:hover {
      background-color: #709d9a;
    }


    /* CSS for table */
   .tickets-table {
  width: 100%;
  border-collapse: collapse;
  font-family: Arial, sans-serif;
  color: #555;
  background-color: #f5f5f5;
}

.tickets-table th,
.tickets-table td {
  padding: 16px;
  text-align: left;
}

.tickets-table th {
  background-color: #333;
  color: #fff;
  text-transform: uppercase;
}

.tickets-table td {
  background-color: #fff;
  border-bottom: 1px solid #ddd;
  transition: background-color 0.3s ease;
}

.tickets-table tbody tr:hover {
  background-color: #f9f9f9;
}

.tickets-table tbody tr:hover td {
  background-color: #d9d9d9;
}

.tickets-table tbody tr:hover .status.open {
  color: #e74c3c;
  background-color: #ffcccc;
}

.tickets-table tbody tr:hover .status.pending {
  color: #f39c12;
  background-color: #ffe5cc;
}

.tickets-table tbody tr:hover .status.in-progress {
  color: #3498db;
  background-color: #cce5ff;
}

.tickets-table tbody tr:hover .status.closed {
  color: #2ecc71;
  background-color: #e6ffe6;
}

.tickets-table tbody tr:last-child td {
  border-bottom: none;
}

.tickets-table .ticket-id {
  font-weight: bold;
}


.tickets-table .status {
  font-weight: bold;
  transition: color 0.3s ease;
}

.tickets-table .status.open {
  color: #e74c3c;
}

.tickets-table .status.pending {
  color: #f39c12;
}

.tickets-table .status.in-progress {
  color: #3498db;
}

.tickets-table .status.closed {
  color: #2ecc71;
}

.tickets-table .ticket-id:before {
  content: "#";
  font-weight: normal;
  color: #aaa;
}

.tickets-table .ticket-id span {
  display: inline-block;
  vertical-align: middle;
  font-size: 18px;
  margin-left: 5px;
}

.tickets-table .title {
  font-size: 16px;
  color: #444;
}

.tickets-table .subject {
  font-size: 14px;
  color: #666;
}

.tickets-table .problem-type:before {
  content: "Problem Type: ";
  font-weight: normal;
  color: #aaa;
}

.tickets-table .status:before {
  content: "Status: ";
  font-weight: normal;
  color: #aaa;
}

.tickets-table .problem-type {
  font-weight: bold;
  color: #ff8c00;
}

.tickets-table .problem-type.password_issue {
  color: #e55598;
}

.tickets-table .problem-type.uploading_issue {
  color: #3bcfc2;
}

.tickets-table .problem-type.adding_issue {
  color: #897c23;
}

.tickets-table .problem-type.other {
  color: #9b59b6;
}

 .Logs {
        display: inline-block;
        padding: 5px 10px;
        background-color: #f2f2f2;
        color: #333;
        font-weight: bold;
        border-radius: 4px;
        display: flex;
        justify-content: center;
        align-items: center;   
         }


</style>

<div class="title-container">
  <h1 class="title"><i class="fas fa-ticket-alt"></i></h1>
</div>


 

<div id="popupFormEdit" class="popup-form">
  <div class="form-content">
    
    <h2>Edit Ticket</h2>
    <form method="POST" autocomplete="on">
       <fieldset class="form-fieldset">
        <legend>Edit Ticket Details</legend>
         <div class="ticket-id">
            <label for="ticketId">Ticket ID:</label>
            <input type="number" id="unique_id" name="unique_id" style="border: none; outline: none; width: 8%; font-size: 12px;"  onKeyPress="if(this.value.length==4) return false;" readonly=""  value="<?php $unique_id =$_GET['unique_id']; echo $unique_id; ?>" >





          </div>
          <hr>
        <div>





           <?php



$unique_id =$_GET['unique_id'];

$query = "SELECT * FROM irtickets WHERE unique_id='$unique_id' ";
$query_run = mysqli_query($conn, $query);
if (mysqli_num_rows($query_run) > 0) {
    # code...
   foreach ($query_run as $row) {
    // code...
    echo "



          <label for='title'>Title:</label>
          <input type='text' id='title' name='title' value='$row[title]' required>
        </div>
        <div>
          <label for='subject'>Subject:</label>
          <input type='text' id='subject' name='subject'value='$row[subject]' required>
        </div>
        <div>
          <label for='problemtype'>Problem Type:</label>
          <select id='problemtype' name='problemtype'   onchange='updateClosingReasonOptions()'>
            <option selected hidden value='$row[problemtype]'>$row[problemtype]</option>
            <option value='password_issue'>Password Issue</option>
            <option value='uploading_issue'>Uploading Issue</option>
            <option value='adding_issue'>Adding Issue</option>
            <option value='other'>Other</option>
            
          </select>
        </div>
         <div>
          <label for='comment'>Comment:</label>
          <textarea id='comment' name='comment' value='$row[comment]'>$row[comment]</textarea>
        </div>
        <div>
          <label for='status'>Status:</label>
          <select id='status' name='status'   onchange='updateClosingReasonOptions()'>
          <option value='$row[status]' selected hidden>$row[status]</option>
             <option value='open' hidden>Open</option>
            <option value='pending'>Pending</option>
            <option value='in_progress'>In Progress</option>
            <option value='closed'>Closed</option>
          </select>
        </div>
       
       
        




 
     
";
}
 }else{
   echo "<p style='font-size: 30px; text-align:center;=' id='nonne'>There is None to View</p>";
  }
?>

 <div class='form-field'>


  <div class="closing_reason_box" id="closing_reason_box">
          <label for='closing_reason'>Closing Reason:</label>
          <select id='closing_reason' name='closing_reason'>
          <option selected hidden value=''>--please select--</option>
             
          </select>
        </div>
         
        <div class='form-field' hidden="">
          <label for='handler'>The Handler:</label>
          <input type='text' id='handler' name='handler' value='<?php echo ($_SESSION['type'] === "admin") ? $_SESSION['user'] : ""; ?>'>
        </div>

<div class='form-field' hidden="">
          <label for='date'>Date:</label>
          <input type='text' id='date' name='date'  value=' <?php date_default_timezone_set('Africa/Cairo'); $time = date('d/m/Y, h:i:s A'); echo ($time);?>'>
        </div>
        <div>
          <button type='submit'  name="addtktlog" id="addtktlog">Save</button>
        </div>
      </fieldset>
    </form>
  </div>
</div>
  </div>
</div>


<hr>
<span class="Logs" id="logs">Logs</span>

<br>



<?php



   
$sql = "SELECT * from irtickets_logs WHERE unique_id='$unique_id'";

$result = $conn->query($sql);

if ($result->num_rows > 0){

  echo "<table class='tickets-table'>
  <thead>
    <tr>
      <th>Ticket ID</th>
      <th>Title</th>
      <th>Subject</th>
      <th>Problem Type</th>
      <th>Status</th>
      <th>comment</th>
      <th>closing reason</th>
      <th>handler</th>
      <th>date</th>
    </tr>
  </thead>
  <tbody>";

  while($row = $result->fetch_assoc() ){


echo " <tr>
      <td class='ticket-id'>
        <span>$row[unique_id]</span>
        <div class='action-buttons'>
          
      </td>
      <td>$row[title]</td>
      <td>$row[subject]</td>
      <td class='problem-type $row[problemtype]'>$row[problemtype]</td>
      <td class='status $row[status]'>$row[status]</td>
      <td>$row[comment]</td>
      <td>$row[closing_reason]</td>
      <td>$row[handler]</td>
      <td>$row[date]</td>
    </tr>";
   
}

echo "</tbody></table>";

 }
else {
   echo "<p style='font-size: 30px; text-align:center;font-family: \"Reem Kufi\", sans-serif;'></p>";
}


  ?>

<!-- <p style='color:green; font-size:15px;'  id="msg"></p> -->


<?php

if (@$_SESSION['type']=='admin' || @$_SESSION['type']=='eo_user' || @$_SESSION['type']=='hr_user'  || @$_SESSION['type']=='acc_user' ) {

 include 'edit_ir_ticket.php';
 include 'edit_ir_ticket_logs.php';

  }else{
            echo "<script>function(){ history.back(); }</script>";
  }




if (@$_SESSION['type'] == 'eo_user' || @$_SESSION['type'] == 'hr_user' || @$_SESSION['type'] == 'acc_user') {
    // Remove the closed option
    echo '<script>
        // Hide the closed and in_progress options
        document.addEventListener("DOMContentLoaded", function() {
            var statusSelect = document.getElementById("status");
            if (statusSelect) {
                var closedOption1 = statusSelect.querySelector("option[value=closed]");
                var closedOption2 = statusSelect.querySelector("option[value=in_progress]");
                var closedOption3 = statusSelect.querySelector("option[value=open]");
                if (closedOption1) {
                    closedOption1.style.display = "none";
                }
                if (closedOption2) {
                    closedOption2.style.display = "none";
                }
                if (closedOption3) {
                    closedOption3.style.display = "none";
                }
            }
        });
    </script>';

} else if (@$_SESSION['type']=='admin') {
    echo '<script>
        // Hide the pending and open options
        document.addEventListener("DOMContentLoaded", function() {
            var statusSelect = document.getElementById("status");
            if (statusSelect) {
                var closedOption1 = statusSelect.querySelector("option[value=pending]");
                var closedOption2 = statusSelect.querySelector("option[value=open]");
                
                if (closedOption1) {
                    closedOption1.style.display = "none";
                }
                if (closedOption2) {
                    closedOption2.style.display = "none";
                }
            }
        });
    </script>';

}




?>

<script type="text/javascript">
  

 function updateClosingReasonOptions() {
    var problemTypeSelect = document.getElementById('problemtype');
    var closingReasonSelect = document.getElementById('closing_reason');
    
    // Clear existing options
    closingReasonSelect.innerHTML = '<option selected hidden value="">--please select--</option>';
    
    // Get the selected problem type
    var selectedProblemType = problemTypeSelect.value;
    
    // Populate the closing reason options based on the selected problem type
   

    if (selectedProblemType === 'password_issue') {
      closingReasonSelect.innerHTML += '<option value="reset the pass">reset the pass</option>';
      closingReasonSelect.innerHTML += '<option value="work suspension">work suspension</option>';
      closingReasonSelect.innerHTML += '<option value="server error">server error</option>';
      closingReasonSelect.innerHTML += '<option value="maintenance time">maintenance time</option>';
      closingReasonSelect.innerHTML += '<option value="No problem Found">No problem Found</option>';

    } else if (selectedProblemType === 'uploading_issue') {
      closingReasonSelect.innerHTML += '<option value="internet issue">internet issue</option>';
      closingReasonSelect.innerHTML += '<option value="exceeded quota">exceeded quota</option>';
      closingReasonSelect.innerHTML += '<option value="cach reset">cach reset</option>';
      closingReasonSelect.innerHTML += '<option value="pc performance">pc performance</option>';
      closingReasonSelect.innerHTML += '<option value="server error">server error</option>';
      closingReasonSelect.innerHTML += '<option value="maintenance time">maintenance time</option>';
      closingReasonSelect.innerHTML += '<option value="No problem Found">No problem Found</option>';

    } else if (selectedProblemType === 'adding_issue') {
       closingReasonSelect.innerHTML += '<option value="cach reset">cach reset</option>';
      closingReasonSelect.innerHTML += '<option value="pc performance">pc performance</option>';
      closingReasonSelect.innerHTML += '<option value="server error">server error</option>';
      closingReasonSelect.innerHTML += '<option value="maintenance time">maintenance time</option>';
      closingReasonSelect.innerHTML += '<option value="No problem Found">No problem Found</option>';
    } else if (selectedProblemType === 'other') {
       closingReasonSelect.innerHTML += '<option value="cach reset">cach reset</option>';
      closingReasonSelect.innerHTML += '<option value="pc performance">pc performance</option>';
      closingReasonSelect.innerHTML += '<option value="server error">server error</option>';
      closingReasonSelect.innerHTML += '<option value="maintenance time">maintenance time</option>';
      closingReasonSelect.innerHTML += '<option value="No problem Found">No problem Found</option>';

    }
  }


</script>