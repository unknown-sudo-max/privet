-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2023 at 05:13 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aghis`
--
CREATE DATABASE IF NOT EXISTS `aghis` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `aghis`;

-- --------------------------------------------------------

--
-- Table structure for table `eo_uploaded_files`
--
-- Creation: Jan 25, 2023 at 02:31 AM
--

DROP TABLE IF EXISTS `eo_uploaded_files`;
CREATE TABLE `eo_uploaded_files` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `medical_number` varchar(255) NOT NULL,
  `pa_national_id` varchar(255) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `file_Full_Name` varchar(255) NOT NULL,
  `added_by` varchar(255) NOT NULL,
  `added_on` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `eo_uploaded_files`
--

INSERT INTO `eo_uploaded_files` (`id`, `unique_id`, `medical_number`, `pa_national_id`, `patient_name`, `file_Full_Name`, `added_by`, `added_on`) VALUES
(1, '010523-124501-7718', '22356987', '27901220456991', 'شهاب محمد فتحي ابراهيم', '22356987_new_text_document____63b6ab99718f7.png', 'Admin_Name', ' 05/01/2023, 12:50:19 PM'),
(2, '010523-124501-7718', '22356987', '27901220456991', 'شهاب محمد فتحي ابراهيم', '22356987_1658321687976____63cbf513e0fe9.png', 'Admin_Name', ' 21/01/2023, 04:21:27 PM'),
(3, '010523-124501-7718', '22356987', '27901220456991', 'شهاب محمد فتحي ابراهيم', '22356987_war-machine-neon-5k-5760x2917-86____63cbf54404d60.jpg', 'Admin_Name', ' 21/01/2023, 04:22:33 PM');

-- --------------------------------------------------------

--
-- Table structure for table `irtickets`
--
-- Creation: Jun 07, 2023 at 03:37 AM
--

DROP TABLE IF EXISTS `irtickets`;
CREATE TABLE `irtickets` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `problemtype` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `closing_reason` varchar(255) NOT NULL,
  `addedby` varchar(255) NOT NULL,
  `segmentation` varchar(255) NOT NULL,
  `handler` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `irtickets`
--

INSERT INTO `irtickets` (`id`, `unique_id`, `title`, `subject`, `problemtype`, `status`, `comment`, `closing_reason`, `addedby`, `segmentation`, `handler`, `date`) VALUES
(6, '5376', 'eo test1', 'eo issue', 'password_issue', 'closed', 'Changed and Mail sent', 'rest pass', 'EO Name', 'eo_user', 'Michael Gad', ' 05/06/2023, 02:22:05 AM'),
(7, '0066', 'hr test1', 'hr issue', 'adding_issue', 'closed', 'Waiting for your superior FB .', 'pc performance', 'HR Name', 'hr_user', 'Admin_Name', ' 07/06/2023, 05:50:43 AM'),
(8, '0345', 'acc test 1', 'acc issue', 'other', 'closed', 'No Issue Found', 'No Issue Found', 'ACC Name', 'acc_user', 'Michael Gad', ' 05/06/2023, 02:19:11 AM'),
(9, '4418', 'admin test 1', 'admin issue', 'uploading_issue', 'pending', 'pending through internet issue ', '', 'Admin_Name', 'admin', 'Michael Gad', ' 05/06/2023, 02:16:47 AM'),
(10, '3053', 'test 2', 'hr issue 2', 'uploading_issue', 'open', '', '', 'HR Name', 'hr_user', '', ' 07/06/2023, 05:58:30 AM');

-- --------------------------------------------------------

--
-- Table structure for table `irtickets_logs`
--
-- Creation: Jun 07, 2023 at 03:38 AM
--

DROP TABLE IF EXISTS `irtickets_logs`;
CREATE TABLE `irtickets_logs` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `problemtype` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `closing_reason` varchar(255) NOT NULL,
  `addedby` varchar(255) NOT NULL,
  `segmentation` varchar(255) NOT NULL,
  `handler` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `irtickets_logs`
--

INSERT INTO `irtickets_logs` (`id`, `unique_id`, `title`, `subject`, `problemtype`, `status`, `comment`, `closing_reason`, `addedby`, `segmentation`, `handler`, `date`) VALUES
(126, '5376', 'eo test1', 'eo issue', 'password_issue', 'open', '', '', 'EO Name', 'eo_user', '', ' 05/06/2023, 02:11:53 AM'),
(127, '0066', 'hr test1', 'hr issue', 'adding_issue', 'open', '', '', 'HR Name', 'hr_user', '', ' 05/06/2023, 02:13:00 AM'),
(128, '0345', 'acc test 1', 'acc issue', 'other', 'open', '', '', 'ACC Name', 'acc_user', '', ' 05/06/2023, 02:14:03 AM'),
(129, '4418', 'admin test 1', 'admin issue', 'uploading_issue', 'open', '', '', 'Admin_Name', 'admin', '', ' 05/06/2023, 02:14:44 AM'),
(130, '4418', 'admin test 1', 'admin issue', 'uploading_issue', 'pending', 'pending through internet issue ', '', '', '', 'Michael Gad', ' 05/06/2023, 02:16:47 AM'),
(131, '0345', 'acc test 1', 'acc issue', 'other', 'closed', 'No Issue Found', 'No Issue Found', '', '', 'Michael Gad', ' 05/06/2023, 02:19:11 AM'),
(132, '0066', 'hr test1', 'hr issue', 'adding_issue', 'in_progress', 'Waiting for your superior FB .', '', '', '', 'Michael Gad', ' 05/06/2023, 02:20:33 AM'),
(133, '5376', 'eo test1', 'eo issue', 'password_issue', 'closed', 'Changed and Mail sent', 'reset pass', '', '', 'Michael Gad', ' 05/06/2023, 02:22:05 AM'),
(134, '0066', 'hr test1', 'hr issue', 'adding_issue', 'pending', 'Waiting for your superior FB .', '', '', '', 'Admin_Name', ' 07/06/2023, 05:42:06 AM'),
(135, '0066', 'hr test1', 'hr issue', 'adding_issue', 'closed', 'Waiting for your superior FB .', 'pc performance', '', '', 'Admin_Name', ' 07/06/2023, 05:50:43 AM'),
(136, '3053', 'test 2', 'hr issue 2', 'uploading_issue', '', '', '', 'HR Name', 'hr_user', '', ' 07/06/2023, 05:58:30 AM');

-- --------------------------------------------------------

--
-- Table structure for table `patient_eo_logs`
--
-- Creation: Jan 25, 2023 at 02:31 AM
--

DROP TABLE IF EXISTS `patient_eo_logs`;
CREATE TABLE `patient_eo_logs` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `medical_number` varchar(255) NOT NULL,
  `pa_national_id` varchar(255) NOT NULL,
  `pa_phone_num` varchar(255) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `date_of_birth` varchar(255) NOT NULL,
  `doctor` varchar(255) NOT NULL,
  `date_of_entry` varchar(255) NOT NULL,
  `specialization` varchar(255) NOT NULL,
  `entry_type` varchar(255) NOT NULL,
  `exit_type` varchar(255) NOT NULL,
  `exit_date` varchar(255) NOT NULL,
  `acceptance_permission` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `financial_transaction` varchar(255) NOT NULL,
  `room` varchar(255) NOT NULL,
  `sponsor_name` varchar(255) NOT NULL,
  `spo_phone_num` varchar(255) NOT NULL,
  `spo_degree_of_kinship` varchar(255) NOT NULL,
  `grade` varchar(255) NOT NULL,
  `health_insurance_beneficiary` varchar(255) NOT NULL,
  `sample_result` varchar(255) NOT NULL,
  `scan_facility_code` varchar(255) NOT NULL,
  `referred_center` varchar(255) NOT NULL,
  `record_status` varchar(255) NOT NULL,
  `added_by` varchar(255) NOT NULL,
  `last_edit_by` varchar(255) NOT NULL,
  `added_on` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_eo_logs`
--

INSERT INTO `patient_eo_logs` (`id`, `unique_id`, `medical_number`, `pa_national_id`, `pa_phone_num`, `patient_name`, `gender`, `date_of_birth`, `doctor`, `date_of_entry`, `specialization`, `entry_type`, `exit_type`, `exit_date`, `acceptance_permission`, `section`, `financial_transaction`, `room`, `sponsor_name`, `spo_phone_num`, `spo_degree_of_kinship`, `grade`, `health_insurance_beneficiary`, `sample_result`, `scan_facility_code`, `referred_center`, `record_status`, `added_by`, `last_edit_by`, `added_on`) VALUES
(1, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-01-05', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', 'Admin_Name', '', ' 05/01/2023, 12:45:01 PM'),
(2, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-01-05', '1', 'طوارئ', 'شفاء', '2023-01-05', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Shehab Mohamed', ' 05/01/2023, 12:51:24 PM'),
(3, '010523-124501-7718', '22356987', '27901220456991', '', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-01-05', '1', 'طوارئ', 'شفاء', '2023-02-20', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 20/02/2023, 05:58:34 PM'),
(4, '010523-124501-7718', '22356987', '27901220456991', '', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-01-05', '1', 'طوارئ', 'شفاء', '2023-02-20', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 20/02/2023, 05:58:39 PM'),
(5, '010523-124501-7718', '22356987', '27901220456991', '', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-01-05', '1', 'طوارئ', 'تحويل', '2023-02-20', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 20/02/2023, 10:38:19 PM'),
(6, '010523-124501-7718', '22356987', '27901220456991', '', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-01-05', '1', 'طوارئ', 'شفاء', '2023-02-20', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 20/02/2023, 10:38:30 PM'),
(7, '010523-124501-7718', '22356987', '27901220456991', '', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-01-05', '1', 'طوارئ', 'شفاء', '2023-02-21', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 21/02/2023, 11:51:28 AM'),
(8, '010523-124501-7718', '22356987', '27901220456991', '', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-01-05', '1', 'طوارئ', 'شفاء', '2023-02-21', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 21/02/2023, 11:51:48 AM'),
(9, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-01-05', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 09/03/2023, 03:22:57 AM'),
(10, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-01-05', '1', 'طوارئ', 'تحويل', '2023-03-09', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 09/03/2023, 03:23:50 AM'),
(11, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-09', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 09/03/2023, 03:24:06 AM'),
(12, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-09', '1', 'طوارئ', 'شفاء', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'EO Name', ' 13/03/2023, 03:26:31 AM'),
(13, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'EO Name', ' 13/03/2023, 03:26:54 AM'),
(14, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:00:11 PM'),
(15, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:01:01 PM'),
(16, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:06:24 PM'),
(17, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:07:28 PM'),
(18, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:07:35 PM'),
(19, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:07:48 PM'),
(20, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:09:22 PM'),
(21, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:09:30 PM'),
(22, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', 'تحويل', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:09:38 PM'),
(23, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:11:37 PM'),
(24, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:13:39 PM'),
(25, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', 'تحويل', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:32:52 PM'),
(26, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:33:09 PM'),
(27, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:34:19 PM'),
(28, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:36:12 PM'),
(29, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '', '1', 'طوارئ', 'شفاء', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:36:29 PM'),
(30, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '', '1', 'طوارئ', '', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:36:45 PM'),
(31, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '', '1', 'طوارئ', '', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:37:00 PM'),
(32, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:37:10 PM'),
(33, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:37:23 PM'),
(34, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:37:30 PM'),
(35, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:39:14 PM'),
(36, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '', '1', 'طوارئ', 'شفاء', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:39:23 PM'),
(37, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '', '1', 'طوارئ', 'شفاء', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:39:38 PM'),
(38, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:39:45 PM'),
(39, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:39:54 PM'),
(40, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:40:02 PM'),
(41, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:40:54 PM'),
(42, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '', '1', 'طوارئ', 'تحويل', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:42:05 PM'),
(43, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '', '1', 'طوارئ', 'تحويل', '2023-03-13', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 13/03/2023, 11:42:25 PM'),
(44, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:42:35 PM'),
(45, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-03-13', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 13/03/2023, 11:42:44 PM'),
(46, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-03', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'أبن او أبنة', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 03/04/2023, 11:41:04 PM'),
(47, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-03', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متوليm', '01388888888', 'أخت', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 03/04/2023, 11:41:34 PM'),
(48, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-03', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', 'أبن او أبنة', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 03/04/2023, 11:47:52 PM'),
(49, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-03', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', 'زوج او زوجة', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 03/04/2023, 11:50:05 PM'),
(50, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-03', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', '', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 03/04/2023, 11:52:57 PM'),
(51, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-03', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', 'أبن او أبنة', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 03/04/2023, 11:55:32 PM'),
(52, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-03', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', '', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 03/04/2023, 11:58:23 PM'),
(53, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '', '1', 'طوارئ', 'شفاء', '2023-04-04', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', '', 'جناح', 'منتفع بالتامين', '', '', '', 'خروج', '', 'Admin_Name', ' 04/04/2023, 12:00:10 AM'),
(54, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-04', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', '', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 04/04/2023, 12:00:45 AM'),
(55, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-04', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', 'أبن او أبنة', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 04/04/2023, 12:01:11 AM'),
(56, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-04', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', '', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 04/04/2023, 12:01:45 AM'),
(57, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-04', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', 'أبن او أبنة', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 04/04/2023, 12:01:50 AM'),
(58, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-04', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', 'زوج او زوجة', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 04/04/2023, 12:02:44 AM'),
(59, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-04', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', 'أبن او أبنة', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 04/04/2023, 12:02:59 AM'),
(60, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-04', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', 'أبن او أبنة', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 04/04/2023, 12:05:40 AM'),
(61, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-04', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', 'حماة', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', '', 'Admin_Name', ' 04/04/2023, 12:05:51 AM');

-- --------------------------------------------------------

--
-- Table structure for table `patient_login_eo`
--
-- Creation: Jan 25, 2023 at 02:31 AM
--

DROP TABLE IF EXISTS `patient_login_eo`;
CREATE TABLE `patient_login_eo` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `medical_number` varchar(255) NOT NULL,
  `pa_national_id` varchar(255) NOT NULL,
  `pa_phone_num` varchar(255) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `date_of_birth` varchar(255) NOT NULL,
  `doctor` varchar(255) NOT NULL,
  `date_of_entry` varchar(255) NOT NULL,
  `specialization` varchar(255) NOT NULL,
  `entry_type` varchar(255) NOT NULL,
  `exit_type` varchar(255) NOT NULL,
  `exit_date` varchar(255) NOT NULL,
  `acceptance_permission` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `financial_transaction` varchar(255) NOT NULL,
  `room` varchar(255) NOT NULL,
  `sponsor_name` varchar(255) NOT NULL,
  `spo_phone_num` varchar(255) NOT NULL,
  `spo_degree_of_kinship` varchar(255) NOT NULL,
  `grade` varchar(255) NOT NULL,
  `health_insurance_beneficiary` varchar(255) NOT NULL,
  `sample_result` varchar(255) NOT NULL,
  `scan_facility_code` varchar(255) NOT NULL,
  `referred_center` varchar(255) NOT NULL,
  `record_status` varchar(255) NOT NULL,
  `added_by` varchar(255) NOT NULL,
  `last_edit_by` varchar(255) NOT NULL,
  `added_on` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_login_eo`
--

INSERT INTO `patient_login_eo` (`id`, `unique_id`, `medical_number`, `pa_national_id`, `pa_phone_num`, `patient_name`, `gender`, `date_of_birth`, `doctor`, `date_of_entry`, `specialization`, `entry_type`, `exit_type`, `exit_date`, `acceptance_permission`, `section`, `financial_transaction`, `room`, `sponsor_name`, `spo_phone_num`, `spo_degree_of_kinship`, `grade`, `health_insurance_beneficiary`, `sample_result`, `scan_facility_code`, `referred_center`, `record_status`, `added_by`, `last_edit_by`, `added_on`) VALUES
(1, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-04-04', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي احمد', '01000000000', 'حماة', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', 'Admin_Name', 'Admin_Name', ' 04/04/2023, 12:05:51 AM');

-- --------------------------------------------------------

--
-- Table structure for table `patient_login_eo_entry_count`
--
-- Creation: Jan 25, 2023 at 02:31 AM
--

DROP TABLE IF EXISTS `patient_login_eo_entry_count`;
CREATE TABLE `patient_login_eo_entry_count` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `medical_number` varchar(255) NOT NULL,
  `pa_national_id` varchar(255) NOT NULL,
  `pa_phone_num` varchar(255) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `date_of_birth` varchar(255) NOT NULL,
  `doctor` varchar(255) NOT NULL,
  `date_of_entry` varchar(255) NOT NULL,
  `specialization` varchar(255) NOT NULL,
  `entry_type` varchar(255) NOT NULL,
  `exit_type` varchar(255) NOT NULL,
  `exit_date` varchar(255) NOT NULL,
  `acceptance_permission` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `financial_transaction` varchar(255) NOT NULL,
  `room` varchar(255) NOT NULL,
  `sponsor_name` varchar(255) NOT NULL,
  `spo_phone_num` varchar(255) NOT NULL,
  `spo_degree_of_kinship` varchar(255) NOT NULL,
  `grade` varchar(255) NOT NULL,
  `health_insurance_beneficiary` varchar(255) NOT NULL,
  `sample_result` varchar(255) NOT NULL,
  `scan_facility_code` varchar(255) NOT NULL,
  `referred_center` varchar(255) NOT NULL,
  `record_status` varchar(255) NOT NULL,
  `added_by` varchar(255) NOT NULL,
  `last_edit_by` varchar(255) NOT NULL,
  `added_on` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_login_eo_entry_count`
--

INSERT INTO `patient_login_eo_entry_count` (`id`, `unique_id`, `medical_number`, `pa_national_id`, `pa_phone_num`, `patient_name`, `gender`, `date_of_birth`, `doctor`, `date_of_entry`, `specialization`, `entry_type`, `exit_type`, `exit_date`, `acceptance_permission`, `section`, `financial_transaction`, `room`, `sponsor_name`, `spo_phone_num`, `spo_degree_of_kinship`, `grade`, `health_insurance_beneficiary`, `sample_result`, `scan_facility_code`, `referred_center`, `record_status`, `added_by`, `last_edit_by`, `added_on`) VALUES
(0, '010523-124501-7718', '22356987', '27901220456991', '01255216546', 'شهاب محمد فتحي ابراهيم', 'ذكر', '1979-01-22', 'mohab mohamed', '2023-01-05', '1', 'طوارئ', '', '', '', 'عناية مركزة', 'خاص', '', 'رباب السيد متولي', '01356641545', 'مرات خالة جوز عمه', 'جناح', 'منتفع بالتامين', '', '', '', 'دخول', 'Admin_Name', '', ' 05/01/2023, 12:45:01 PM');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Creation: Jan 25, 2023 at 02:31 AM
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `user`, `pass`, `type`, `date`) VALUES
(1, 'Admin_Name', 'Admin', 'user', 'admin', ''),
(2, 'Eo_Viewer', 'eoviewer', 'user', 'eo_viewer', ''),
(3, 'ACC_Viewer', 'accviewer', 'user', 'acc_viewer', ''),
(4, 'HR_Viewer', 'hrviewer', 'user', 'hr_viewer', ''),
(5, 'Michael Gad', 'Michel', '787878', 'admin', ' 05/01/2023, 12:42:48 PM'),
(6, 'Shehab Mohamed', 'shehab', 'user', 'admin', ' 05/01/2023, 12:40:17 PM'),
(7, 'HR Name', 'hruser', 'user', 'hr_user', ' 05/01/2023, 12:40:43 PM'),
(8, 'EO Name', 'eouser', 'user', 'eo_user', ' 05/01/2023, 12:41:13 PM'),
(9, 'ACC Name', 'accuser', 'user', 'acc_user', ' 05/01/2023, 12:41:30 PM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `eo_uploaded_files`
--
ALTER TABLE `eo_uploaded_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `irtickets`
--
ALTER TABLE `irtickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_id` (`unique_id`);

--
-- Indexes for table `irtickets_logs`
--
ALTER TABLE `irtickets_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_eo_logs`
--
ALTER TABLE `patient_eo_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_login_eo`
--
ALTER TABLE `patient_login_eo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_id` (`unique_id`,`medical_number`);

--
-- Indexes for table `patient_login_eo_entry_count`
--
ALTER TABLE `patient_login_eo_entry_count`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user` (`user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `eo_uploaded_files`
--
ALTER TABLE `eo_uploaded_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `irtickets`
--
ALTER TABLE `irtickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `irtickets_logs`
--
ALTER TABLE `irtickets_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `patient_eo_logs`
--
ALTER TABLE `patient_eo_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `patient_login_eo`
--
ALTER TABLE `patient_login_eo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
