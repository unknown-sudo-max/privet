<html  >
<head>
<?php

 
// require_once('connect.php');
$start_time = microtime(TRUE);

require_once('header.php');

// include 'access.php';

 


?>
<title>Edit</title>

</head>
<link rel="stylesheet" href="ircss.css">

<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>



<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>


<script type="text/javascript">

 


$(document).ready(function() {
   

});
 
</script>

<style type="text/css">


 .close-button {
    background-color: transparent;
    border: none;
    color: #ff0000; /* Change the color to your desired color */
    font-size: 18px;
    cursor: pointer;
    padding: 5px;
    margin-left: 10px;
    transition: color 0.3s ease;
  }

  .close-button:hover {
    color: #990000; /* Change the hover color if desired */
  }
  .toggle-button {
    background-color: transparent;
    border: none;
    color: #333;
    font-size: 20px;
    cursor: pointer;
    padding: 5px;
    margin-right: 10px;
  }

  .toggle-button:hover {
    color: #555;
  }

.sidepanel {
    display: none; /* Hide the sidepanel by default */
  }

  .sidepanel.open {
    display: block; /* Show the sidepanel when the "open" class is applied */
  }


.title-container {
  position: relative;
  display: inline-block;
}

.title {
  font-size: 48px;
  color: #FF4081; /* Rose */
  position: relative;
  display: inline-block;
  text-transform: uppercase;
  transition: transform 0.3s ease-in-out;
}

.title:hover {
  transform: scale(1.1);
  animation: title 6s infinite;
}

@keyframes title {
  0% { transform: scale(1); }
  50% { transform: scale(1.2); }
  100% { transform: scale(1); }
}



/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}


 /* CSS for side panel */
    .sidepanel {
      height: 100%;
      width: 200px;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #333333; /* Dark Gray */
      overflow-x: hidden;
      padding-top: 20px;
      transition: 0.5s;
    }

    .sidepanel-content {
      padding: 20px;
    }

   

    .sidenav a {
      display: block;
      padding: 15px;
      text-decoration: none;
      color: #fff; /* White */
      font-size: 18px;
      transition: 0.3s;
    }

    .sidenav a:hover {
      background-color: #555555;
    }

    /* CSS for search bar */
    .search-container {
      margin-top: 20px;
      padding: 10px;
      background-color: #555555;
      display: flex;
      flex-direction: column;
      align-items: center;
      border-radius: 5px;
    }

    .search-container input[type=text] {
      padding: 10px;
      font-size: 16px;
      border: none;
      width: 100%;
      background-color: #ddd;
      border-radius: 5px;
    }

    .search-container button {
      padding: 10px;
      font-size: 16px;
      border: none;
      cursor: pointer;
      background-color: #5f4545;  
      color: white;
      border-radius: 5px;
      margin-top: 10px;
    }


    .search-container button:hover {
      padding: 10px;
      font-size: 16px;
      border: none;
      cursor: pointer;
      background-color: #877474;  
      color: black;
      border-radius: 5px;
      margin-top: 10px;
     
    }


    /* CSS for table */
   .tickets-table {
  width: 100%;
  border-collapse: collapse;
  font-family: Arial, sans-serif;
  color: #555;
  background-color: #f5f5f5;
}

.tickets-table th,
.tickets-table td {
  padding: 16px;
  text-align: left;
}

.tickets-table th {
  background-color: #333;
  color: #fff;
  text-transform: uppercase;
}

.tickets-table td {
  background-color: #fff;
  border-bottom: 1px solid #ddd;
  transition: background-color 0.3s ease;
}

.tickets-table tbody tr:hover {
  background-color: #f9f9f9;
}

.tickets-table tbody tr:hover td {
  background-color: #d9d9d9;
}

.tickets-table tbody tr:hover .status.open {
  color: #e74c3c;
  background-color: #ffcccc;
}

.tickets-table tbody tr:hover .status.pending {
  color: #f39c12;
  background-color: #ffe5cc;
}

.tickets-table tbody tr:hover .status.in-progress {
  color: #3498db;
  background-color: #cce5ff;
}

.tickets-table tbody tr:hover .status.closed {
  color: #2ecc71;
  background-color: #e6ffe6;
}

.tickets-table tbody tr:last-child td {
  border-bottom: none;
}

.tickets-table .ticket-id {
  font-weight: bold;
}


.tickets-table .status {
  font-weight: bold;
  transition: color 0.3s ease;
}

.tickets-table .status.open {
  color: #e74c3c;
}

.tickets-table .status.pending {
  color: #f39c12;
}

.tickets-table .status.in-progress {
  color: #3498db;
}

.tickets-table .status.closed {
  color: #2ecc71;
}

.tickets-table .ticket-id:before {
  content: "#";
  font-weight: normal;
  color: #aaa;
}

.tickets-table .ticket-id span {
  display: inline-block;
  vertical-align: middle;
  font-size: 18px;
  margin-left: 5px;
}

.tickets-table .title {
  font-size: 16px;
  color: #444;
}

.tickets-table .subject {
  font-size: 14px;
  color: #666;
}

.tickets-table .problem-type:before {
  content: "Problem Type: ";
  font-weight: normal;
  color: #aaa;
}

.tickets-table .status:before {
  content: "Status: ";
  font-weight: normal;
  color: #aaa;
}

.tickets-table .problem-type {
  font-weight: bold;
  color: #ff8c00;
}

.tickets-table .problem-type.password_issue {
  color: #e55598;
}

.tickets-table .problem-type.uploading_issue {
  color: #3bcfc2;
}

.tickets-table .problem-type.adding_issue {
  color: #897c23;
}

.tickets-table .problem-type.other {
  color: #9b59b6;
}



/*icons css*/
.edit-button i,
.view-button i {
  transition: transform 0.3s ease-in-out, color 0.3s ease-in-out;
  color: black;
  background-color: white; 
  cursor: pointer;
    font-size: 20px;


}

.edit-button:hover i,
.view-button:hover i {
  transform: scale(1.2);
  color: white;
  background-color: black;
}




.create-button {
 color: white!important;
    background-color: #555555;
    border: none;
    outline: none;
    cursor: pointer;
    width: 100%;
    padding: 10px;
    margin: 2px;
    font-size: 14px;
    text-align: left;
}

.create-button:hover {
  background-color: #444444;
}




    /* CSS for popup form */
    .popup-form {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0, 0, 0, 0.5);
    }

    .form-content {
      background-color: #fefefe;
      margin: 10% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 50%;
    }

    .close-popup {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }

    .close-popup:hover,
    .close-popup:focus {
      color: black;
      text-decoration: none;
      cursor: pointer;
    }


    .form-content h2 {
      font-size: 24px;
      margin-bottom: 20px;
    }

    .form-content form {
      display: flex;
      flex-direction: column;
    }

    .form-content label {
      font-size: 18px;
      margin-bottom: 10px;
    }

    .form-content input[type="text"],
    .form-content select,
    .form-content textarea {
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ddd;
      border-radius: 5px;
      margin-bottom: 15px;
    }

    .form-content textarea {
      height: 100px;
    }

    .form-content button {
      padding: 10px 20px;
      font-size: 16px;
      background-color: #324140;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .form-content button:hover {
      background-color: #709d9a;
    }


  .ticket-id {
  background-color: #dddcdc;
  padding: 5px;
  width: 100%;
  border-radius: 5px;
  display: inline-block;
}

.ticket-id label {
  font-size: 16px;
  margin-right: 5px;
}

.ticket-id span {
  font-size: 14px;
  font-weight: bold;
}

.form-fieldset {
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 20px;
  margin-bottom: 20px;
}

.form-fieldset legend {
  font-weight: bold;
  font-size: 18px;
  margin-bottom: 10px;
}



  /*table {
   font-family: Georgia, serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}*/
 
.body{
    position: absolute;
    right: 33%;
    width: 50%;
}


 .w3-sidebar{

     position: relative;
     right: 0;
     top: 0;
  }

   .sessiondiv{

    position: relative;
    top:  -13px;

   }

     header{

  position: absolute;
  left: 0;
  padding: 10px;

  }


    .logomain {
    width: 60%;
    position: absolute;
    right: -64px;
    top: -140px;
    z-index: -1;
    cursor: pointer;
}
  
  
  details > summary {
  list-style: none;
}


  @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){



  }
 
 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){

.body{
  position: relative; 
  left: -50%; 

  top: 80px;

  width:200%;
}


 /* CSS for side panel */
    .sidepanel {
      height: 90%;
      width: 200px;
      position: fixed;
      z-index: 1;
      top: 12%;
      left: 0;
      background-color: #333333; /* Dark Gray */
      overflow-x: hidden;
      padding-top: 20px;
      transition: 0.5s;
    }

 body{
    width: 40%;
    position: absolute;
    left: 30%;
   }




   .toggle-button {
    background-color: transparent;
    border: none;
    color: #333;
    font-size: 20px;
    cursor: pointer;
    padding: 5px;
    margin-right: 10px;
    position: absolute;
    top: 10%;
        left: -32px;

  }


 }
@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){

.body{
  position: relative; 
  left: -50%; 

  top: 60px;

  width:200%;
}

body{
    width: 40%;
    position: absolute;
    left: 30%;
   }
   /* CSS for side panel */
    .sidepanel {
      height: 100%;
      width: 300px;
      position: fixed;
      z-index: 1;
      
      left: 0;
      background-color: #333333; /* Dark Gray */
      overflow-x: hidden;
      padding-top: 20px;
      transition: 0.5s;



}

.toggle-button {
    background-color: transparent;
    border: none;
    color: #333;
    font-size: 20px;
    cursor: pointer;
    padding: 5px;
    margin-right: 10px;
    position: absolute;
    top: 10%;
        left: -32px;

  }

  .toggle-button:hover {
    color: #555;
  }


  .title {
    font-size: 18px;
    color: #FF4081;
     width: 100%;
    position: relative;
    display: inline-block;
    text-transform: uppercase;
    transition: transform 0.3s ease-in-out;
}
.title-container {
margin: 12px;
position: relative;
left: -60%;

}
.div-tickets{
      overflow: scroll;
      width: 100%;
}



}


</style>



<body dir="ltr">

<div class="body">
<?php
@ob_start(); 
/*

fullname
pcuser
pcpass
login
shifttime
sitestatus
arrivalstatus

*/








@session_start();



    

ob_end_flush();
?>
    <span style="visibility: hidden; display: none;">     

<?php

require_once('connect.php');


?>

</span> 

<div class="sidepanel">
    <div class="sidepanel-content">
      <button class="close-button" onclick="toggleNavbar()">x</button>
      <div class="search-container">
        <input type="text" placeholder="Search.." name="search">
        <br>
        <button type="submit">Search</button>
      </div>
      
    </div>
    <button class="create-button" onclick="openPopupForm()">Create New</button>

         <?php
   
      if (access('AIT'  , false)): ?>
        <form method="get">
     <button class="create-button" type="submit" name="byme" id="byme">Created By ME</button>
     </form>
      <?php endif; ?>
  </div>
<button class="toggle-button" onclick="toggleNavbar()">
  &#9776;
</button>



  <div class="main" style="margin-left: 200px;">
<div class="title-container">
  <h1 class="title"><i class="fas fa-ticket-alt"></i> Tickets Area</h1>
  <hr>
  <br>
</div>

</div>


<?php


if (@$_SESSION['type']=='admin' || @$_SESSION['type']=='ad_it_user' ) {

include 'admin_tickets.php';




  }elseif (@$_SESSION['type']=='it_user' || @$_SESSION['type']=='eo_user' || @$_SESSION['type']=='hr_user'  || @$_SESSION['type']=='acc_user') {

    include 'users_tickets.php';
     
  }else{
            // echo "<script>function(){ history.back(); }</script>";
  }



if(isset($_GET['byme'])){

if (@$_SESSION['type']=='admin' || @$_SESSION['type']=='ad_it_user' ) {

 include 'users_tickets.php';

  }
}




?>

<footer class="custom-footer">
      <?php
      $end_time = microtime(TRUE);
      $time_taken = $end_time - $start_time;
      $total_time = round($time_taken, 4);
      ?>
      <p>
        <span class="description">⏱️ Render:</span>
        <span class="result"><?php echo $total_time; ?> sec</span>
      </p>
      <p>&copy; 2023 M_G_X. All rights reserved.</p>
    </footer>

<!-- 	////////////////////////////////removed section///////////////////M_G_X-->
  <!--  <table class="tickets-table">
  <thead>
    <tr>
      <th>Ticket ID</th>
      <th>Title</th>
      <th>Subject</th>
      <th>Problem Type</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="ticket-id">
        <span>123</span>
        <div class="action-buttons">
          <button class="edit-button" title="Edit Ticket">
            <i class="fas fa-pen-square" onclick="openPopupFormEdit()"></i>
          </button>
          <button class="view-button" title="View Ticket">
            <i class="fas fa-search" onclick="openViewPopup()"></i>
          </button>
        </div>
      </td>
      <td>Example Ticket 1</td>
      <td>Example Subject 1</td>
      <td class="problem-type other">Other</td>
      <td class="status pending">Pending</td>
    </tr>
    <tr>
      <td class="ticket-id">
        <span>456</span>
        <div class="action-buttons">
          <button class="edit-button" title="Edit Ticket">
            <i class="fas fa-pen-square"  onclick="openPopupFormEdit()"></i>
          </button>
          <button class="view-button" title="View Ticket">
            <i class="fas fa-search"  onclick="openViewPopup()"></i>
          </button>
        </div>
      </td>
      <td>Example Ticket 2</td>
      <td>Example Subject 2</td>
      <td class="problem-type password_issue">Password Issue</td>
      <td class="status in-progress">In Progress</td>
    </tr>
    <tr>
      <td class="ticket-id">
        <span>789</span>
        <div class="action-buttons">
          <button class="edit-button" title="Edit Ticket">
            <i class="fas fa-pen-square" onclick="openPopupFormEdit()"></i>
          </button>
          <button class="view-button" title="View Ticket">
            <i class="fas fa-search" onclick="openViewPopup()"></i>
          </button>
        </div>
      </td>
      <td>Example Ticket 3</td>
      <td>Example Subject 3</td>
      <td class="problem-type uploading_issue">Uploading Issue</td>
      <td class="status completed">Completed</td>
    </tr>
    <tr>
      <td class="ticket-id">
        <span>321</span>
        <div class="action-buttons">
          <button class="edit-button" title="Edit Ticket">
            <i class="fas fa-pen-square" onclick="openPopupFormEdit()"></i>
          </button>
          <button class="view-button" title="View Ticket">
            <i class="fas fa-search" onclick="openViewPopup()"></i>
          </button>
        </div>
      </td>
      <td>Example Ticket 4</td>
      <td>Example Subject 4</td>
      <td class="problem-type adding_issue">Adding Issue</td>
      <td class="status open">Open</td>
    </tr>
    </tbody>
</table> -->
<!-- 	////////////////////////////////removed section///////////////////M_G_X-->



  </div>
<!-- /////////////////addpopup//////////////////-->

<div id="popupForm" class="popup-form">
  <div class="form-content">
    <span class="close-popup" onclick="closePopupForm()">&times;</span>
    <h2>Create New Ticket</h2>
    <form method="POST" autocomplete="on">
      <fieldset class="form-fieldset">
        <legend>Ticket Details</legend>
        <div class="form-field">
          <div class="ticket-id">
            <label for="ticketId">Ticket ID:</label>
           <input type="number" id="unique_id" name="unique_id" style="border: none; outline: none; width: 5%; font-size: 10px; background-color: #dddcdc;"  onKeyPress="if(this.value.length==4) return false;" readonly=""  value="<?php $n=2;
function randomNumber($n) {
 $characters = '0123456789';
 $randomString = '';
 for ($i = 0; $i < $n; $i++) {
  $index = rand(0, strlen($characters) - 1);
  $randomString .= $characters[$index];
 }
 return $randomString;
}
echo date('s').randomNumber($n);?>" >

          </div>
        </div>
        <hr>
        <div class="form-field">
          <label for="title">Title:</label>
          <input type="text" id="title" name="title" required>
        </div>
        <div class="form-field">
          <label for="subject">Subject:</label>
          <input type="text" id="subject" name="subject" required>
        </div>
        <div class="form-field">
          <label for="problemtype">Problem Type:</label>
          <select id="problemtype" name="problemtype" required="">
            <option selected hidden>--Please select--</option>
            <option value="password_issue">Password Issue</option>
            <option value="uploading_issue">Uploading Issue</option>
            <option value="adding_issue">Adding Issue</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div class="form-field">
          <label for="status">Status:</label>
          <select id="status" name="status" required="" disabled="" readonly>
            <option value="open" selected="">Open</option>
            <option value="pending">Pending</option>
            <option value="in_progress">In Progress</option>
            <option value="closed">Closed</option>
          </select>
        </div>
        <div class="form-field">
          <label for="comment">Comment:</label>
          <textarea id="comment" name="comment"  cols="50" rows="20"></textarea>
        </div>
        <div class="form-field" hidden>
          <label for="addedby">Added By:</label>
          <input type="text" id="addedby" name="addedby" value="<?php echo $_SESSION['user'];?>">
        </div>
        <div class="form-field" hidden>
          <label for="segmentation">Segmentation:</label>
          <input type="text" id="segmentation" name="segmentation" value="<?php echo $_SESSION['type'];?>">
        </div>
        <div class="form-field" hidden>
          <label for="date">Date:</label>
          <input type="text" id="date" name="date"  value=" <?php date_default_timezone_set('Africa/Cairo'); $time = date('d/m/Y, h:i:s A'); echo ($time);?>">
        </div>
      </fieldset>
      <div class="form-field">
        <button type="submit" name="addnewtkt" id="addnewtkt">Save</button>
      </div>
    </form>
  </div>
</div>


<!-- /////////////////////////editpopup/////////////////////////-->

<div id="popupFormEdit" class="popup-form">
  <div class="form-content">
    <span class="close-popup" onclick="closePopupFormEdit()">&times;</span>
    <h2>Edit Ticket</h2>
    <form method="POST" autocomplete="on">
       <fieldset class="form-fieldset">
        <legend>Edit Ticket Details</legend>
         <div class="ticket-id">
            <label for="ticketId">Ticket ID:</label>
           <input type="number" id="ticketId" name="ticketId" style="border: none; outline: none; width: 5%; font-size: 10px; background-color: #dddcdc;"  onKeyPress="if(this.value.length==4) return false;" readonly="">

          </div>
          <hr>
        <div>
          <label for="title">Title:</label>
          <input type="text" id="title" name="title" required>
        </div>
        <div>
          <label for="subject">Subject:</label>
          <input type="text" id="subject" name="subject" required>
        </div>
        <div>
          <label for="problemType">Problem Type:</label>
          <select id="problemType" name="problemType">
            <!-- Options here -->
          </select>
        </div>
        <div>
          <label for="status">Status:</label>
          <select id="status" name="status">
            <!-- Options here -->
          </select>
        </div>
        <div>
          <label for="comment">Comment:</label>
          <textarea id="comment" name="comment"></textarea>
        </div>
        <div>
          <button type="submit">Save</button>
        </div>
      </fieldset>
    </form>
  </div>
</div>





<!-- //////////////////////Viewpopup///////////////M_G_X-->



<!-- <div id="popupFormView" class="popup-form">
  <div class="form-content">
    <span class="close-popup" onclick="closeViewPopup()">&times;</span>
    <h2>Ticket Details</h2>
    <div id="ticketDetails">
       <label for="ticketId">Ticket ID:</label>
           <input type="number" id="unique_id" name="unique_id" style="border: none; outline: none; width: 5%; font-size: 10px; background-color: #dddcdc;"  onKeyPress="if(this.value.length==4) return false;" readonly=""  value="$row[unique_id]" >
    </div>
  </div>
</div> -->


  <script>
    function openPopupForm() {
      document.getElementById("popupForm").style.display = "block";
    }

    function closePopupForm() {
      document.getElementById("popupForm").style.display = "none";
    }

    function openPopupFormEdit() {
  var popupForm = document.getElementById("popupFormEdit");
  popupForm.style.display = "block";
}

function closePopupFormEdit() {
  var popupForm = document.getElementById("popupFormEdit");
  popupForm.style.display = "none";
}


// function openViewPopup() {
//   var popupFormView = document.getElementById("popupFormView");
//   popupFormView.style.display = "block";
  
//   // Populate the ticket details dynamically
//   var ticketId = document.querySelector(".ticket-id").textContent;
//   var ticketTitle = document.querySelector(".tickets-table td:nth-child(2)").textContent;
//   var ticketSubject = document.querySelector(".tickets-table td:nth-child(3)").textContent;
//   var ticketProblemType = document.querySelector(".problem-type").textContent;
//   var ticketStatus = document.querySelector(".status").textContent;
  
//   var ticketDetails = document.getElementById("ticketDetails");
//   ticketDetails.innerHTML = `
//     <p><strong>Ticket ID:</strong> ${ticketId}</p>
//     <p><strong>Title:</strong> ${ticketTitle}</p>
//     <p><strong>Subject:</strong> ${ticketSubject}</p>
//     <p><strong>Problem Type:</strong> ${ticketProblemType}</p>
//     <p><strong>Status:</strong> ${ticketStatus}</p>
//     <p><strong>Comment:</strong> ${comment}</p>
//     <p><strong>Added BY:</strong> ${comment}</p>
//     <p><strong>Segmentation:</strong> ${comment}</p>
//     <p><strong>Date:</strong> ${comment}</p>
//     <p><strong>Handler:</strong> ${comment}</p>
//   `;
// }

function closeViewPopup() {
  var popupFormView = document.getElementById("popupFormView");
  popupFormView.style.display = "none";
}

  function openPopup(url) {
    var features = 'width=800,height=600,toolbar=no,location=no,status=no';
    window.open(url, '_blank', features);
  }

 function toggleNavbar() {
    var sidepanel = document.querySelector('.sidepanel');
    sidepanel.classList.toggle('open'); // Toggle the "open" class on the sidepanel
  }
  </script>





<?php
//include 'add user script.php';

//include 'connect.php';




if (@$_SESSION['type']=='admin' || @$_SESSION['type']=='eo_user' || @$_SESSION['type']=='hr_user'  || @$_SESSION['type']=='acc_user' ) {

 include 'add_ir_ticket.php';
 include 'add_ir_ticket_logs.php';

	}else{
            echo "<script>function(){ history.back(); }</script>";
	}









if (@$_SESSION['type']=='admin' ) {






	}elseif (@$_SESSION['type']=='eo_user' || @$_SESSION['type']=='hr_user'  || @$_SESSION['type']=='acc_user') {

		
		 
	}else{
            // echo "<script>function(){ history.back(); }</script>";
	}





////////////////////////////////////////////change pass inc///////////////M_G_X

if(isset($_POST['change'])){

if (@$_SESSION['type']=='admin' ) {



	}elseif (@$_SESSION['type']=='eo_user' || @$_SESSION['type']=='hr_user'  || @$_SESSION['type']=='acc_user') {

	
		 
	}else{
            // echo "<script>history.back();</script>";
	}



}


?>
 

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>



<script>
// $(document).ready(function(){
//   $("tr").on({
//     mouseenter: function(){
//       $(this).css("background-color", "F5CECE");
//     },  
//     mouseleave: function(){
//       $(this).css("background-color", "FEFEFE");

//     }  
//   });
  
  
  
//   $("tr:nth-child(even)").on({
//     mouseenter: function(){
//       $(this).css("background-color", "898181");
//     },  
//     mouseleave: function(){
//       $(this).css("background-color", "CECACA");

//     }  
//   });
// });
</script>



<?php

//////////////////////////
//////////////////////////host checker........../////

























//////////////////////////

@$_SESSION['fullname'] = $_GET['fullname'];
@$_SESSION['pcuser'] = $_GET['pcuser'];
@$_SESSION['pcpass'] = $_GET['pcpass'];
@$_SESSION['login'] = $_GET['login'];
@$_SESSION['shifttime'] = $_GET['shifttime'];
@$_SESSION['sitestatus'] = $_GET['sitestatus'];
@$_SESSION['arrivalstatus'] = $_GET['arrivalstatus'];
@$_SESSION['shiftondate'] = $_GET['shiftondate'];
@$_SESSION['addedon'] = $_GET['addedon'];
@$_SESSION['recordstatus'] = $_GET['recordstatus'];
@$_SESSION['comment'] = $_GET['comment'];
@$_SESSION['lastupdateby'] = $_GET['lastupdateby'];

//$_SESSION['myform'] = $_GET['myform'];
//@$_SESSION['alltxt'] = $_GET['alltxt'];


/*

if(isset($_GET['check'])){

@$fullname       = $_GET['fullname'];
@$pcuser        = $_GET['pcuser'];
@$pcpass        = $_GET['pcpass'];
@$login         = $_GET['login'];
@$shifttime     = $_GET['shifttime'];
@$sitestatus    = $_GET['sitestatus'];
@$arrivalstatus = $_GET['arrivalstatus'];
@$recordstatus  = $_GET['recordstatus'];
@$comment       = $_GET['comment'];
@$shiftondate   = $_GET['shiftondate'];
@$addedon       = $_GET['addedon'];


$sql = "INSERT INTO records (fullname, pcuser, pcpass, login, shifttime, sitestatus, arrivalstatus, recordstatus, comment, shiftondate,  addedon) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
$stmtinsert = $db->prepare($sql);
$result = $stmtinsert->execute([$fullname, $pcuser, $pcpass, $login, $shifttime, $sitestatus, $arrivalstatus, $recordstatus, $comment, $shiftondate, $addedon  ]);
if ($result) {
  # code...
  echo "Data has been saved";
}
else{
  echo "there is error appered";
}
}

*/

/*

if(isset($_GET['check'])){

   
$fullname = $_SESSION['fullname'];
   
$pcuser = $_SESSION['pcuser'];
   
$pcpass = $_SESSION['pcpass'];
   
$login = $_SESSION['login'];
   
$shifttime = $_SESSION['shifttime'];
   
$sitestatus = $_SESSION['sitestatus'];

$arrivalstatus = $_SESSION['arrivalstatus'];

$shiftondate = $_SESSION['shiftondate'];

$addedon = $_SESSION['addedon'];

$recordstatus = $_SESSION['recordstatus'];

$comment = $_SESSION['comment'];


  //echo "Full Name : $fullname<br><br>PC User : $pcuser <br><br>PC Pass : $pcpass<br><br>Login : $login<br><br>Shift Time : $shifttime<br><br>Site Status : $sitestatus<br><br>Arrival Status :$arrivalstatus<br><br>Record Status : $recordstatus<br><br>Comment : $comment<br><br>Shift on Date : $shiftondate<br><br>Added Time : $addedon<br> <hr>";


  echo "
<style>
td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

<center>
<hr>
<hr>

<div style='position: relative;text-align: center;'>
<h1 style='font-size: 19px; font:bold; '>
#_Check_Logs
</h1>
<br>
<h4 style='font-size: 15px; font:bold; font-family: Brush Script MT, cursive;' >
#_Record_Found
</h4>
</div>

<hr>
  <table  id='myTable' style='width:210%; font-size: 15px; position:relative; left: -288px;'>
  <tr>
    <th>Full Name</th>
    <th>PC User</th>
    <th>PC Pass</th>
    <th>Login</th>
    <th>Shift Time</th>
    <th>Site Status</th>
    <th>Arrival Status</th>
    <th>Record Status</th>
    <th>Comment</th>
    <th>Shift on Date</th>
    <th>Added Time</th>
  </tr>
  <tr>
<td>$fullname</td>
<td>$pcuser</td>
<td>$pcpass</td>
<td>$login</td>
<td>$shifttime</td>
<td>$sitestatus</td>
<td>$arrivalstatus</td>
<td>$recordstatus</td>
<td>$comment</td>
<td>$shiftondate</td>
<td>$addedon</td>
</tr>
</table>
</center>
<hr style='width=250px;'>

  ";
           
           
}

*/

/*
if(isset($_GET['check'])){


 if ($_SERVER['REQUEST_METHOD'] == "GET") {
  
  $myfile = fopen('myfile.txt', 'w');
    fwrite($myfile , $_GET['alltxt']);
  fclose($myfile);
 
}
}
*/
/*
if(isset($_GET['check'])){

extract($_REQUEST);
$file=fopen('myfile.html' , 'a');
fwrite($file, "Full Name : ");
fwrite($file, $fullname ."<br>");
fwrite($file, "PC User : ");
fwrite($file, $pcuser ."\n");
fwrite($file, "PC Pass : ");
fwrite($file, $pcpass ."\n");
fwrite($file, "Login : ");
fwrite($file, $login ."\n");
fwrite($file, "Shift Time : ");
fwrite($file, $shifttime ."\n");
fwrite($file, "Site Status : ");
fwrite($file, $sitestatus ."\n");
fwrite($file, "Arrival Status : ");
fwrite($file, $arrivalstatus ."\n");
fwrite($file, "<hr><hr>");
fwrite($file, "------------------------------------------------------");

fclose($myfile);


}

*/

/*
if(isset($_GET['save'])){

extract($_REQUEST);
$file=fopen('myfile.html' , 'a');
fwrite(@$file, "\n");
fwrite(@$file, "\n");
fwrite(@$file, "<!--");
fwrite(@$file, $fullname);
fwrite(@$file, "-->");
fwrite(@$file, "\n");
fwrite(@$file, "<tr>");
//fwrite(@$file, "Full Name : ");
//fwrite(@$file, "<td><img  src='edit.jpg' style='width:24px; position:relative; top:3px;'></img>");
fwrite(@$file, "<td><a href='addir1.php'><img src='edit.jpg' alt='Edit' style='width:24px; position:relative; top:3px;'>
</a>");

fwrite(@$file, $fullname);
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "PC User : ");
fwrite(@$file, $pcuser ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "PC Pass : ");
fwrite(@$file, $pcpass ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Login : ");
fwrite(@$file, $login ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Shift Time : ");
fwrite(@$file, $shifttime ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Site Status : ");
fwrite(@$file, $sitestatus ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Arrival Status : ");
fwrite(@$file, $arrivalstatus ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Record Status : ");
fwrite(@$file, $recordstatus ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Comment : ");
fwrite(@$file, $comment ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Shift on Date : ");
fwrite(@$file, $shiftondate ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "<td>");
//fwrite(@$file, "Added Time : ");
fwrite(@$file, $addedon ."<br>");
fwrite(@$file, "</td>");
fwrite(@$file, "</tr>");
//fwrite(@$file, "<hr><hr>");
fwrite(@$file, "\n");
fwrite(@$file, "\n");

}




*/





?>

<script type="text/javascript">
  /*
document.GETElementById('comment').innerHTML=(myform.recordstatus[myform.recordstatus.selected].text)
*/


</script>
<script type='text/javascript'>

  /*
  $(function() {

    $('#check').click(function(e) {

      var valid = this.form.checkValidity();
      if (valid) {


      var fullname      = $('#fullname').val();
      var pcuser        = $('#pcuser').val();
      var pcpass        = $('#pcpass').val();
      var login         = $('#login').val();
      var shifttime     = $('#shifttime').val();
      var sitestatus    = $('#sitestatus').val();
      var arrivalstatus = $('#arrivalstatus').val();
      var recordstatus  = $('#recordstatus').val();
      var comment       = $('#comment').val();
      var shiftondate   = $('#shiftondate').val();
      var addedon       = $('#addedon').val();
      


        e.preventDefault();
        $.ajax({

          type: 'GET',
          url:  'check.php',
          data: {fullname : fullname,pcuser : pcuser,pcpass : pcpass,login : login,shifttime : shifttime,sitestatus : sitestatus,arrivalstatus : arrivalstatus,recordstatus : recordstatus,comment : comment,shiftondate : shiftondate,addedon : addedon},
          success: function (data) {
            // body...

            Swal.fire({
                             icon: 'success',
                             title: 'Data has been saved',
                             text: data
                             
                             
                             })
          },
          error: function (data) {
            // body...

            Swal.fire({
                             icon: 'error',
                             title: 'Oops...',
                             text: 'Something went wrong!',
                             footer: '<a href="">Why do I have this issue?</a>'
                             })
          }

        });
        //alert('true');

      }
      //else{
        //alert('false');
      //}


      

    });
  });
 
*/

</script>
<?php








  
// $r = mysqli_query($conn , $slecetr= "SELECT * FROM hruploadedfiles");



?>


  <?php




  if(isset($_GET['check'])){

 


    echo "<form>


  

  <table  id='myTable' style='width:99.9%; font-size: 15px; position: relative; left: -15%;'>
  <tr>
    <th style='background-color :#2E2D2D; color:white;'>Record ID</th>
    <th style='background-color :#2E2D2D; color:white;'>Full Name</th>
    <th style='background-color :#2E2D2D; color:white;'>PC User</th>
    <th style='background-color :#2E2D2D; color:white;'>PC Pass</th>
    <th style='background-color :#2E2D2D; color:white;'>Login</th>
    <th style='background-color :#2E2D2D; color:white;'>Shift Time</th>
    <th style='background-color :#2E2D2D; color:white;'>Site Status</th>
    <th style='background-color :#2E2D2D; color:white;'>Arrival Status</th>
    <th style='background-color :#2E2D2D; color:white;'>Record Status</th>
    <th style='background-color :#2E2D2D; color:white;'>Comment</th>
    <th style='background-color :#2E2D2D; color:white;'>Shift on Date</th>
    <th style='background-color :#2E2D2D; color:white;'>Added By</th>
    <th style='background-color :#2E2D2D; color:white;'>Last Update By</th>
    <th style='background-color :#2E2D2D; color:white;'>Added Time</th>
  </tr>";
    while (@$row = mysqli_fetch_array(@$r)){


      echo "<tr>";



      echo "<td>$row[id]</td>";
      echo "<td>$row[fullname]</td>";
      echo "<td>$row[pcuser]</td>";
      echo "<td>$row[pcpass]</td>";
      echo "<td>$row[login]</td>";
      echo "<td>$row[shifttime]</td>";
      echo "<td>$row[sitestatus]</td>";
      echo "<td>$row[arrivalstatus]</td>";
      echo "<td>$row[recordstatus]</td>";
      echo "<td>$row[comment]</td>";
      echo "<td>$row[shiftondate]</td>";
      echo "<td>$row[addedby]</td>";
      echo "<td>$row[lastupdateby]</td>";
      echo "<td>$row[addedon]</td>";
      


      echo "</tr>";

    }
}
  ?>

  <script type="text/javascript">



    
    var tbl = document.GETElementById('myTable');

    for (var x = 1 ;  x < tbl.rows.length ; x++ ){

      tbl.rows[x].onclick = function () {
        // body...

        document.GETElementById('id').value = this.cells[0].innerHTML;
        document.GETElementById('fullname').value = this.cells[1].innerHTML;
        document.GETElementById('pcuser').value = this.cells[2].innerHTML;
        document.GETElementById('pcpass').value = this.cells[3].innerHTML;
        document.GETElementById('login').value = this.cells[4].innerHTML;
        document.GETElementById('shifttime').value = this.cells[5].innerHTML;
        document.GETElementById('sitestatus').value = this.cells[6].innerHTML;
        document.GETElementById('arrivalstatus').value = this.cells[7].innerHTML;
        document.GETElementById('recordstatus').value = this.cells[8].innerHTML;
        document.GETElementById('comment').value = this.cells[9].innerHTML;
        document.GETElementById('shiftondate').value = this.cells[10].innerHTML;
        document.GETElementById('addedon').value = this.cells[13].innerHTML;
      }
    }

  </script>
</form>
</div>
<!-- <span class="printuser">Al-Agouza_Hospital</span> -->

</body>

</html>