
  <!-- Header -->
<?php 
$start_time = microtime(TRUE);
require_once('header.php');
// include 'access.php';
access('AIT');

?>
<!-- End page content -->
<link rel="stylesheet" href="cdn/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
 <script type="text/javascript" src="cdn/xlsx.full.min.js"></script>
 <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script src="cdn/dd9c95f04f.js" crossorigin="anonymous"></script>

<script type="text/javascript">

//   $(document).ready(function(){

// //Using setTimeout to execute a function after 5 seconds.
// setTimeout(function () {
//    //Redirect with JavaScript
//    window.history.pushState("/test2.php", "", '/test3/test2.php');
// }, 0);


// window.scrollTo(1000,0);

// });

 
  $(document).ready(function(){



 function html_table_to_excel(type)
    {
        var data = document.getElementById('myTable');

        var file = XLSX.utils.table_to_book(data, {sheet: "sheet1"});

        XLSX.write(file, { bookType: type, bookSST: true, type: 'base64' });

        XLSX.writeFile(file, 'All patient in DB file.' + type);
    }

    const export_button = document.getElementById('export_button');

    export_button.addEventListener('click', () =>  {
        html_table_to_excel('xlsx');
    });


});
 
  

</script>
<style>


    td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

tr:hover {
  background-color: #85aae5;
}


* {box-sizing: border-box;}

body{ 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    

}
/*
body::before { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  width: 99%;
    content: "";
      background-image: url('pngegg.png');
      background-size: cover;
      position: absolute;
      top: 0px;
      right: 0px;
      bottom: 0px;
      left: 0px;
      opacity: 0.10;
      z-index: -1;
}
 */
#navbar {
  overflow: hidden;
  background-color: #9f8398;
  padding: 90px 10px;
  transition: 0.4s;
  position: fixed;
  width: 100%;
  top: 0;
  z-index: 99;

}

#navbar a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;

}
ul{

  list-style-image: url('fas fa-folder-open');
}
#navbar #logo {
  font-size: 35px;
  font-weight: bold;
  transition: 0.4s;

}

#navbar a:hover {
  background-color: #b99fb2;
  color: black;
}

#navbar a.active {
  background-color: #7d1d64;
  color: white;
}

#navbar-right {
  float: right;
  padding: 12px;
}

 
.container a {
  
  display: block;
  color: black;
  text-align: left;
  padding: 10px;
  
  font-size: 17px;
  list-style-image: url('sqpurple.gif');
}

.container a:hover {
  background-color: #ddd;
  color: black;
  border-radius: 5px;
  padding: 8;
  margin: 4;
  opacity: 0.5;

}

.container a.active {
  background-color: #2196F3;
  color: white;
  

}

.container{
float: left;
text-align: left;
position: absolute;
left: 1%;
width: 70%;

}

.list{
  width: 100%;
  align-items: left;

}

.ifrm{
  width: 100%;
  height: 100%;
  border: none;
}


.list li {
  list-style-type: 'fas fa-folder-open';
  list-style-type: '📂 ';
}

.logo{

  //display: block;
  position: relative;
  float: right;
  left:  -30px;
  width: 20%;
  height: 27%;
  opacity: 0.1;
  background-image: url('pngegg.png');
  //background-repeat: no-repeat;
  //background-position: 100%;
  background-size: cover;
}

.cpr{

/*  padding: 12px;
  margin: 12px;
  position: absolute;*/

  text-align: center;
 cursor: not-allowed;
/*  top: 84%;
  left: 30%;*/
  
}
 
details > summary {
  list-style: none;
}



.navbarh {
  overflow: hidden;
  background-color: #333;
}

.navbarh a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}


.navbarh span {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;

}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}



.export_button {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  cursor: pointer;
  
  background-color: inherit;
  font-family: inherit;
  margin: 0;
   
}

.export_button:hover {
  background-color: red;
}

.navbarh a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}



.custom-footer {
      color: #554949;
      font-size: 13px;
      margin-top: 2rem;
    }
@media screen and (max-width: 580px) {
  #navbar {
    padding: 20px 10px !important;
  }
  #navbar a {
    float: none;
    display: block;
    text-align: left;
  }
  #navbar-right {
    float: none;
  }


details > summary {
  list-style: none;
}





  @media screen and (min-device-width: 1200px) and (max-device-width: 1600px) and (-webkit-min-device-pixel-ratio: 1){
.navbarh{
    width: 120%;
    position: relative;
    top: 20px;

  }
#navbarv{
    width: 70%;
    position: relative;
  }
  }



 @media screen and (min-width: 560px) and (min-height: 350px) and (max-width: 968px) and (max-height: 1000px){
.navbarh{
    width: 120%;
    position: relative;
    top: 20px;

  }

  #navbarv{
    width: 70%;
    position: relative;
  }
   h4{
    top: 75px;
    position: relative;
  }


}


@media screen and (min-width: 90px) and (min-height: 250px) and (max-width: 560px) and (max-height: 915px){

  .navbarh{
    width: 130%;
    position: relative;
    top: 75px;
    height: 150px;

  }

  h4{
    top: 75px;
    position: relative;
  }

  #navbarv{
    width: 80%;
    position: relative;
  }

    #divco{
    overflow: scroll;
    width: 140%;
    position: relative;
  }

}

</style>



<div class="container" style="float: left" dir="ltr">

<h4 style="font-family: 'Carattere', cursive; font-size: 30px;">IT-_-List</h4>
 

 
<!DOCTYPE html>
<html>
<head>
  <title>System Monitoring</title>
  <link rel="stylesheet" href="styles.css">
  <script src="script.js"></script>
</head>
<body>
  <header>
    <h1>System Monitoring</h1>
  </header>

  <main>
    <section>
      <h2>💽 Disk Space</h2>
      <?php
        // Get disk space information
        $totalSpace = disk_total_space("/");
        $freeSpace = disk_free_space("/");
        $usedSpace = $totalSpace - $freeSpace;

        // Convert to human-readable format
        $totalSpace = formatBytes($totalSpace);
        $freeSpace = formatBytes($freeSpace);
        $usedSpace = formatBytes($usedSpace);

        // Display disk space information
        echo "<p>💽 Total Space: $totalSpace</p>";
        echo "<p>💽 Free Space: $freeSpace</p>";
        echo "<p>💽 Used Space: $usedSpace</p>";
      ?>
    </section>

    <section>
      <h2>📟 Database Available Space</h2>

   
      <?php
        // Connect to your database
        $dbHost = "localhost";
        $dbName = "aghis";
        $dbUser = "root";
        $dbPass = "";

        $db = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPass);

        // Get the available space in the database
        $query = "SELECT table_schema AS 'Database', sum( data_length + index_length ) / 1024 / 1024 AS 'Size (MB)' FROM information_schema.TABLES GROUP BY table_schema";
        $result = $db->query($query);
        
        // Display the database available space
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
          echo "<p>📟 Database: " . $row['Database'] . ", Size: " . $row['Size (MB)'] . " MB</p>";
        }
      ?>
    </section>

    <section>
      <h2>🌡️ RAM Available Space</h2>
      <?php
       // Get RAM available space
        $ramInfo = getRamInfo();
        $totalRAM = $ramInfo['total'] ?? 0;
        $usedRAM = $ramInfo['used'] ?? 0;
        $freeRAM = $ramInfo['free'] ?? 0;

        // Display RAM available space
        echo "<p>🌡️ Total RAM: $totalRAM GB</p>";
        echo "<p>🌡️ Used RAM: $usedRAM GB</p>";
        echo "<p>🌡️ Free RAM: $freeRAM GB</p>";

        // Function to get RAM information
        function getRamInfo() {
          $output = array();
          exec('wmic OS get FreePhysicalMemory,TotalVisibleMemorySize', $output);

          $totalRAM = 0;
          $freeRAM = 0;
          if (isset($output[1])) {
            preg_match_all('/\d+/', $output[1], $matches);
            $totalRAM = round($matches[0][1] / 1024/ 1024, 2);
            $freeRAM = round($matches[0][0] / 1024/ 1024, 2);
          }

          $usedRAM = $totalRAM - $freeRAM;

          return array(
            'total' => $totalRAM,
            'used' => $usedRAM,
            'free' => $freeRAM
          );
        }
      ?>
    </section>

    <section>
      <h2>🖥️ CPU Usage</h2>
      <?php
        // Get CPU usage
        $cpuUsage = getCpuUsage();

        // Display CPU usage
        echo "<p>🖥️ CPU Usage: $cpuUsage%</p>";

        // Function to get CPU usage
        function getCpuUsage() {
          $output = array();
          exec('wmic cpu get loadpercentage', $output);

          if (isset($output[1])) {
            return $output[1];
          } else {
            return "N/A";
          }
        }
      ?>
    </section>

  </main>
 <hr>
  <footer  class="custom-footer">
    <?php   $end_time = microtime(TRUE);
  $time_taken = $end_time - $start_time;
  $total_time = round($time_taken,4);?>

  <p style="color: #554949; font-size: 13px;"><span class="description">⏱️ Render : </span> <span class="result"><?php echo $total_time; ?> sec</span></p>
    <p>&copy; 2023 M_G_X. All rights reserved.</p>
  </footer>
</body>
</html>

<?php
// Function to format bytes to human-readable format
function formatBytes($bytes, $decimals = 2) {
    $size = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    $factor = floor((strlen($bytes) - 1) / 3);
    return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . ' ' . $size[$factor];
}
?>






<!-- M_G_X Container -->

<!-- <div class="cpr">

<details style="float: center;">
<summary style="scale:120px right;">
  <u style="color:gray;">
    جميع الحقوق محفوظة © 2022-2023
</u>
</summary>
  <p> * Powered BY <a target="_top" disabled="" style="color: gray; cursor: pointer;"><u>MG</u></a>*</p>

</details>
</div> -->


<?php








if (@$_SESSION['type']=='admin' ) {

        echo "<script>document.getElementById('navbarh').style.backgroundColor = '#081a36';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#081a36';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#081a36';</script>";
        echo "<script>
                       document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                       document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                       function mouseEnter() {
                         document.getElementById('tr').style.backgroundColor = '#9ab3cd';
                       }

                       function mouseLeave() {
                         document.getElementById('tr').style.backgroundColor = '';
                       }
            </script>";






  }elseif (@$_SESSION['type']=='it_user' || @$_SESSION['type']=='ad_it_user') {

      
  echo "<script>document.getElementById('navbarh').style.backgroundColor = '#15483f';</script>";
 
        echo "<script>document.getElementById('navbarv').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('neww3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('newwbuttom').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th1').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th2').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th3').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th4').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th5').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th6').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th7').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th8').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th9').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th10').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th11').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th12').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th13').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th14').style.backgroundColor = '#15483f';</script>";
        echo "<script>document.getElementById('th15').style.backgroundColor = '#15483f';</script>";
        echo "<script>
                      document.getElementById('tr').addEventListener('mouseenter', mouseEnter);
                      document.getElementById('tr').addEventListener('mouseleave', mouseLeave);

                      function mouseEnter() {
                        document.getElementById('tr').style.backgroundColor = '#7e9996';
                      }

                      function mouseLeave() {
                        document.getElementById('tr').style.backgroundColor = '';
                      }
              </script>";


     
  }else{
            echo "<script>function(){ history.back(); }</script>";
  }


?>
