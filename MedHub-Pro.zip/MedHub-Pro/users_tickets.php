
<style>
    .tickets-heading {
        text-align: center;
        font-size: 24px;
        font-weight: bold;
        color: #333;
        margin-bottom: 20px;
    }
</style>
 <hr>
  <br>
<div class='tickets-heading'>
    <h2>Your Tickets</h2>
</div>
<?php
  
   
$sql = "SELECT * from irtickets WHERE  addedby='$_SESSION[user]' ORDER BY date DESC";

$result = $conn->query($sql);

if ($result->num_rows > 0){

	echo "


  <table class='tickets-table'>
  <thead>
    <tr>
      <th>Ticket ID</th>
      <th>Title</th>
      <th>Subject</th>
      <th>Problem Type</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>";

	while($row = $result->fetch_assoc() ){


echo " <tr>
      <td class='ticket-id'>
        <span>$row[unique_id]</span>
        <div class='action-buttons'>
          <button class='edit-button' title='Edit Ticket'>
            <i class='fas fa-pen-square'  href=\"javascript:void(0)\" onclick=\"openPopup('./Edit_Tickets.php?unique_id=$row[unique_id]')\"></i>
          </button>
          <button class='view-button' title='View Ticket' >
            <i class='fas fa-search' href=\"javascript:void(0)\" onclick=\"openPopup('./View_Tickets.php?unique_id=$row[unique_id]')\">
</i>
          </button>
        </div>
      </td>
      <td>$row[title]</td>
      <td>$row[subject]</td>
      <td class='problem-type $row[problemtype]'>$row[problemtype]</td>
      <td class='status $row[status]'>$row[status]</td>
    </tr>";
   
}

echo "</tbody></table>";

 }
else {
   echo "<p style='font-size: 30px; text-align:center;font-family: \"Reem Kufi\", sans-serif;'>There's None to View ..</p>";
}


	?>



