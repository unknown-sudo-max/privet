<?php


function access($type , $redirect = true)
{


	if (isset($_SESSION["ACCESS"]) && !$_SESSION["ACCESS"][$type]) {


		if ($redirect) {
			
			echo "<script> window.location.href=('denied.php');</script>";
        die();
		}
		
		return false;
	}

       return true;
}


$_SESSION["ACCESS"]["ADMIN"] = isset($_SESSION['type']) && trim($_SESSION['type']) == 'admin';

$_SESSION["ACCESS"]["AIT"] = isset($_SESSION['type']) && (trim($_SESSION['type']) == 'ad_it_user' ||  trim($_SESSION['type']) == 'admin');

$_SESSION["ACCESS"]["IT"] = isset($_SESSION['type']) && (trim($_SESSION['type']) == 'ad_it_user' || trim($_SESSION['type']) == 'it_user' ||  trim($_SESSION['type']) == 'admin');

$_SESSION["ACCESS"]["HR_VIEWER"] = isset($_SESSION['type']) && (trim($_SESSION['type']) == 'hr_viewer' || trim($_SESSION['type']) == 'hr_user' || trim($_SESSION['type']) == 'ad_it_user' || trim($_SESSION['type']) == 'it_user' || trim($_SESSION['type']) == 'admin');
$_SESSION["ACCESS"]["ACC_VIEWER"] = isset($_SESSION['type']) && (trim($_SESSION['type']) == 'acc_viewer' || trim($_SESSION['type']) == 'acc_user' || trim($_SESSION['type']) == 'ad_it_user'  || trim($_SESSION['type']) == 'it_user' || trim($_SESSION['type']) == 'admin');
$_SESSION["ACCESS"]["EO_VIEWER"] = isset($_SESSION['type']) && (trim($_SESSION['type']) == 'eo_viewer' || trim($_SESSION['type']) == 'eo_user' || trim($_SESSION['type']) == 'ad_it_user'  || trim($_SESSION['type']) == 'it_user' || trim($_SESSION['type']) == 'admin');

$_SESSION["ACCESS"]["ACC"] = isset($_SESSION['type']) && (trim($_SESSION['type']) == 'acc_user' || trim($_SESSION['type']) == 'ad_it_user'  || trim($_SESSION['type']) == 'it_user' || trim($_SESSION['type']) == 'admin');

$_SESSION["ACCESS"]["HR"] = isset($_SESSION['type']) && (trim($_SESSION['type']) == 'hr_user'  || trim($_SESSION['type']) == 'ad_it_user'  || trim($_SESSION['type']) == 'it_user' ||  trim($_SESSION['type']) == 'admin');

$_SESSION["ACCESS"]["EO"] = isset($_SESSION['type']) && (trim($_SESSION['type']) == 'eo_user' || trim($_SESSION['type']) == 'ad_it_user'  || trim($_SESSION['type']) == 'it_user' || trim($_SESSION['type']) == 'admin');






// var_dump($_SESSION["ACCESS"]["USER"]);