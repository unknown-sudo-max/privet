<?php
if (isset($_POST['export'])) {
    // Your database connection details
    $host = "localhost";
    $username = "root";
    $password = "";
    
    // Create a connection to the MySQL server
    $conn = mysqli_connect($host, $username, $password);
    
    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    // Check if "Select All Databases" is selected
    if (in_array('select_all', $_POST['databases'])) {
        // Export all databases
        $result = mysqli_query($conn, "SHOW DATABASES");
        
        if (!$result) {
            die("Error: " . mysqli_error($conn));
        }
        
        $databases = array();
        
        while ($row = mysqli_fetch_assoc($result)) {
            $database = $row['Database'];
            
            // Exclude system databases like 'information_schema' and 'mysql'
            if ($database != 'information_schema' && $database != 'mysql') {
                $databases[] = $database;
            }
        }
        
        // Set the filename to "All Databases"
        $filename = 'MedHub_Pro_All Databases_' . date('Y-m-d_H-i-s') . '.sql';
    } else {
        // Export selected databases
        $databases = $_POST['databases'] ?? [];
        
        // If only one database is selected, set the filename to the database name
        if (count($databases) === 1) {
            $filename = 'MedHub_Pro_'. $databases[0] . '_' . date('Y-m-d_H-i-s') . '.sql';
        } else {
            // If multiple databases are selected, set a generic filename
            $filename = 'MedHub_Pro_Multiple Databases_' . date('Y-m-d_H-i-s') . '.sql';
        }
    }
    
    // Start the output buffering to capture SQL commands
    ob_start();
    
    // Loop through each database and export its tables, structures, and data
    foreach ($databases as $database) {
        echo "-- Database: $database\n\n";
        
        // Export tables and structures
        mysqli_select_db($conn, $database);
        $tables = mysqli_query($conn, "SHOW TABLES");
        
        if (!$tables) {
            die("Error: " . mysqli_error($conn));
        }
        
        while ($table = mysqli_fetch_row($tables)) {
            echo "-- Table: $table[0]\n\n";
            
            // Export table structure
            $result = mysqli_query($conn, "SHOW CREATE TABLE $table[0]");
            
            if (!$result) {
                die("Error: " . mysqli_error($conn));
            }
            
            $row = mysqli_fetch_assoc($result);
            
            if (!$row) {
                die("Error: " . mysqli_error($conn));
            }
            
            echo $row['Create Table'] . ";\n\n";
            
            // Export table data
            $result = mysqli_query($conn, "SELECT * FROM $table[0]");
            
            if (!$result) {
                die("Error: " . mysqli_error($conn));
            }
            
            while ($row = mysqli_fetch_assoc($result)) {
                $values = array_map(function($value) use ($conn) {
                    return "'" . mysqli_real_escape_string($conn, $value) . "'";
                }, $row);
                
                echo "INSERT INTO $table[0] (`" . implode('`, `', array_keys($row)) . "`) VALUES (" . implode(", ", $values) . ");\n";
            }
            
            echo "\n";
        }
        
        echo "\n";
    }
    
    // Get the output buffer contents and save it to a file
    $sql = ob_get_clean();
    file_put_contents($filename, $sql);
    
    // Close the database connection
    mysqli_close($conn);
    
    // Set appropriate headers for file download
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($filename));
    readfile($filename);
    
    // Delete the temporary SQL file
    unlink($filename);
    exit;
}
?>
