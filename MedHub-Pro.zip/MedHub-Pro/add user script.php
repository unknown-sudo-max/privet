
<?php


require_once 'connect.php';
require_once 'Add_new_user.php';

if(isset($_POST['save'])){



//@$alert =$_POST['alert'];





if (!empty($_POST['thefname']) && !empty($_POST['theuser']) && !empty($_POST['usertype'])) {

	# code...

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
@$name = strip_tags($_POST['thefname']);
@$user = strip_tags($_POST['theuser']);
@$pass = strip_tags($_POST['thepass']);
@$date = strip_tags($_POST['addedon']);
@$type = strip_tags($_POST['usertype']);

$db  ="insert into users (name,user,pass,date,type) values('$name','$user','$pass','$date','$type')";
}


if (mysqli_query($conn, $db )) {

	# code...

	echo "<p style='color:green; font-size:15px;'>The User Added Successfully</p>";
}
	else{

		echo "<p style='color:red; font-size:15px;'>Failed TO Add The User! , (#_OR The User Already Exists !!)</p>";
	}

mysqli_close($conn);

}
else{
	echo "<p style='color:red; font-size:15px;'>All Fields Required !</p>";
}
/*
if (mysqli_query($conn, $db )) {

	# code...

	echo "user added success";
}
	else{

		echo "failed";
	}

mysqli_close($conn);

*/



}

ob_start();

@session_start();
//@$_SESSION['theuser'] = $_POST['theuser'];

//@$_SESSION['thepass'] = $_POST['thepass'];

//@$_SESSION['thefname'] = $_POST['thefname'];

/*


if(isset($_POST['save'])){

extract($_REQUEST);
$file=fopen('myusers2.php' , 'a');
fwrite(@$file, "///////////////");
fwrite(@$file, $thefname);
fwrite(@$file, " User");
fwrite(@$file, "//");
fwrite(@$file, "\n");
fwrite(@$file, "if(isset($");
fwrite(@$file, "_");
fwrite(@$file, "POST['submit'])){");
fwrite(@$file, "if(");
fwrite(@$file, "$");
fwrite(@$file, "user ");
fwrite(@$file, "== '");
fwrite(@$file, $theuser);
fwrite(@$file, "'){");
fwrite(@$file, "if(");
fwrite(@$file, "$");
fwrite(@$file, "pass ");
fwrite(@$file, "== '");
fwrite(@$file, $thepass);
fwrite(@$file, "'){");
fwrite(@$file, "echo ");
fwrite(@$file, "\"<script>");
fwrite(@$file, "window.location.href=");
fwrite(@$file, "('Avaya_vaildation.php');");
fwrite(@$file, "</script>\";");
fwrite(@$file, "}");

fwrite(@$file, "else{");

fwrite(@$file, "$");
fwrite(@$file, "error ");
fwrite(@$file, "= ");
fwrite(@$file, "\"<div ");
fwrite(@$file, "style='position: relative;text-align: center;'>");
fwrite(@$file, "<n style='color: red;'>");
fwrite(@$file, "Invalid Login</n>");
fwrite(@$file, "<br><k>");
fwrite(@$file, "Check your password again , OR refer to your Adminstrator");
fwrite(@$file, "</k><div>\";");
//fwrite(@$file, "$error = \'<div style='position: relative;text-align: center;'><n style='color: red;'>Invalid Login</n><br><k>Check your password again , OR refer to your Adminstrator</k><div>\';");
   
fwrite(@$file, "$");
fwrite(@$file, "success ");
   fwrite(@$file, "= '';"); 


     fwrite(@$file, "echo \"<br><br> <br> ");    
     fwrite(@$file, "$");
     fwrite(@$file, "error\";");       
     fwrite(@$file, "}}}");  
     fwrite(@$file, "\n");       

            
}

*/





  ob_end_flush();

?>
